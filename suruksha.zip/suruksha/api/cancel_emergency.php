<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
$user = require_role(['citizen']);
$input = json_decode(file_get_contents('php://input'), true) ?: [];
if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}
db()->prepare('INSERT INTO emergency_logs (user_id, actor_role, action, details, ip_address) VALUES (?, ?, ?, ?, ?)')
    ->execute([$user['id'], $user['role'], 'emergency_cancelled_before_submit', json_encode($input), client_ip()]);
echo json_encode(['success' => true]);
