<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');

$category = $_GET['category'] ?? 'all';
$period = $_GET['period'] ?? 'today'; // today, week, month, all
$offset = $_GET['offset'] ?? 0;
$limit = $_GET['limit'] ?? 10;

try {
    $where = [];
    $params = [];

    // Category filter
    if ($category !== 'all') {
        $where[] = "category = ?";
        $params[] = $category;
    }

    // Period filter
    if ($period === 'today') {
        $where[] = "DATE(created_at) = CURDATE()";
    } elseif ($period === 'week') {
        $where[] = "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
    } elseif ($period === 'month') {
        $where[] = "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    }

    $whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

    // Get incidents
    $sql = "SELECT id, 'incident' as type, title as description, category, status, severity, created_at, updated_at 
            FROM incidents $whereClause
            UNION ALL
            SELECT id, 'sos' as type, CONCAT('SOS: ', emergency_category) as description, emergency_category as category, status, severity, created_at, updated_at 
            FROM sos_alerts $whereClause
            UNION ALL
            SELECT id, 'missing' as type, CONCAT('Missing: ', full_name) as description, 'Missing Person' as category, status, 3 as severity, created_at, updated_at 
            FROM missing_persons $whereClause
            ORDER BY created_at DESC 
            LIMIT ? OFFSET ?";

    $params[] = (int)$limit;
    $params[] = (int)$offset;

    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $reports = $stmt->fetchAll();

    // Get counts by category
    $countsSql = "SELECT 
                    (SELECT COUNT(*) FROM incidents WHERE DATE(created_at) = CURDATE()) as incidents_today,
                    (SELECT COUNT(*) FROM sos_alerts WHERE DATE(created_at) = CURDATE()) as sos_today,
                    (SELECT COUNT(*) FROM missing_persons WHERE DATE(created_at) = CURDATE()) as missing_today,
                    (SELECT COUNT(*) FROM incidents WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as incidents_week,
                    (SELECT COUNT(*) FROM sos_alerts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as sos_week,
                    (SELECT COUNT(*) FROM missing_persons WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as missing_week,
                    (SELECT COUNT(*) FROM incidents WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as incidents_month,
                    (SELECT COUNT(*) FROM sos_alerts WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as sos_month,
                    (SELECT COUNT(*) FROM missing_persons WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as missing_month";
    
    $counts = db()->query($countsSql)->fetch();

    echo json_encode([
        'success' => true,
        'reports' => $reports,
        'counts' => $counts,
        'total' => count($reports)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
