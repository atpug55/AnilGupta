<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');

try {
    // Get SOS metrics
    $activeSOS = db()->query("
        SELECT COUNT(*) as count 
        FROM sos_alerts 
        WHERE status = 'active'
    ")->fetch()['count'] ?? 0;

    $respondingSOS = db()->query("
        SELECT COUNT(*) as count 
        FROM sos_alerts 
        WHERE status = 'active' AND live_status = 'RESPONDING'
    ")->fetch()['count'] ?? 0;

    $assignedSOS = db()->query("
        SELECT COUNT(*) as count 
        FROM sos_alerts 
        WHERE status = 'active' AND live_status = 'OFFICER_ASSIGNED'
    ")->fetch()['count'] ?? 0;

    $offlineSOS = db()->query("
        SELECT COUNT(*) as count 
        FROM sos_alerts 
        WHERE status = 'active' AND live_status = 'OFFLINE'
    ")->fetch()['count'] ?? 0;

    echo json_encode([
        'active' => $activeSOS,
        'responding' => $respondingSOS,
        'assigned' => $assignedSOS,
        'offline' => $offlineSOS
    ]);
} catch (Throwable $e) {
    error_log('Error in command_metrics: ' . $e->getMessage());
    echo json_encode([
        'active' => 0,
        'responding' => 0,
        'assigned' => 0,
        'offline' => 0
    ]);
}
