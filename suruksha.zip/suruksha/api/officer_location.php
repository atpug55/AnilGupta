<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
$user = require_role(['officer','station_incharge','emergency_operator']);
$input = json_decode(file_get_contents('php://input'), true) ?: [];
if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}
if (empty($input['latitude']) || empty($input['longitude'])) {
    echo json_encode(['success' => false, 'message' => 'Missing location']);
    exit;
}
db()->prepare('INSERT INTO officer_tracking (officer_user_id, latitude, longitude, speed_kmh, status, last_active_at) VALUES (?, ?, ?, ?, ?, NOW())')
    ->execute([$user['id'], $input['latitude'], $input['longitude'], $input['speed_kmh'] ?? null, $input['status'] ?? 'available']);
echo json_encode(['success' => true]);
