<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
$user = require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);
$input = json_decode(file_get_contents('php://input'), true) ?: [];
if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}
$sosId = (int)($input['sos_alert_id'] ?? 0);
$officerId = (int)($input['officer_user_id'] ?? 0);
if (!$sosId || !$officerId) {
    echo json_encode(['success' => false, 'message' => 'Select a valid officer']);
    exit;
}
db()->prepare('INSERT INTO case_assignments (sos_alert_id, officer_user_id, assigned_by, status, notes) VALUES (?, ?, ?, ?, ?)')
    ->execute([$sosId, $officerId, $user['id'], 'ASSIGNED', $input['notes'] ?? null]);
db()->prepare("UPDATE sos_alerts SET live_status='OFFICER_ASSIGNED' WHERE id=?")->execute([$sosId]);
db()->prepare('INSERT INTO live_notifications (user_id, title, message, type, related_type, related_id) VALUES (?, ?, ?, ?, ?, ?)')
    ->execute([$officerId, 'New Emergency Assignment', 'You have been assigned SOS case #' . $sosId, 'danger', 'sos', $sosId]);
db()->prepare('INSERT INTO emergency_logs (sos_alert_id, user_id, actor_role, action, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)')
    ->execute([$sosId, $user['id'], $user['role'], 'ASSIGN_OFFICER', 'Officer user ID: ' . $officerId, client_ip()]);
echo json_encode(['success' => true, 'message' => 'Officer assigned']);
