<?php
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../config/google-config.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$credential = $input['credential'] ?? '';

if (!$credential || !is_google_configured()) {
    echo json_encode(['message' => 'Google login is not configured.']);
    exit;
}

$parts = explode('.', $credential);
$payload = json_decode(base64_decode(strtr($parts[1] ?? '', '-_', '+/')), true);

if (!$payload || ($payload['aud'] ?? '') !== GOOGLE_CLIENT_ID || empty($payload['email'])) {
    echo json_encode(['message' => 'Invalid Google credential.']);
    exit;
}

$email = strtolower($payload['email']);
$name = $payload['name'] ?? $email;
$googleSub = $payload['sub'] ?? null;
$picture = $payload['picture'] ?? null;

$stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user) {
    // Auto-create account for new Google users
    $username = generate_username($name);
    $profilePhoto = $picture ? mb_substr($picture, 0, 500) : null;
    
    db()->prepare('INSERT INTO users (name, username, email, google_sub, profile_photo, auth_provider, account_status, is_verified, last_login_at) VALUES (?, ?, ?, ?, ?, ?, ?, 1, NOW())')
        ->execute([$name, $username, $email, $googleSub, $profilePhoto, 'google', 'active']);
    
    $stmt->execute([$email]);
    $user = $stmt->fetch();
} else {
    // Update existing Google user with latest profile info
    if ($user['auth_provider'] === 'google' || empty($user['auth_provider'])) {
        $updateFields = ['last_login_at = NOW()'];
        $params = [];
        
        if ($picture && (!$user['profile_photo'] || $user['profile_photo'] !== $picture)) {
            $updateFields[] = 'profile_photo = ?';
            $params[] = mb_substr($picture, 0, 500);
        }
        
        if ($googleSub && !$user['google_sub']) {
            $updateFields[] = 'google_sub = ?';
            $params[] = $googleSub;
        }
        
        if (!empty($params)) {
            $params[] = $user['id'];
            db()->prepare('UPDATE users SET ' . implode(', ', $updateFields) . ' WHERE id = ?')
                ->execute($params);
        }
    } else {
        // Update last login for local auth users logging in via Google
        db()->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?')->execute([$user['id']]);
    }
}

session_regenerate_id(true);
$_SESSION['user_id'] = $user['id'];

$redirectPath = $user['role'] === 'citizen' ? 'citizen/dashboard.php' : 
                (in_array($user['role'], ['officer','station_incharge','emergency_operator'], true) ? 'officer/dashboard.php' : 'admin/dashboard.php');

echo json_encode(['redirect' => APP_URL . '/' . $redirectPath]);
