<?php
require_once __DIR__ . '/../includes/helpers.php';

header('Content-Type: application/json');

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['csrf_token']) || !isset($input['station_id']) || !isset($input['pin'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid request', 'debug' => $input]);
        exit;
    }
    
    // Verify CSRF token from JSON body
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid security token', 'session_token' => $_SESSION['csrf_token'] ?? 'none', 'input_token' => $input['csrf_token']]);
        exit;
    }
    
    $user = require_role(['admin', 'super_admin', 'police_admin']);
    
    // Hardcoded PIN for admin operations
    $adminPin = '5555';
    if ($input['pin'] !== $adminPin) {
        echo json_encode(['success' => false, 'message' => 'Invalid PIN']);
        exit;
    }
    
    $stationId = (int)$input['station_id'];
    
    // Check if station exists
    $station = db()->prepare('SELECT * FROM police_stations WHERE id = ?');
    $station->execute([$stationId]);
    if (!$station->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Station not found', 'station_id' => $stationId]);
        exit;
    }
    
    // Delete the station (foreign keys have ON DELETE SET NULL)
    $stmt = db()->prepare('DELETE FROM police_stations WHERE id = ?');
    $result = $stmt->execute([$stationId]);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Station deleted successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete station', 'error_info' => $stmt->errorInfo()]);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage(), 'trace' => $e->getTraceAsString()]);
}
