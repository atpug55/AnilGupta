<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
$user = require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator','officer']);
$input = json_decode(file_get_contents('php://input'), true) ?: [];
if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}
$sosId = (int)($input['sos_alert_id'] ?? 0);
$action = $input['action'] ?? '';
$map = [
    'ACCEPT_CASE' => ['status' => 'acknowledged', 'live_status' => 'RESPONDING'],
    'MARK_RESOLVED' => ['status' => 'resolved', 'live_status' => 'RESOLVED'],
    'FALSE_ALERT' => ['status' => 'false_alarm', 'live_status' => 'FALSE_ALERT'],
    'CLOSE_ALERT' => ['status' => 'resolved', 'live_status' => 'EMERGENCY_CLOSED'],
    'responding' => ['status' => 'active', 'live_status' => 'RESPONDING'],
    'officer_assigned' => ['status' => 'active', 'live_status' => 'OFFICER_ASSIGNED'],
    'resolved' => ['status' => 'resolved', 'live_status' => 'RESOLVED'],
];
if (!$sosId || !isset($map[$action])) {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
}
db()->prepare('UPDATE sos_alerts SET status=?, live_status=? WHERE id=?')->execute([$map[$action]['status'], $map[$action]['live_status'], $sosId]);
db()->prepare('INSERT INTO emergency_logs (sos_alert_id, user_id, actor_role, action, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)')
    ->execute([$sosId, $user['id'], $user['role'], $action, $input['notes'] ?? null, client_ip()]);
echo json_encode(['success' => true, 'message' => 'Case updated']);
