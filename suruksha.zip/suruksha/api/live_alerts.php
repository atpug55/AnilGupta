<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);
$stmt = db()->query("SELECT s.*, u.name AS citizen_name, u.phone FROM sos_alerts s JOIN users u ON u.id = s.user_id WHERE s.status = 'active' ORDER BY s.created_at DESC LIMIT 10");
$alerts = $stmt->fetchAll();
echo json_encode(['alerts' => $alerts, 'server_time' => date('Y-m-d H:i:s')]);
