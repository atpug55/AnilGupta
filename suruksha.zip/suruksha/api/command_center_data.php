<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);
db()->query("UPDATE sos_alerts SET live_status='OFFLINE' WHERE status='active' AND last_active_at IS NOT NULL AND last_active_at < DATE_SUB(NOW(), INTERVAL 30 SECOND)");
$alerts = db()->query("SELECT s.*, u.name AS citizen_name, u.phone, u.email, ps.name AS nearest_station FROM sos_alerts s JOIN users u ON u.id=s.user_id LEFT JOIN police_stations ps ON ps.section=s.emergency_category WHERE s.status='active' ORDER BY s.severity DESC, s.created_at DESC LIMIT 30")->fetchAll();
foreach ($alerts as &$alert) {
    $path = db()->prepare('SELECT latitude, longitude, speed_kmh, movement_direction, battery_level, created_at FROM live_locations WHERE sos_alert_id=? ORDER BY created_at DESC LIMIT 25');
    $path->execute([$alert['id']]);
    $alert['path'] = array_reverse($path->fetchAll());
}
$stations = db()->query('SELECT id, name, district, section, latitude, longitude FROM police_stations WHERE latitude IS NOT NULL AND longitude IS NOT NULL')->fetchAll();
$officers = db()->query("SELECT u.id, u.name, u.phone, ot.latitude, ot.longitude, ot.status, ot.last_active_at FROM users u JOIN officer_tracking ot ON ot.officer_user_id=u.id JOIN (SELECT officer_user_id, MAX(id) id FROM officer_tracking GROUP BY officer_user_id) latest ON latest.id=ot.id WHERE u.role IN ('officer','station_incharge','emergency_operator')")->fetchAll();
echo json_encode(['alerts' => $alerts, 'stations' => $stations, 'officers' => $officers, 'server_time' => date('Y-m-d H:i:s')]);
