<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');

$id = $_GET['id'] ?? 0;

// Get emergency details
$stmt = db()->prepare("
    SELECT 
        s.id,
        s.emergency_category as category,
        s.status,
        s.severity,
        s.latitude,
        s.longitude,
        s.address as location,
        s.live_status,
        s.created_at,
        u.name,
        u.phone,
        s.speed_kmh,
        s.movement_direction,
        s.battery_level,
        s.notes
    FROM sos_alerts s 
    JOIN users u ON u.id = s.user_id 
    WHERE s.id = ?
");
$stmt->execute([$id]);
$emergency = $stmt->fetch();

if (!$emergency) {
    echo json_encode(['error' => 'Emergency not found']);
    exit;
}

echo json_encode($emergency);
