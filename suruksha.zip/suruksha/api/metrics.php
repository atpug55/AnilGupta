<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');

try {
    $metricResults = db()->query("
        SELECT 
            (SELECT COUNT(*) FROM incidents WHERE status NOT IN ('resolved','rejected')) as active,
            (SELECT COUNT(*) FROM sos_alerts WHERE status='active') as sos,
            (SELECT COUNT(*) FROM incidents WHERE severity >= 4 AND status NOT IN ('resolved','rejected')) as high,
            (SELECT COUNT(*) FROM officers WHERE status='available') as officers,
            (SELECT COUNT(*) FROM incidents WHERE status='resolved' AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) +
            (SELECT COUNT(*) FROM sos_alerts WHERE status IN ('resolved','acknowledged') AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) +
            (SELECT COUNT(*) FROM missing_persons WHERE status='found' AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as resolved_today,
            (SELECT COUNT(*) FROM incidents WHERE DATE(created_at) = CURDATE()) +
            (SELECT COUNT(*) FROM sos_alerts WHERE DATE(created_at) = CURDATE()) +
            (SELECT COUNT(*) FROM missing_persons WHERE DATE(created_at) = CURDATE()) as reports_today
    ")->fetch();
    
    $metrics = [
        'active' => (int)$metricResults['active'],
        'sos' => (int)$metricResults['sos'],
        'high' => (int)$metricResults['high'],
        'officers' => (int)$metricResults['officers'],
        'resolved_today' => (int)$metricResults['resolved_today'],
        'reports_today' => (int)$metricResults['reports_today'],
    ];

    echo json_encode(['success' => true, 'metrics' => $metrics]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
