<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
$user = require_role(['citizen']);
$input = json_decode(file_get_contents('php://input'), true) ?: [];
if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}
$sosId = (int)($input['sos_alert_id'] ?? 0);
$lat = $input['latitude'] ?? null;
$lng = $input['longitude'] ?? null;
if (!$sosId || !$lat || !$lng) {
    echo json_encode(['success' => false, 'message' => 'Missing location data']);
    exit;
}
$prev = db()->prepare('SELECT latitude, longitude, created_at FROM live_locations WHERE sos_alert_id = ? ORDER BY created_at DESC LIMIT 1');
$prev->execute([$sosId]);
$last = $prev->fetch();
$speed = null;
$direction = 'Stationary';
if ($last) {
    $distance = geo_distance_km((float)$last['latitude'], (float)$last['longitude'], (float)$lat, (float)$lng);
    $seconds = max(1, time() - strtotime($last['created_at']));
    $speed = round(($distance / $seconds) * 3600, 2);
    $direction = compass_direction((float)$last['latitude'], (float)$last['longitude'], (float)$lat, (float)$lng);
}
$battery = isset($input['battery_level']) ? (int)$input['battery_level'] : null;
db()->prepare('INSERT INTO live_locations (sos_alert_id, user_id, latitude, longitude, accuracy, speed_kmh, movement_direction, battery_level, is_online, device_info) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)')
    ->execute([$sosId, $user['id'], $lat, $lng, $input['accuracy'] ?? null, $speed, $direction, $battery, mb_substr($input['device_info'] ?? '', 0, 255)]);
db()->prepare('UPDATE sos_alerts SET latitude=?, longitude=?, live_status="ACTIVE", last_active_at=NOW(), speed_kmh=?, movement_direction=?, battery_level=? WHERE id=? AND user_id=?')
    ->execute([$lat, $lng, $speed, $direction, $battery, $sosId, $user['id']]);
db()->prepare('INSERT INTO device_activity (user_id, sos_alert_id, status, device_info, battery_level, ip_address) VALUES (?, ?, ?, ?, ?, ?)')
    ->execute([$user['id'], $sosId, ($battery !== null && $battery < 15) ? 'LOW_BATTERY' : 'ONLINE', mb_substr($input['device_info'] ?? '', 0, 255), $battery, client_ip()]);
echo json_encode(['success' => true, 'speed_kmh' => $speed, 'direction' => $direction]);
