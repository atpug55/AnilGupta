<?php
require_once __DIR__ . '/../includes/helpers.php';

$user = require_role(['citizen']);

// Check if user has SOS PIN set
$hasPin = !empty($user['sos_pin_hash']);

header('Content-Type: application/json');
echo json_encode(['has_pin' => $hasPin]);
