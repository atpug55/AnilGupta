<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');
$user = require_role(['officer','station_incharge','emergency_operator']);
$input = json_decode(file_get_contents('php://input'), true) ?: [];
if (!hash_equals($_SESSION['csrf_token'] ?? '', $input['csrf_token'] ?? '')) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Invalid token']);
    exit;
}
$sosId = (int)($input['sos_alert_id'] ?? 0);
$status = $input['status'] ?? 'ACCEPTED';
$allowed = ['ACCEPTED','EN_ROUTE','ON_SCENE','SAFE','CLOSED'];
if (!$sosId || !in_array($status, $allowed, true)) {
    echo json_encode(['success' => false, 'message' => 'Invalid update']);
    exit;
}
db()->prepare('UPDATE case_assignments SET status=? WHERE sos_alert_id=? AND officer_user_id=?')->execute([$status, $sosId, $user['id']]);
if ($status === 'SAFE' || $status === 'CLOSED') {
    db()->prepare("UPDATE sos_alerts SET live_status='RESOLVED', status='resolved' WHERE id=?")->execute([$sosId]);
} else {
    db()->prepare("UPDATE sos_alerts SET live_status='RESPONDING' WHERE id=?")->execute([$sosId]);
}
db()->prepare('INSERT INTO response_history (sos_alert_id, officer_user_id, action, notes) VALUES (?, ?, ?, ?)')
    ->execute([$sosId, $user['id'], $status, $input['notes'] ?? null]);
db()->prepare('INSERT INTO emergency_logs (sos_alert_id, user_id, actor_role, action, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)')
    ->execute([$sosId, $user['id'], $user['role'], 'OFFICER_' . $status, $input['notes'] ?? null, client_ip()]);
echo json_encode(['success' => true, 'message' => 'Officer response updated']);
