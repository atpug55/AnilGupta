<?php
require_once __DIR__ . '/../includes/ai.php';
require_once __DIR__ . '/../includes/emergency_mailer.php';
header('Content-Type: application/json');
$user = require_role(['citizen']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$csrf = $input['csrf_token'] ?? '';
if (!hash_equals($_SESSION['csrf_token'] ?? '', $csrf)) {
    http_response_code(419);
    echo json_encode(['success' => false, 'message' => 'Invalid security token.']);
    exit;
}

$sosSecret = (string)($input['sos_secret'] ?? '');
$authMethod = trim($input['auth_method'] ?? 'Account password/SOS PIN');
$deviceInfo = mb_substr(trim($input['device_info'] ?? ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown device')), 0, 255);
$db = db();
ensure_sos_pin_column();
$user = current_user();
$authOk = $sosSecret !== '' && (
    (!empty($user['password_hash']) && password_verify($sosSecret, $user['password_hash'])) ||
    (!empty($user['sos_pin_hash']) && password_verify($sosSecret, $user['sos_pin_hash']))
);
$db->prepare('INSERT INTO authentication_logs (user_id, auth_context, auth_method, success, device_info, ip_address) VALUES (?, ?, ?, ?, ?, ?)')
    ->execute([$user['id'], 'sos', $authMethod, $authOk ? 1 : 0, $deviceInfo, client_ip()]);

if (!$authOk) {
    echo json_encode(['success' => false, 'message' => 'Wrong or empty PIN/password. SOS was not sent.']);
    exit;
}

if (!check_sos_rate_limit((int)$user['id'])) {
    echo json_encode(['success' => false, 'message' => 'Too many SOS attempts. Please wait before trying again.']);
    exit;
}

$category = trim($input['emergency_category'] ?? 'General Emergency');
$lat = $input['latitude'] !== '' ? $input['latitude'] : null;
$lng = $input['longitude'] !== '' ? $input['longitude'] : null;
$address = trim($input['address'] ?? '');
$ai = analyze_incident_with_ai('SOS Alert: ' . $category, 'Emergency SOS triggered by citizen. Category: ' . $category . '. Device: ' . $deviceInfo, 'auto');
$severity = max(4, (int)$ai['severity']);

$stmt = $db->prepare('INSERT INTO sos_alerts (user_id, latitude, longitude, address, emergency_category, device_info, authenticated, auth_method, severity, ai_summary) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?)');
$stmt->execute([$user['id'], $lat, $lng, $address, $category, $deviceInfo, $authMethod, $severity, $ai['summary']]);
$sosId = (int)$db->lastInsertId();

$db->prepare('INSERT INTO sos_logs (sos_alert_id, user_id, action, details, ip_address) VALUES (?, ?, ?, ?, ?)')
    ->execute([$sosId, $user['id'], 'sos_created', 'Authenticated SOS created with method: ' . $authMethod, client_ip()]);
$db->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)')
    ->execute([$user['id'], 'Emergency SOS Alert', 'You triggered ' . $category . ' SOS.', 'danger']);

$caseStmt = $db->prepare('SELECT s.*, u.name AS citizen_name, u.phone, u.email FROM sos_alerts s JOIN users u ON u.id = s.user_id WHERE s.id = ?');
$caseStmt->execute([$sosId]);
$case = $caseStmt->fetch();
if ($case) {
    send_emergency_alert_emails($case, 'SOS Emergency', $category, 'sos');
}

echo json_encode(['success' => true, 'message' => 'SOS sent to police control room.', 'id' => $sosId]);
