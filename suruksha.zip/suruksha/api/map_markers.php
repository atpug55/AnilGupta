<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');

$allMarkers = [];

// Get police stations
try {
    $stations = db()->query("
        SELECT 
            id,
            name AS title,
            'station' AS status,
            1 AS severity,
            latitude,
            longitude,
            address,
            district,
            section,
            'station' AS type
        FROM police_stations 
        WHERE latitude IS NOT NULL AND longitude IS NOT NULL
    ")->fetchAll();
    $allMarkers = array_merge($allMarkers, $stations);
    error_log('Fetched ' . count($stations) . ' police stations');
} catch (Throwable $e) {
    error_log('Error fetching police stations: ' . $e->getMessage());
}

// Get police officers as additional stations
try {
    $officers = db()->query("
        SELECT 
            o.id,
            u.name AS title,
            o.status,
            1 AS severity,
            o.latitude,
            o.longitude,
            'officer' AS type
        FROM officers o
        JOIN users u ON u.id = o.user_id
        WHERE o.latitude IS NOT NULL AND o.longitude IS NOT NULL
    ")->fetchAll();
    $allMarkers = array_merge($allMarkers, $officers);
    error_log('Fetched ' . count($officers) . ' police officers');
} catch (Throwable $e) {
    error_log('Error fetching police officers: ' . $e->getMessage());
}

// Get incidents with full details
try {
    $incidents = db()->query("
        SELECT 
            i.id,
            i.title,
            i.status,
            i.severity,
            i.latitude,
            i.longitude,
            i.address,
            i.category,
            i.created_at,
            u.name AS citizen_name,
            u.phone AS citizen_phone,
            'incident' AS type
        FROM incidents i 
        JOIN users u ON u.id = i.user_id 
        WHERE i.latitude IS NOT NULL AND i.longitude IS NOT NULL 
        AND i.status NOT IN ('resolved','rejected') 
        ORDER BY i.severity DESC, i.created_at DESC 
        LIMIT 200
    ")->fetchAll();
    $allMarkers = array_merge($allMarkers, $incidents);
    error_log('Fetched ' . count($incidents) . ' incidents');
} catch (Throwable $e) {
    error_log('Error fetching incidents: ' . $e->getMessage());
}

// Get SOS alerts with live GPS locations
try {
    $sosAlerts = db()->query("
        SELECT 
            s.id,
            s.emergency_category AS title,
            s.status,
            s.severity,
            s.latitude,
            s.longitude,
            s.address,
            s.live_status,
            s.created_at,
            u.name AS citizen_name,
            u.phone AS citizen_phone,
            s.speed_kmh,
            s.movement_direction,
            s.battery_level,
            'sos' AS type
        FROM sos_alerts s 
        JOIN users u ON u.id = s.user_id 
        WHERE s.latitude IS NOT NULL AND s.longitude IS NOT NULL 
        AND s.status = 'active' 
        ORDER BY s.severity DESC, s.created_at DESC 
        LIMIT 200
    ")->fetchAll();
    $allMarkers = array_merge($allMarkers, $sosAlerts);
    error_log('Fetched ' . count($sosAlerts) . ' SOS alerts');
} catch (Throwable $e) {
    error_log('Error fetching SOS alerts: ' . $e->getMessage());
}

error_log('Total markers: ' . count($allMarkers));

// Convert latitude and longitude to float for JavaScript
foreach ($allMarkers as &$marker) {
    if (isset($marker['latitude'])) {
        $marker['latitude'] = (float)$marker['latitude'];
    }
    if (isset($marker['longitude'])) {
        $marker['longitude'] = (float)$marker['longitude'];
    }
}

echo json_encode($allMarkers);
