<?php
require_once __DIR__ . '/../includes/helpers.php';
header('Content-Type: application/json');

try {
    // Get active SOS alerts for live feed
    $alerts = db()->query("
        SELECT 
            s.id,
            s.emergency_category as category,
            s.status,
            s.severity,
            s.latitude,
            s.longitude,
            s.address,
            s.live_status,
            s.created_at,
            u.name,
            u.phone,
            s.speed_kmh,
            s.movement_direction,
            s.battery_level
        FROM sos_alerts s 
        JOIN users u ON u.id = s.user_id 
        WHERE s.status = 'active' 
        ORDER BY s.severity DESC, s.created_at DESC 
        LIMIT 20
    ")->fetchAll();

    // Format time for display
    foreach ($alerts as &$alert) {
        $alert['time'] = date('H:i', strtotime($alert['created_at']));
    }

    echo json_encode($alerts);
} catch (Throwable $e) {
    error_log('Error in live_feed: ' . $e->getMessage());
    echo json_encode([]);
}
