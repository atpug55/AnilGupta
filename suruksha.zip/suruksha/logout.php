<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/helpers.php';

// Verify CSRF token for logout to prevent CSRF attacks
$token = $_GET['csrf_token'] ?? '';
if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
    flash('danger', 'Invalid logout request. Please try again.');
    header('Location: ' . APP_URL . '/index.php');
    exit;
}

// Clear PHP session
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();

// Clear Google's state cookies - more aggressive clearing
$googleCookies = ['G_ENABLED_IDPS', 'g_state', 'SID', 'HSID', 'SSID', 'APISID', 'SAPISID', '1P_JAR', 'NID', 'CONSENT'];
foreach ($googleCookies as $cookie) {
    if (isset($_COOKIE[$cookie])) {
        setcookie($cookie, '', time() - 3600, '/');
        setcookie($cookie, '', time() - 3600, '/.google.com');
        setcookie($cookie, '', time() - 3600, '/.google.co.in');
        unset($_COOKIE[$cookie]);
    }
}

// Clear all Google-related localStorage/sessionStorage via redirect with parameter
header('Location: ' . APP_URL . '/login.php?clear_google=1');
exit;
