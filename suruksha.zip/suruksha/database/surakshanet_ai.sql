CREATE DATABASE IF NOT EXISTS surakshanet_ai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE surakshanet_ai;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS live_notifications;
DROP TABLE IF EXISTS case_assignments;
DROP TABLE IF EXISTS response_history;
DROP TABLE IF EXISTS device_activity;
DROP TABLE IF EXISTS emergency_logs;
DROP TABLE IF EXISTS officer_tracking;
DROP TABLE IF EXISTS emergency_tracking;
DROP TABLE IF EXISTS live_locations;
DROP TABLE IF EXISTS email_logs;
DROP TABLE IF EXISTS authentication_logs;
DROP TABLE IF EXISTS sos_logs;
DROP TABLE IF EXISTS emergency_assignments;
DROP TABLE IF EXISTS officers;
DROP TABLE IF EXISTS officer_roles;
DROP TABLE IF EXISTS police_stations;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS missing_persons;
DROP TABLE IF EXISTS sos_alerts;
DROP TABLE IF EXISTS incidents;
DROP TABLE IF EXISTS police_officers;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    username VARCHAR(80) NOT NULL UNIQUE,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(30) NULL,
    password_hash VARCHAR(255) NULL,
    sos_pin_hash VARCHAR(255) NULL,
    google_sub VARCHAR(190) NULL UNIQUE,
    role ENUM('citizen','admin','dispatcher','super_admin','police_admin','station_incharge','officer','emergency_operator') NOT NULL DEFAULT 'citizen',
    profile_photo VARCHAR(500) NULL,
    auth_provider ENUM('local','google') NOT NULL DEFAULT 'local',
    account_status ENUM('active','suspended','pending') NOT NULL DEFAULT 'active',
    login_token VARCHAR(255) NULL,
    police_station_id INT UNSIGNED NULL,
    section VARCHAR(100) NULL,
    permissions TEXT NULL,
    is_verified TINYINT(1) NOT NULL DEFAULT 0,
    otp_code VARCHAR(10) NULL,
    otp_expires_at DATETIME NULL,
    reset_token_hash VARCHAR(255) NULL,
    reset_expires_at DATETIME NULL,
    reset_otp_code VARCHAR(255) NULL,
    reset_otp_expires_at DATETIME NULL,
    last_login_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_users_role (role),
    INDEX idx_users_email_verified (email, is_verified),
    INDEX idx_users_auth_provider (auth_provider)
);

CREATE TABLE police_officers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    badge_number VARCHAR(50) NOT NULL UNIQUE,
    phone VARCHAR(30) NOT NULL,
    rank_title VARCHAR(80) NOT NULL,
    station_name VARCHAR(160) NOT NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    status ENUM('available','assigned','off_duty') NOT NULL DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_officer_status (status)
);

CREATE TABLE incidents (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    officer_id INT UNSIGNED NULL,
    title VARCHAR(180) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(100) NOT NULL DEFAULT 'General Emergency',
    severity TINYINT UNSIGNED NOT NULL DEFAULT 3,
    status ENUM('submitted','verified','assigned','in_progress','resolved','rejected') NOT NULL DEFAULT 'submitted',
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    address VARCHAR(255) NULL,
    evidence_path VARCHAR(255) NULL,
    evidence_type ENUM('none','image','video') NOT NULL DEFAULT 'none',
    language VARCHAR(20) NOT NULL DEFAULT 'auto',
    is_spam TINYINT(1) NOT NULL DEFAULT 0,
    ai_summary VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (officer_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_incidents_status_severity (status, severity),
    INDEX idx_incidents_created (created_at),
    INDEX idx_incidents_location (latitude, longitude)
);

CREATE TABLE sos_alerts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    address VARCHAR(255) NULL,
    emergency_category VARCHAR(100) NOT NULL DEFAULT 'General Emergency',
    device_info VARCHAR(255) NULL,
    authenticated TINYINT(1) NOT NULL DEFAULT 0,
    auth_method VARCHAR(80) NULL,
    status ENUM('active','acknowledged','resolved','false_alarm') NOT NULL DEFAULT 'active',
    severity TINYINT UNSIGNED NOT NULL DEFAULT 5,
    ai_summary VARCHAR(255) NULL,
    live_status ENUM('ACTIVE','OFFLINE','RESPONDING','OFFICER_ASSIGNED','RESOLVED','FALSE_ALERT','EMERGENCY_CLOSED') NOT NULL DEFAULT 'ACTIVE',
    last_active_at DATETIME NULL,
    speed_kmh DECIMAL(8,2) NULL,
    movement_direction VARCHAR(60) NULL,
    battery_level TINYINT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sos_status_created (status, created_at),
    INDEX idx_sos_live_status (live_status),
    INDEX idx_sos_location (latitude, longitude)
);

CREATE TABLE missing_persons (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    full_name VARCHAR(140) NOT NULL,
    age INT UNSIGNED NULL,
    gender VARCHAR(30) NULL,
    last_seen_location VARCHAR(255) NOT NULL,
    last_seen_at DATETIME NULL,
    description TEXT NOT NULL,
    photo_path VARCHAR(255) NULL,
    status ENUM('submitted','searching','found','closed') NOT NULL DEFAULT 'submitted',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_missing_status (status)
);

CREATE TABLE notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    title VARCHAR(160) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info','warning','danger','success') NOT NULL DEFAULT 'info',
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notifications_user_read (user_id, is_read)
);

CREATE TABLE police_stations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(160) NOT NULL,
    district VARCHAR(100) NOT NULL,
    section VARCHAR(100) NOT NULL,
    email VARCHAR(190) NULL,
    phone VARCHAR(30) NULL,
    address VARCHAR(255) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_station_district_section (district, section)
);

CREATE TABLE officer_roles (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    permissions TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE officers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    police_station_id INT UNSIGNED NULL,
    officer_role_id INT UNSIGNED NULL,
    badge_number VARCHAR(50) NULL UNIQUE,
    section VARCHAR(100) NULL,
    status ENUM('available','assigned','off_duty') NOT NULL DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (police_station_id) REFERENCES police_stations(id) ON DELETE SET NULL,
    FOREIGN KEY (officer_role_id) REFERENCES officer_roles(id) ON DELETE SET NULL,
    INDEX idx_officers_status_station (status, police_station_id)
);

CREATE TABLE emergency_assignments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sos_alert_id INT UNSIGNED NULL,
    incident_id INT UNSIGNED NULL,
    officer_user_id INT UNSIGNED NULL,
    assigned_by INT UNSIGNED NULL,
    status ENUM('assigned','accepted','on_scene','resolved') NOT NULL DEFAULT 'assigned',
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE CASCADE,
    FOREIGN KEY (officer_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_assignments_status (status)
);

CREATE TABLE sos_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sos_alert_id INT UNSIGNED NULL,
    user_id INT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_sos_logs_created (created_at)
);

CREATE TABLE authentication_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    auth_context VARCHAR(80) NOT NULL,
    auth_method VARCHAR(80) NULL,
    success TINYINT(1) NOT NULL DEFAULT 0,
    device_info VARCHAR(255) NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_auth_logs_user_created (user_id, created_at)
);

CREATE TABLE email_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    recipient VARCHAR(190) NOT NULL,
    subject VARCHAR(190) NOT NULL,
    context VARCHAR(80) NOT NULL,
    related_type VARCHAR(50) NULL,
    related_id INT UNSIGNED NULL,
    sent TINYINT(1) NOT NULL DEFAULT 0,
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_logs_context (context, created_at)
);

CREATE TABLE live_locations (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sos_alert_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    accuracy DECIMAL(8,2) NULL,
    speed_kmh DECIMAL(8,2) NULL,
    movement_direction VARCHAR(60) NULL,
    battery_level TINYINT UNSIGNED NULL,
    is_online TINYINT(1) NOT NULL DEFAULT 1,
    device_info VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_live_locations_sos_created (sos_alert_id, created_at),
    INDEX idx_live_locations_user_created (user_id, created_at)
);

CREATE TABLE emergency_tracking (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sos_alert_id INT UNSIGNED NOT NULL,
    tracking_status ENUM('ACTIVE','OFFLINE','RESPONDING','OFFICER_ASSIGNED','RESOLVED','FALSE_ALERT','EMERGENCY_CLOSED') NOT NULL DEFAULT 'ACTIVE',
    last_latitude DECIMAL(10,7) NULL,
    last_longitude DECIMAL(10,7) NULL,
    route_json JSON NULL,
    last_active_at DATETIME NULL,
    possible_danger_zone VARCHAR(160) NULL,
    nearest_station_id INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    FOREIGN KEY (nearest_station_id) REFERENCES police_stations(id) ON DELETE SET NULL,
    INDEX idx_emergency_tracking_status (tracking_status)
);

CREATE TABLE officer_tracking (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    officer_user_id INT UNSIGNED NOT NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    speed_kmh DECIMAL(8,2) NULL,
    status ENUM('available','responding','on_scene','off_duty') NOT NULL DEFAULT 'available',
    last_active_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (officer_user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_officer_tracking_user_created (officer_user_id, created_at)
);

CREATE TABLE emergency_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sos_alert_id INT UNSIGNED NULL,
    user_id INT UNSIGNED NULL,
    actor_role VARCHAR(80) NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_emergency_logs_sos_created (sos_alert_id, created_at)
);

CREATE TABLE device_activity (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    sos_alert_id INT UNSIGNED NULL,
    status ENUM('ONLINE','OFFLINE','GPS_OFF','LOW_BATTERY','SUSPICIOUS') NOT NULL DEFAULT 'ONLINE',
    device_info VARCHAR(255) NULL,
    battery_level TINYINT UNSIGNED NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    INDEX idx_device_activity_user_created (user_id, created_at)
);

CREATE TABLE response_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sos_alert_id INT UNSIGNED NOT NULL,
    officer_user_id INT UNSIGNED NULL,
    action VARCHAR(100) NOT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    FOREIGN KEY (officer_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_response_history_sos_created (sos_alert_id, created_at)
);

CREATE TABLE case_assignments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sos_alert_id INT UNSIGNED NOT NULL,
    officer_user_id INT UNSIGNED NOT NULL,
    assigned_by INT UNSIGNED NOT NULL,
    status ENUM('ASSIGNED','ACCEPTED','EN_ROUTE','ON_SCENE','SAFE','CLOSED') NOT NULL DEFAULT 'ASSIGNED',
    eta_minutes INT UNSIGNED NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts(id) ON DELETE CASCADE,
    FOREIGN KEY (officer_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_case_assignments_officer_status (officer_user_id, status)
);

CREATE TABLE live_notifications (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    role_target VARCHAR(80) NULL,
    title VARCHAR(160) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info','warning','danger','success') NOT NULL DEFAULT 'info',
    related_type VARCHAR(50) NULL,
    related_id INT UNSIGNED NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_live_notifications_target_read (role_target, is_read, created_at),
    INDEX idx_live_notifications_user_read (user_id, is_read, created_at)
);

INSERT INTO users (name, username, email, password_hash, role, is_verified)
VALUES ('System Administrator', 'admin1001', 'admin@surakshanet.local', '$2y$10$h9FHH1SH97SUHa5IDehH3u6TzPJL9pQUv67w.ujmelqb.JtP9Ft5.', 'admin', 1);

INSERT INTO police_officers (name, badge_number, phone, rank_title, station_name, latitude, longitude)
VALUES
('Inspector Ramesh Shrestha', 'NP-1001', '9800000001', 'Inspector', 'Kathmandu Metropolitan Police', 27.7172453, 85.3239605),
('Sub Inspector Sita Thapa', 'NP-1002', '9800000002', 'Sub Inspector', 'Lalitpur Police Station', 27.6588000, 85.3247000);

INSERT INTO officer_roles (name, permissions) VALUES
('Super Admin', 'all'),
('Police Admin', 'station_manage,officer_manage,case_manage'),
('Station Incharge', 'officer_manage,case_manage'),
('Officer', 'case_view,case_update'),
('Emergency Operator', 'sos_manage,case_assign');

INSERT INTO police_stations (name, district, section, email, phone, address, latitude, longitude)
VALUES ('Kathmandu Metropolitan Police', 'Kathmandu', 'Emergency Response', 'admin@surakshanet.local', '100', 'Kathmandu, Nepal', 27.7172453, 85.3239605);
