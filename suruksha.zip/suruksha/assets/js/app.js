function getPlatformFromUA() {
    const ua = navigator.userAgent;
    if (ua.includes('Win64') || ua.includes('WOW64') || ua.includes('x64')) {
        return 'Windows 64-bit';
    } else if (ua.includes('Windows')) {
        return 'Windows 32-bit';
    } else if (ua.includes('Macintosh') || ua.includes('Mac OS X')) {
        return 'macOS';
    } else if (ua.includes('Linux')) {
        return 'Linux';
    } else if (ua.includes('Android')) {
        return 'Android';
    } else if (ua.includes('iPhone') || ua.includes('iPad') || ua.includes('iOS')) {
        return 'iOS';
    } else {
        return 'Unknown Platform';
    }
}

function initMap(elementId, markersUrl, options = {}) {
    const el = document.getElementById(elementId);
    if (!el || typeof L === 'undefined') return;
    const center = options.center || [27.7172, 85.3240];
    const map = L.map(elementId).setView(center, options.zoom || 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(map);
    
    const trackingStatus = document.getElementById('trackingStatus');
    if (trackingStatus) {
        trackingStatus.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Requesting location...';
    }
    
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            pos => {
                const userLatLng = [pos.coords.latitude, pos.coords.longitude];
                L.marker(userLatLng).addTo(map).bindPopup('Your live location');
                if (options.followUser) map.setView(userLatLng, 15);
                document.querySelectorAll('[name="latitude"]').forEach(i => i.value = pos.coords.latitude);
                document.querySelectorAll('[name="longitude"]').forEach(i => i.value = pos.coords.longitude);
                
                if (trackingStatus) {
                    trackingStatus.innerHTML = '<i class="fas fa-check-circle me-1 text-success"></i>Location captured successfully';
                }
            },
            error => {
                if (trackingStatus) {
                    trackingStatus.innerHTML = '<i class="fas fa-exclamation-triangle me-1 text-warning"></i>Location unavailable. Showing default location.';
                }
                console.error('Geolocation error:', error);
            },
            { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
        );
    } else {
        if (trackingStatus) {
            trackingStatus.innerHTML = '<i class="fas fa-exclamation-triangle me-1 text-warning"></i>Geolocation not supported';
        }
    }
    
    if (markersUrl) {
        fetch(markersUrl).then(r => r.json()).then(items => {
            items.forEach(item => {
                if (!item.latitude || !item.longitude) return;
                
                // Determine marker color based on type, severity, and status
                const color = getMarkerColor(item);
                
                // Create custom marker based on type
                let marker;
                if (item.type === 'sos') {
                    // SOS alerts get pulsing red markers
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 12,
                        color: color,
                        fillColor: color,
                        fillOpacity: 0.9,
                        weight: 3
                    }).addTo(map);
                } else if (item.type === 'station') {
                    // Police stations get blue markers
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 10,
                        color: '#0066cc',
                        fillColor: '#0066cc',
                        fillOpacity: 0.8,
                        weight: 2
                    }).addTo(map);
                } else if (item.type === 'officer') {
                    // Officers get green markers
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 8,
                        color: '#28a745',
                        fillColor: '#28a745',
                        fillOpacity: 0.8,
                        weight: 2
                    }).addTo(map);
                } else {
                    // Incidents get standard markers
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 10,
                        color: color,
                        fillColor: color,
                        fillOpacity: 0.8,
                        weight: 2
                    }).addTo(map);
                }
                
                // Create professional popup with detailed information
                const popupContent = createMarkerPopup(item);
                marker.bindPopup(popupContent);
            });
        });
    }
}

function getMarkerColor(item) {
    // SOS alerts - always red for emergencies
    if (item.type === 'sos') {
        if (item.live_status === 'OFFLINE') return '#6c757d'; // Gray for offline
        if (item.live_status === 'RESPONDING') return '#ffc107'; // Yellow for responding
        if (item.live_status === 'OFFICER_ASSIGNED') return '#17a2b8'; // Cyan for assigned
        return '#dc3545'; // Red for active
    }
    
    // Police stations - blue
    if (item.type === 'station') return '#0066cc';
    
    // Officers - green
    if (item.type === 'officer') return '#28a745';
    
    // Incidents - color by severity
    if (item.type === 'incident') {
        const severity = parseInt(item.severity) || 1;
        if (severity >= 5) return '#dc3545'; // Red - critical
        if (severity >= 4) return '#fd7e14'; // Orange - high
        if (severity >= 3) return '#ffc107'; // Yellow - medium
        return '#28a745'; // Green - low
    }
    
    return '#6c757d'; // Default gray
}

function createMarkerPopup(item) {
    let content = `<div style="min-width: 250px;">`;
    
    // Header with type icon
    const typeIcon = getTypeIcon(item.type);
    content += `<h5 style="margin: 0 0 10px 0; color: ${getMarkerColor(item)};">${typeIcon} ${item.title || 'Unknown'}</h5>`;
    
    // Citizen information (for incidents and SOS)
    if (item.citizen_name) {
        content += `<div style="margin-bottom: 8px;"><strong>Citizen:</strong> ${item.citizen_name}</div>`;
        if (item.citizen_phone) {
            content += `<div style="margin-bottom: 8px;"><strong>Phone:</strong> <a href="tel:${item.citizen_phone}" style="color: #0066cc;">${item.citizen_phone}</a></div>`;
        }
    }
    
    // Location details
    content += `<div style="margin-bottom: 8px;"><strong>GPS:</strong> ${item.latitude.toFixed(6)}, ${item.longitude.toFixed(6)}</div>`;
    if (item.address) {
        content += `<div style="margin-bottom: 8px;"><strong>Address:</strong> ${item.address}</div>`;
    }
    
    // Status and severity
    if (item.status) {
        content += `<div style="margin-bottom: 8px;"><strong>Status:</strong> <span style="color: ${getMarkerColor(item)}; font-weight: bold;">${item.status}</span></div>`;
    }
    if (item.live_status) {
        content += `<div style="margin-bottom: 8px;"><strong>Live Status:</strong> <span style="color: ${getMarkerColor(item)}; font-weight: bold;">${item.live_status}</span></div>`;
    }
    if (item.severity) {
        content += `<div style="margin-bottom: 8px;"><strong>Severity:</strong> ${item.severity}/5</div>`;
    }
    
    // Additional SOS details
    if (item.type === 'sos') {
        if (item.speed_kmh !== null) {
            content += `<div style="margin-bottom: 8px;"><strong>Speed:</strong> ${item.speed_kmh} km/h</div>`;
        }
        if (item.movement_direction) {
            content += `<div style="margin-bottom: 8px;"><strong>Direction:</strong> ${item.movement_direction}</div>`;
        }
        if (item.battery_level !== null) {
            content += `<div style="margin-bottom: 8px;"><strong>Battery:</strong> ${item.battery_level}%</div>`;
        }
    }
    
    // Category (for incidents)
    if (item.category) {
        content += `<div style="margin-bottom: 8px;"><strong>Category:</strong> ${item.category}</div>`;
    }
    
    // Timestamp
    if (item.created_at) {
        const date = new Date(item.created_at);
        content += `<div style="margin-bottom: 8px;"><strong>Time:</strong> ${date.toLocaleString()}</div>`;
    }
    
    // District/Section (for stations)
    if (item.district) {
        content += `<div style="margin-bottom: 8px;"><strong>District:</strong> ${item.district}</div>`;
    }
    if (item.section) {
        content += `<div style="margin-bottom: 8px;"><strong>Section:</strong> ${item.section}</div>`;
    }
    
    // View on OpenStreetMap link
    content += `<div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #ddd;">
        <a href="https://www.openstreetmap.org/?mlat=${item.latitude}&mlon=${item.longitude}#map=17/${item.latitude}/${item.longitude}" 
           target="_blank" style="color: #0066cc; text-decoration: none;">
            <i class="fas fa-external-link-alt"></i> View on OpenStreetMap
        </a>
    </div>`;
    
    content += `</div>`;
    return content;
}

function getTypeIcon(type) {
    switch(type) {
        case 'sos': return '<i class="fas fa-exclamation-triangle"></i>';
        case 'incident': return '<i class="fas fa-file-alt"></i>';
        case 'station': return '<i class="fas fa-building"></i>';
        case 'officer': return '<i class="fas fa-user-shield"></i>';
        default: return '<i class="fas fa-map-marker-alt"></i>';
    }
}

function handleGoogleCredential(response) {
    fetch('api/google_login.php', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({credential: response.credential}) })
        .then(r => r.json()).then(data => { if (data.redirect) location.href = data.redirect; else alert(data.message || 'Google login failed'); });
}

async function verifyDeviceForSos() {
    // Check if user has SOS PIN set
    const checkRes = await fetch('../api/check_sos_pin.php');
    const checkData = await checkRes.json();
    
    if (!checkData.has_pin) {
        // Redirect to security page to set SOS PIN
        window.location.href = '../citizen/security.php';
        return { ok: false, method: 'SOS PIN', secret: '' };
    }
    
    // Show professional PIN entry modal
    return new Promise((resolve) => {
        const modalHtml = `
            <div class="modal fade" id="sosPinModal" tabindex="-1" data-bs-backdrop="static">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content" style="background: rgba(10, 22, 40, 0.95); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 20px;">
                        <div class="modal-header border-0">
                            <h5 class="modal-title text-white"><i class="fas fa-shield-alt me-2"></i>Enter SOS PIN</h5>
                        </div>
                        <div class="modal-body">
                            <p class="text-white-50 mb-4">Enter your SOS PIN to confirm emergency alert</p>
                            <div class="mb-3">
                                <input type="password" class="form-control text-center" id="sosPinInput" 
                                    placeholder="Enter PIN" maxlength="8" style="font-size: 24px; letter-spacing: 8px; background: rgba(0, 0, 0, 0.4); border: 2px solid rgba(59, 130, 246, 0.5); color: #ffffff; padding: 12px;">
                            </div>
                            <div id="pinError" class="text-danger small mb-3"></div>
                        </div>
                        <div class="modal-footer border-0">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="confirmPinBtn">Confirm & Send SOS</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if any
        const existingModal = document.getElementById('sosPinModal');
        if (existingModal) existingModal.remove();
        
        // Add modal to body
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        
        const modal = new bootstrap.Modal(document.getElementById('sosPinModal'));
        modal.show();
        
        const pinInput = document.getElementById('sosPinInput');
        const confirmBtn = document.getElementById('confirmPinBtn');
        const pinError = document.getElementById('pinError');
        
        pinInput.focus();
        
        // Allow only numbers
        pinInput.addEventListener('input', (e) => {
            e.target.value = e.target.value.replace(/[^0-9]/g, '');
        });
        
        // Handle confirm button
        confirmBtn.addEventListener('click', () => {
            const pin = pinInput.value.trim();
            if (pin.length < 4) {
                pinError.textContent = 'PIN must be at least 4 digits';
                return;
            }
            modal.hide();
            resolve({ ok: true, method: 'SOS PIN', secret: pin });
        });
        
        // Handle cancel
        document.getElementById('sosPinModal').addEventListener('hidden.bs.modal', () => {
            if (!confirmBtn.disabled) {
                resolve({ ok: false, method: 'SOS PIN', secret: '' });
            }
        });
        
        // Allow Enter key to submit
        pinInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                confirmBtn.click();
            }
        });
    });
}

function setupSecureSos() {
    const btn = document.getElementById('secureSosBtn');
    if (!btn) return;
    btn.addEventListener('click', async () => {
        const message = document.getElementById('sosMessage');
        btn.disabled = true;
        message.innerHTML = '<span class="text-warning">Checking device PIN/fingerprint...</span>';
        const auth = await verifyDeviceForSos();
        if (!auth.ok) {
            message.innerHTML = '<span class="text-danger">PIN/password is required. SOS was not sent.</span>';
            btn.disabled = false;
            return;
        }
        message.innerHTML = '<span class="text-info">Capturing live GPS...</span>';
        navigator.geolocation.getCurrentPosition(async pos => {
            message.innerHTML = '<span class="text-info">Verifying PIN/password and sending SOS...</span>';
            const battery = await getBatteryLevel();
            const payload = {
                csrf_token: btn.dataset.csrf,
                auth_method: auth.method,
                sos_secret: auth.secret,
                emergency_category: document.getElementById('sosCategory').value,
                latitude: pos.coords.latitude,
                longitude: pos.coords.longitude,
                accuracy: pos.coords.accuracy,
                battery_level: battery,
                device_info: `${getPlatformFromUA()} | ${navigator.userAgent}`.slice(0, 255)
            };
            const res = await fetch('../api/submit_sos.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
            const data = await res.json();
            if (data.success) startCitizenLiveTracking(data.id, btn.dataset.csrf);
            message.innerHTML = data.success ? `<span class="text-danger fw-bold">${data.message} Case #${data.id}. Live tracking active.</span>` : `<span class="text-danger">${data.message}</span>`;
            btn.disabled = false;
        }, async (error) => {
            // GPS permission denied or unavailable - proceed with warning
            message.innerHTML = '<span class="text-warning">GPS unavailable. Sending SOS without location...</span>';
            const battery = await getBatteryLevel();
            const payload = {
                csrf_token: btn.dataset.csrf,
                auth_method: auth.method,
                sos_secret: auth.secret,
                emergency_category: document.getElementById('sosCategory').value,
                latitude: '',
                longitude: '',
                accuracy: null,
                battery_level: battery,
                device_info: `${getPlatformFromUA()} | ${navigator.userAgent}`.slice(0, 255)
            };
            const res = await fetch('../api/submit_sos.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
            const data = await res.json();
            message.innerHTML = data.success ? `<span class="text-danger fw-bold">${data.message} Case #${data.id}. Location not captured.</span>` : `<span class="text-danger">${data.message}</span>`;
            btn.disabled = false;
        }, { enableHighAccuracy: true, timeout: 12000 });
    });
}

function showEmergencyConfirmModal(pos) {
    const modalEl = document.getElementById('sosConfirmModal');
    const details = document.getElementById('sosConfirmDetails');
    if (!modalEl || !details) return Promise.resolve(confirm('Confirm emergency alert?'));
    const root = document.querySelector('[data-citizen-name]');
    const category = document.getElementById('sosCategory').value;
    details.innerHTML = `<div class="text-white"><p><strong>Citizen:</strong> ${root.dataset.citizenName}</p><p><strong>Phone:</strong> ${root.dataset.citizenPhone || 'Not provided'}</p><p><strong>Location:</strong> ${pos.coords.latitude.toFixed(6)}, ${pos.coords.longitude.toFixed(6)}</p><p><strong>Category:</strong> ${category}</p><p><strong>Time:</strong> ${new Date().toLocaleString()}</p><p><strong>Evidence:</strong> No evidence attached for SOS.</p></div>`;
    const modal = new bootstrap.Modal(modalEl);
    modal.show();
    return new Promise(resolve => {
        document.getElementById('confirmEmergencyBtn').onclick = () => { modal.hide(); resolve(true); };
        document.getElementById('cancelEmergencyBtn').onclick = () => { modal.hide(); resolve(false); };
    });
}

async function getBatteryLevel() {
    if (!navigator.getBattery) return null;
    try {
        const battery = await navigator.getBattery();
        return Math.round(battery.level * 100);
    } catch {
        return null;
    }
}

function startCitizenLiveTracking(sosId, csrf) {
    const status = document.getElementById('trackingStatus');
    const sendPing = async pos => {
        const battery = await getBatteryLevel();
        const payload = {
            csrf_token: csrf,
            sos_alert_id: sosId,
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            battery_level: battery,
            device_info: `${getPlatformFromUA()} | ${navigator.userAgent}`.slice(0, 255)
        };
        const res = await fetch('../api/location_ping.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
        const data = await res.json();
        if (status) status.textContent = data.success ? `Tracking active. Citizen moving ${data.direction} at ${data.speed_kmh || 0} km/h. Last updated ${new Date().toLocaleTimeString()}` : 'Tracking update failed.';
    };
    navigator.geolocation.watchPosition(sendPing, () => {
        if (status) status.textContent = 'GPS inactive or permission lost. Police will see OFFLINE warning.';
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 });
}

function setupLivePoliceAlerts(url) {
    const popup = document.getElementById('liveAlertPopup');
    const text = document.getElementById('liveAlertText');
    const feed = document.getElementById('liveSosFeed');
    const metric = document.getElementById('activeSosMetric');
    const timer = document.getElementById('responseTimer');
    if (!popup || !text) return;
    let latestId = null;
    let latestCreated = null;
    const beep = () => {
        const audio = new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=');
        audio.play().catch(() => {});
    };
    const renderTimer = () => {
        if (!latestCreated || !timer) return;
        const seconds = Math.max(0, Math.floor((Date.now() - new Date(latestCreated.replace(' ', 'T')).getTime()) / 1000));
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;
        timer.textContent = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    };
    setInterval(renderTimer, 1000);
    const poll = async () => {
        try {
            const res = await fetch(url, { cache: 'no-store' });
            const data = await res.json();
            const alerts = data.alerts || [];
            if (metric) metric.textContent = alerts.length;
            if (feed) {
                feed.innerHTML = alerts.map(a => `<div class="alert alert-danger alert-strip"><strong>${a.citizen_name}</strong> ${a.phone || ''}<br><small>${a.created_at} | ${a.emergency_category} | Severity ${a.severity}/5</small><br><a class="btn btn-sm btn-light mt-2" target="_blank" href="https://www.openstreetmap.org/?mlat=${a.latitude}&mlon=${a.longitude}#map=17/${a.latitude}/${a.longitude}">Live Location</a></div>`).join('') || '<div class="text-white-50">No active SOS alerts.</div>';
            }
            if (alerts[0] && alerts[0].id !== latestId) {
                latestId = alerts[0].id;
                latestCreated = alerts[0].created_at;
                text.innerHTML = `<strong>${alerts[0].citizen_name}</strong> triggered ${alerts[0].emergency_category}. Severity ${alerts[0].severity}/5. Phone: ${alerts[0].phone ? `<a href="tel:${alerts[0].phone}" class="text-danger text-decoration-none fw-bold">${alerts[0].phone}</a>` : 'N/A'}`;
                popup.classList.remove('d-none');
                beep();
            }
        } catch (error) {
            console.error('Live alert polling failed', error);
        }
    };
    poll();
    setInterval(poll, 5000);
}

let commandState = { map: null, miniMap: null, selected: null, csrf: null, layers: [] };

function setupCommandCenter(csrf) {
    commandState.csrf = csrf;
    commandState.map = L.map('commandMap').setView([27.7172, 85.3240], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(commandState.map);
    pollCommandCenter();
    setInterval(pollCommandCenter, 4000);
}

async function pollCommandCenter() {
    const res = await fetch('../api/command_center_data.php', { cache: 'no-store' });
    const data = await res.json();
    commandState.layers.forEach(layer => commandState.map.removeLayer(layer));
    commandState.layers = [];
    const alerts = data.alerts || [];
    document.getElementById('ccActive').textContent = alerts.length;
    document.getElementById('ccOffline').textContent = alerts.filter(a => a.live_status === 'OFFLINE').length;
    document.getElementById('ccResponding').textContent = alerts.filter(a => a.live_status === 'RESPONDING').length;
    document.getElementById('ccAssigned').textContent = alerts.filter(a => a.live_status === 'OFFICER_ASSIGNED').length;
    renderCommandFeed(alerts);
    [...alerts, ...(data.stations || []), ...(data.officers || [])].forEach(item => renderCommandMarker(item));
    alerts.forEach(alert => renderAlertPath(alert));
}

function markerColor(item) {
    if (item.live_status === 'RESOLVED' || item.status === 'resolved') return 'green';
    if ((parseInt(item.severity || '1') >= 4) || item.live_status === 'ACTIVE') return 'red';
    return 'orange';
}

function renderCommandMarker(item) {
    if (!item.latitude || !item.longitude) return;
    const color = markerColor(item);
    const marker = L.circleMarker([item.latitude, item.longitude], { radius: 9, color, fillColor: color, fillOpacity: 0.85 }).addTo(commandState.map);
    marker.bindPopup(`<strong>${item.citizen_name || item.name || item.title || 'Emergency'}</strong><br>${item.live_status || item.status || ''}<br>${item.latitude}, ${item.longitude}`);
    commandState.layers.push(marker);
}

function renderAlertPath(alert) {
    if (!alert.path || alert.path.length < 2) return;
    const points = alert.path.map(p => [p.latitude, p.longitude]);
    const line = L.polyline(points, { color: markerColor(alert), weight: 4, opacity: 0.75 }).addTo(commandState.map);
    commandState.layers.push(line);
}

function renderCommandFeed(alerts) {
    const feed = document.getElementById('commandFeed');
    feed.innerHTML = alerts.map(a => `<div class="alert alert-danger alert-strip command-feed-item" onclick="openAdminEmergency(${a.id})"><strong>Case #${a.id}</strong> ${a.citizen_name}<br><small>${a.emergency_category} | ${a.live_status} | ${a.movement_direction || 'Unknown direction'} at ${a.speed_kmh || 0} km/h</small></div>`).join('') || '<div class="text-white-50">No active emergencies.</div>';
    window.latestCommandAlerts = alerts;
}

function openAdminEmergency(id) {
    const alert = (window.latestCommandAlerts || []).find(a => parseInt(a.id) === parseInt(id));
    if (!alert) return;
    commandState.selected = alert;
    const details = document.getElementById('adminEmergencyDetails');
    details.innerHTML = `<div class="text-white"><div class="d-flex gap-3 align-items-center mb-3"><div class="citizen-avatar">${(alert.citizen_name || 'C').charAt(0)}</div><div><h4>${alert.citizen_name}</h4><div>${alert.phone || 'No phone'}</div></div></div><p><strong>Emergency:</strong> ${alert.emergency_category}</p><p><strong>Severity:</strong> ${alert.severity}/5</p><p><strong>Coordinates:</strong> ${alert.latitude}, ${alert.longitude}</p><p><strong>Station:</strong> ${alert.nearest_station || 'Nearest station pending'}</p><p><strong>Status:</strong> ${alert.live_status}</p><p><strong>Movement:</strong> Citizen moving ${alert.movement_direction || 'unknown'} at ${alert.speed_kmh || 0} km/h</p><p><strong>Battery:</strong> ${alert.battery_level || 'N/A'}%</p><p><strong>Timestamp:</strong> ${alert.created_at}</p></div>`;
    document.getElementById('callCitizenBtn').href = `tel:${alert.phone || ''}`;
    document.getElementById('viewLiveMapBtn').href = `https://www.openstreetmap.org/?mlat=${alert.latitude}&mlon=${alert.longitude}#map=17/${alert.latitude}/${alert.longitude}`;
    const modal = new bootstrap.Modal(document.getElementById('adminEmergencyModal'));
    modal.show();
    setTimeout(() => renderMiniMap(alert), 300);
}

function renderMiniMap(alert) {
    if (commandState.miniMap) commandState.miniMap.remove();
    commandState.miniMap = L.map('modalMiniMap').setView([alert.latitude, alert.longitude], 16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(commandState.miniMap);
    L.marker([alert.latitude, alert.longitude]).addTo(commandState.miniMap).bindPopup('Citizen live location').openPopup();
    if (alert.path && alert.path.length > 1) L.polyline(alert.path.map(p => [p.latitude, p.longitude]), { color: 'red' }).addTo(commandState.miniMap);
}

async function commandCaseAction(action) {
    if (!commandState.selected) return;
    const res = await fetch('../api/case_action.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ csrf_token: commandState.csrf, sos_alert_id: commandState.selected.id, action }) });
    const data = await res.json();
    alert(data.message || 'Updated');
    pollCommandCenter();
}

async function assignSelectedOfficer() {
    if (!commandState.selected) return;
    const officerId = document.getElementById('assignOfficerSelect').value;
    const res = await fetch('../api/assign_case.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ csrf_token: commandState.csrf, sos_alert_id: commandState.selected.id, officer_user_id: officerId }) });
    const data = await res.json();
    alert(data.message || 'Assignment updated');
    pollCommandCenter();
}

function startOfficerTracking(csrf) {
    const status = document.getElementById('officerTrackingStatus');
    if (!navigator.geolocation) {
        status.textContent = 'Geolocation is not supported on this device.';
        return;
    }
    navigator.geolocation.watchPosition(async pos => {
        const payload = { csrf_token: csrf, latitude: pos.coords.latitude, longitude: pos.coords.longitude, speed_kmh: pos.coords.speed ? Math.round(pos.coords.speed * 3.6) : null, status: 'responding' };
        await fetch('../api/officer_location.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
        status.textContent = `Officer tracking active. Last update ${new Date().toLocaleTimeString()}`;
    }, () => {
        status.textContent = 'Officer GPS permission denied or unavailable.';
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 });
}

async function officerCaseUpdate(sosId, status, csrf) {
    const notes = prompt('Response notes', '') || '';
    const res = await fetch('../api/officer_case_update.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ csrf_token: csrf, sos_alert_id: sosId, status, notes }) });
    const data = await res.json();
    alert(data.message || 'Updated');
    location.reload();
}
