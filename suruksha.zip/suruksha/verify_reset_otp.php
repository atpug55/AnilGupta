<?php
require_once __DIR__ . '/includes/helpers.php';

$email = strtolower(trim($_GET['email'] ?? ''));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $otp = trim($_POST['otp'] ?? '');
    
    // Validate OTP
    $stmt = db()->prepare('SELECT id, reset_otp_code, reset_otp_expires_at FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) {
        flash('danger', 'Email not found in database. Please check and try again.');
        header('Location: ' . APP_URL . '/forgot_password.php');
        exit;
    }
    
    if (!$user['reset_otp_code']) {
        flash('danger', 'No OTP found in database for this email. Please request a new OTP.');
        header('Location: ' . APP_URL . '/forgot_password.php?email=' . urlencode($email));
        exit;
    }
    
    if (strtotime($user['reset_otp_expires_at']) < time()) {
        flash('danger', 'OTP expired at: ' . $user['reset_otp_expires_at'] . '. Please request a new OTP.');
        header('Location: ' . APP_URL . '/forgot_password.php?email=' . urlencode($email));
        exit;
    }
    
    if (!password_verify($otp, $user['reset_otp_code'])) {
        flash('danger', 'Invalid OTP..Check?');
        header('Location: ' . APP_URL . '/verify_reset_otp.php?email=' . urlencode($email));
        exit;
    }
    
    // OTP is valid, redirect to reset password page
    header('Location: ' . APP_URL . '/reset_password.php?email=' . urlencode($email) . '&verified=1');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP - SurakshaNet AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            position: relative;
        }
        
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="0.5"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
            pointer-events: none;
            z-index: 0;
        }
        
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            z-index: 1;
        }
        
        .auth-card {
            background: linear-gradient(145deg, rgba(255, 255, 255, 0.95) 0%, rgba(240, 245, 255, 0.95) 100%);
            border-radius: 16px;
            padding: 0;
            max-width: 1100px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.1);
            animation: fadeInUp 0.7s ease-out;
            overflow: hidden;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .auth-illustration {
            background: linear-gradient(135deg, #003366 0%, #004080 50%, #0052a3 100%);
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            min-height: 550px;
            position: relative;
            overflow: hidden;
        }
        
        .auth-illustration::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        }
        
        .auth-illustration::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -30%;
            width: 80%;
            height: 80%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
        }
        
        .police-badge {
            width: 140px;
            height: 140px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4a 50%, #ffd700 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.5);
            position: relative;
            z-index: 2;
            animation: badgeGlow 3s ease-in-out infinite;
        }
        
        @keyframes badgeGlow {
            0%, 100% { box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.5), 0 0 20px rgba(255, 215, 0, 0.3); }
            50% { box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.5), 0 0 40px rgba(255, 215, 0, 0.5); }
        }
        
        .police-badge i {
            font-size: 60px;
            color: #003366;
        }
        
        .auth-illustration h2 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 15px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 2;
        }
        
        .auth-illustration p {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 30px;
            position: relative;
            z-index: 2;
        }
        
        .police-features {
            display: flex;
            flex-direction: column;
            gap: 15px;
            position: relative;
            z-index: 2;
        }
        
        .police-feature {
            display: flex;
            align-items: center;
            gap: 12px;
            background: rgba(255, 255, 255, 0.1);
            padding: 12px 20px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .police-feature i {
            color: #ffd700;
            font-size: 18px;
        }
        
        .police-feature span {
            font-size: 14px;
            font-weight: 500;
        }
        
        .auth-form {
            padding: 50px 45px;
            background: white;
        }
        
        .auth-header {
            text-align: center;
            margin-bottom: 35px;
        }
        
        .auth-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            font-size: 26px;
            font-weight: 700;
            color: #003366;
            margin-bottom: 10px;
        }
        
        .auth-logo i {
            color: #dc2626;
            font-size: 32px;
        }
        
        .auth-subtitle {
            color: #64748b;
            font-size: 15px;
            margin-bottom: 0;
        }
        
        .form-label {
            color: #374151;
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        .form-control {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            padding: 14px 18px;
            color: #1e293b;
            font-size: 15px;
            transition: all 0.3s ease;
            text-align: center;
            font-size: 24px;
            letter-spacing: 8px;
        }
        
        .form-control:focus {
            background: white;
            border-color: #003366;
            box-shadow: 0 0 0 4px rgba(0, 51, 102, 0.1);
            color: #1e293b;
        }
        
        .form-control::placeholder {
            color: #94a3b8;
            letter-spacing: normal;
            font-size: 16px;
        }
        
        .input-group-text {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-right: none;
            color: #64748b;
            transition: all 0.3s ease;
        }
        
        .input-group .form-control {
            border-left: none;
        }
        
        .input-group:focus-within .input-group-text,
        .input-group:focus-within .form-control {
            border-color: #003366;
        }
        
        .input-group:focus-within .input-group-text {
            box-shadow: 0 0 0 4px rgba(0, 51, 102, 0.1);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #003366 0%, #004080 100%);
            border: none;
            border-radius: 10px;
            padding: 14px 28px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #004080 0%, #0052a3 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 51, 102, 0.3);
        }
        
        .btn-primary:active {
            transform: translateY(0);
        }
        
        .btn-link {
            color: #003366;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        .btn-link:hover {
            color: #0052a3;
        }
        
        .auth-links {
            margin-top: 25px;
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }
        
        .auth-links p {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        .auth-links a {
            color: #003366;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        .auth-links a:hover {
            color: #0052a3;
        }
        
        @media (max-width: 991px) {
            .auth-card {
                max-width: 500px;
            }
            
            .auth-illustration {
                display: none;
            }
            
            .auth-form {
                padding: 40px 30px;
            }
        }
        
        @media (max-width: 576px) {
            .auth-form {
                padding: 30px 20px;
            }
            
            .auth-logo {
                font-size: 22px;
            }
            
            .police-badge {
                width: 100px;
                height: 100px;
            }
            
            .police-badge i {
                font-size: 45px;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="row g-0">
                <div class="col-lg-6">
                    <div class="auth-illustration">
                        <div class="police-badge">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h2 class="mb-3">Verify OTP</h2>
                        <p class="mb-4">Secure your password reset process</p>
                        <div class="police-features">
                            <div class="police-feature">
                                <i class="fas fa-envelope"></i>
                                <span>Email Verification</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-clock"></i>
                                <span>Time-Sensitive OTP</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-lock"></i>
                                <span>Secure Authentication</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-user-shield"></i>
                                <span>Account Protection</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="auth-form">
                        <div class="auth-header">
                            <div class="auth-logo">
                                <i class="fas fa-shield-halved"></i> SurakshaNet
                            </div>
                            <p class="auth-subtitle">Enter the 6-digit OTP sent to your email</p>
                            <?php if ($email): ?>
                                <p class="text-muted small mb-0">OTP sent to: <?= e($email) ?></p>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (isset($_SESSION['flash']) && isset($_SESSION['flash']['message'])): ?>
                            <?php 
                                $flashType = $_SESSION['flash']['type'];
                                $flashMessage = $_SESSION['flash']['message'];
                                unset($_SESSION['flash']);
                            ?>
                        <?php endif; ?>
                        
                        <form method="post">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            <input type="hidden" name="email" value="<?= e($email) ?>">
                            
                            <div class="mb-4">
                                <label class="form-label">Enter OTP</label>
                                <input type="text" class="form-control" name="otp" placeholder="000000" required pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code">
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 mb-3">
                                <i class="fas fa-check me-2"></i>Verify OTP
                            </button>
                        </form>
                        
                        <div class="auth-links">
                            <p>Didn't receive OTP?</p>
                            <a href="forgot_password.php?email=<?= e($email) ?>&resend=1&csrf_token=<?= csrf_token() ?>" class="btn-link">Resend OTP</a>
                        </div>
                        
                        <div class="auth-links mt-3">
                            <a href="login.php">Back to Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Flash Message Modal -->
    <div class="modal fade" id="flashModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title" id="flashModalTitle">Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="flashModalBody">
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto-focus OTP input
        document.addEventListener('DOMContentLoaded', function() {
            const otpInput = document.querySelector('input[name="otp"]');
            if (otpInput) {
                otpInput.focus();
            }
        });
        
        // Allow only numbers
        document.querySelector('input[name="otp"]').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
        
        // Show flash message in modal
        <?php if (isset($flashType) && isset($flashMessage)): ?>
            document.addEventListener('DOMContentLoaded', function() {
                const modal = new bootstrap.Modal(document.getElementById('flashModal'));
                const modalTitle = document.getElementById('flashModalTitle');
                const modalBody = document.getElementById('flashModalBody');
                
                modalTitle.textContent = '<?= $flashType === 'danger' ? 'Error' : 'Notification' ?>';
                modalBody.textContent = '<?= e($flashMessage) ?>';
                
                modal.show();
                
                // Auto-hide after 3 seconds
                setTimeout(function() {
                    modal.hide();
                }, 3000);
            });
        <?php endif; ?>
        
        // Prevent browser back button
        history.pushState(null, null, location.href);
        window.onpopstate = function() {
            history.go(1);
            window.location.href = 'forgot_password.php';
        };
    </script>
</body>
</html>
