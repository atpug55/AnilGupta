# SurakshaNet AI

Production-ready PHP 8 + MySQL emergency management system for police command centers and citizens.

## Features

- Email signup/login with OTP verification
- Google One Tap login integration point
- Forgot password and secure sessions
- Citizen SOS, crime reporting, missing person reporting, evidence upload
- Police admin command dashboard with live OpenStreetMap markers
- Gemini AI incident categorization, severity scoring, Nepali-English support, spam filtering
- Officer assignment, status management, notifications, analytics metrics
- PDO prepared statements, password hashing, CSRF protection, secure upload validation

## Installation on XAMPP

1. Put this folder at `c:\xampp\htdocs\suruksha`.
2. Start Apache and MySQL from XAMPP Control Panel.
3. Open phpMyAdmin and import `database/surakshanet_ai.sql`.
4. Copy `.env.example` values into your server environment or edit `config/config.php` defaults for local testing.
5. Install PHPMailer if Composer is available:

```bash
composer install
```

6. Open `http://localhost/suruksha`.

## Default Admin

- Email: `admin@surakshanet.local`
- Password: `Admin@12345`

Change this password immediately after first deployment.

## API Keys

Set these environment variables in production:

- `GEMINI_API_KEY` for Gemini AI analysis
- `GOOGLE_CLIENT_ID` for Google One Tap
- `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM` for OTP/password emails

## Production Hardening

- Serve over HTTPS only.
- Move secrets out of source code and into environment variables.
- Restrict `/uploads` execution; `.htaccess` is included for Apache.
- Configure a cron job or queue worker if high-volume notifications are added.
- Use a dedicated MySQL user with least privilege.
- Keep PHP, Composer packages, Apache, and MySQL updated.

## Folder Structure

- `admin/` police dashboard and command actions
- `api/` JSON endpoints for maps and Google login
- `assets/` CSS and JavaScript
- `citizen/` citizen portal flows
- `config/` app and database configuration
- `database/` SQL schema
- `includes/` shared helpers, mailer, AI, upload security
- `uploads/` evidence storage
