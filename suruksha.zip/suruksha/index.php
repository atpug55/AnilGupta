<?php 
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/config/google-config.php';
require_once __DIR__ . '/includes/header.php'; 

// Don't redirect logged-in users from homepage - allow them to view it
?>

<!-- Professional Homepage Redesign -->
<style>
/* Homepage-specific styles */
.homepage-hero {
    min-height: 100vh;
    background: linear-gradient(135deg, rgba(7, 27, 58, 0.97), rgba(8, 60, 120, 0.95)), 
                url('https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&w=1920&q=80') center/cover;
    position: relative;
    overflow: hidden;
}

.homepage-hero::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 20% 50%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 50%, rgba(220, 38, 38, 0.1) 0%, transparent 50%);
    pointer-events: none;
}

.typing-text {
    border-right: 3px solid #ffd700;
    animation: blink 0.7s infinite;
}

@keyframes blink {
    0%, 100% { border-color: #ffd700; }
    50% { border-color: transparent; }
}

.stats-card {
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 30px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.stats-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, #3b82f6, #ffd700, #dc2626);
}

.stats-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
    border-color: rgba(255, 215, 0, 0.3);
}

.feature-card {
    background: rgba(255, 255, 255, 0.03);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 16px;
    padding: 35px 25px;
    transition: all 0.4s ease;
    position: relative;
    overflow: hidden;
}

.feature-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, transparent 50%);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.feature-card:hover::before {
    opacity: 1;
}

.feature-card:hover {
    transform: translateY(-8px);
    border-color: rgba(59, 130, 246, 0.4);
    box-shadow: 0 15px 35px rgba(59, 130, 246, 0.2);
}

.feature-icon {
    width: 70px;
    height: 70px;
    background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%);
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    color: white;
    margin-bottom: 20px;
    transition: all 0.3s ease;
}

.feature-card:hover .feature-icon {
    transform: scale(1.1) rotate(5deg);
    box-shadow: 0 10px 25px rgba(59, 130, 246, 0.4);
}

.police-section {
    background: linear-gradient(135deg, #071b3a 0%, #0d2a57 100%);
    position: relative;
    overflow: hidden;
}

.police-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&w=1920&q=80') center/cover;
    opacity: 0.05;
}

.service-card {
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(15px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    padding: 30px;
    transition: all 0.3s ease;
    text-align: center;
}

.service-card:hover {
    transform: translateY(-5px);
    border-color: rgba(255, 215, 0, 0.3);
    background: rgba(255, 255, 255, 0.08);
}

.service-icon {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #ffd700 0%, #f59e0b 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: #071b3a;
    margin: 0 auto 20px;
}

.command-center-preview {
    background: linear-gradient(135deg, #0a1628 0%, #1a365d 100%);
    border: 2px solid rgba(59, 130, 246, 0.3);
    border-radius: 20px;
    padding: 40px;
    position: relative;
    overflow: hidden;
}

.command-center-preview::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at 50% 50%, rgba(59, 130, 246, 0.1) 0%, transparent 70%);
}

.map-placeholder {
    background: linear-gradient(135deg, #1a365d 0%, #0d2137 100%);
    border: 2px solid rgba(59, 130, 246, 0.3);
    border-radius: 16px;
    height: 350px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}

.map-placeholder::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=800&q=80') center/cover;
    opacity: 0.3;
}

.alert-card {
    background: rgba(220, 38, 38, 0.1);
    border: 1px solid rgba(220, 38, 38, 0.3);
    border-radius: 12px;
    padding: 15px;
    margin-bottom: 15px;
    animation: alertPulse 2s infinite;
}

@keyframes alertPulse {
    0%, 100% { border-color: rgba(220, 38, 38, 0.3); }
    50% { border-color: rgba(220, 38, 38, 0.6); }
}

.safety-tip-card {
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    padding: 25px;
    transition: all 0.3s ease;
}

.safety-tip-card:hover {
    transform: translateX(10px);
    border-color: rgba(34, 197, 94, 0.3);
    background: rgba(34, 197, 94, 0.05);
}

.trust-badge {
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
    transition: all 0.3s ease;
}

.trust-badge:hover {
    transform: scale(1.05);
    border-color: rgba(255, 215, 0, 0.3);
}

.footer-section {
    background: linear-gradient(135deg, #071b3a 0%, #0a1628 100%);
    border-top: 3px solid #ffd700;
}

.footer-link {
    color: rgba(255, 255, 255, 0.7);
    text-decoration: none;
    transition: all 0.3s ease;
    display: block;
    padding: 8px 0;
}

.footer-link:hover {
    color: #ffd700;
    padding-left: 10px;
}

.social-icon {
    width: 45px;
    height: 45px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    transition: all 0.3s ease;
    margin-right: 10px;
}

.social-icon:hover {
    background: #ffd700;
    color: #071b3a;
    transform: translateY(-5px);
}

/* Floating animation for hero elements */
.float-animation {
    animation: float 6s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
}

/* Glow effect for emergency elements */
.glow-effect {
    animation: glow 2s ease-in-out infinite;
}

@keyframes glow {
    0%, 100% { box-shadow: 0 0 20px rgba(220, 38, 38, 0.5); }
    50% { box-shadow: 0 0 40px rgba(220, 38, 38, 0.8); }
}

/* Counter animation */
.counter {
    font-size: 3rem;
    font-weight: 800;
    background: linear-gradient(135deg, #ffd700 0%, #f59e0b 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .sos-button {
        width: 140px;
        height: 140px;
        font-size: 2rem;
    }
    
    .counter {
        font-size: 2rem;
    }
    
    .feature-card {
        padding: 25px 20px;
    }
}
</style>

<!-- Hero Section -->
<section class="homepage-hero d-flex align-items-center" id="home">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7">
                <div class="mb-4">
                    <span class="badge bg-warning text-dark px-4 py-2 fw-bold rounded-pill">
                        <i class="fas fa-shield-alt me-2"></i>Nepal Police Emergency Intelligence Platform
                    </span>
                </div>
                <h1 class="display-3 fw-bold mb-4 text-white">
                    SurakshaNet - AI <br>
                    <span class="typing-text" id="typingText">Public Safety</span>
                </h1>
                <p class="lead text-white-50 mb-5 fs-5">
                    Advanced emergency response system powered by artificial intelligence. 
                    Report incidents, trigger SOS alerts, and help police prioritize emergencies with real-time AI analysis.
                </p>
                <div class="d-flex gap-3 flex-wrap mb-5">
                    <a href="register.php" class="btn btn-gradient btn-lg fw-bold px-5 py-3">
                        <i class="fas fa-user-plus me-2"></i>Get Started
                    </a>
                    <a href="login.php" class="btn btn-glass btn-lg fw-bold px-5 py-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Login
                    </a>
                    <button class="btn btn-glass btn-lg fw-bold px-5 py-3" data-bs-toggle="modal" data-bs-target="#onetapLoginModal" style="color: white; background: linear-gradient(135deg, #991b1b 0%, #7f1d1d 100%); border: 2px solid #b91c1c;">
                        <i class="fas fa-sign-in-alt me-2"></i>One Tap Login
                    </button>
                </div>
                <div class="row g-4 mt-3">
                    <div class="col-6 col-md-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <span class="text-white-50">AI Detection</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <span class="text-white-50">Live Tracking</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <span class="text-white-50">24/7 Support</span>
                        </div>
                    </div>
                    <div class="col-6 col-md-3">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <span class="text-white-50">Secure Platform</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card hero-card text-dark p-4">
                    <h4 class="fw-bold">Emergency Capabilities</h4>
                    <ul class="list-unstyled mt-3">
                        <li class="mb-2">✅ One-tap SOS with live location</li>
                        <li class="mb-2">✅ Gemini AI categorization and spam detection</li>
                        <li class="mb-2">✅ OpenStreetMap incident monitoring</li>
                        <li class="mb-2">✅ Officer assignment and status tracking</li>
                        <br>
                    </ul>
            </div>
        </div>
    </div>
</section>



<!-- System Features Section -->
<section class="py-5 police-section" id="features">
    <div class="container position-relative">
        <div class="text-center mb-5">
            <span class="badge bg-warning text-dark px-4 py-2 rounded-pill mb-3">Advanced Features</span>
            <h2 class="display-5 fw-bold text-white mb-3">AI-Powered Emergency System</h2>
            <p class="text-white-50 lead">Cutting-edge technology for modern public safety</p>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-brain"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">AI Incident Detection</h5>
                    <p class="text-white-50 mb-0">Advanced AI algorithms automatically categorize and prioritize emergency reports</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-satellite"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">Real-Time GPS Tracking</h5>
                    <p class="text-white-50 mb-0">Live location tracking for rapid emergency response and officer deployment</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-desktop"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">Live Police Dashboard</h5>
                    <p class="text-white-50 mb-0">Real-time command center with interactive maps and incident monitoring</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">Emergency Email Alerts</h5>
                    <p class="text-white-50 mb-0">Instant notifications to citizens and authorities during emergencies</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">Missing Person Tracking</h5>
                    <p class="text-white-50 mb-0">Dedicated system for reporting and tracking missing persons</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">Secure Authentication</h5>
                    <p class="text-white-50 mb-0">Multi-factor authentication and encrypted data protection</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-sort-amount-up"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">Smart Prioritization</h5>
                    <p class="text-white-50 mb-0">AI-powered severity scoring for intelligent incident prioritization</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-bell"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-3">Real-Time Notifications</h5>
                    <p class="text-white-50 mb-0">Instant alerts and updates for all emergency situations</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Nepal Police Services Section -->
<section class="py-5" style="background: linear-gradient(135deg, #071b3a 0%, #0d2a57 100%);">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-warning text-dark px-4 py-2 rounded-pill mb-3">Nepal Police Services</span>
            <h2 class="display-5 fw-bold text-white mb-3">Emergency Services & Safety</h2>
            <p class="text-white-50 lead">Comprehensive public safety and emergency response services</p>
        </div>
        <div class="row g-4">
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-hand-holding-heart"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">Public Safety</h5>
                    <p class="text-white-50 small mb-0">Community safety programs and awareness campaigns</p>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">Emergency Helpline</h5>
                    <p class="text-white-50 small mb-0">24/7 emergency response and support services</p>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-laptop"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">Cyber Crime</h5>
                    <p class="text-white-50 small mb-0">Digital crime prevention and investigation</p>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-female"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">Women & Child Safety</h5>
                    <p class="text-white-50 small mb-0">Specialized protection and support services</p>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-house-damage"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">Disaster Response</h5>
                    <p class="text-white-50 small mb-0">Emergency preparedness and disaster management</p>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-user-friends"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">Missing Persons</h5>
                    <p class="text-white-50 mb-0">Missing person reporting and tracking system</p>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-traffic-light"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">Traffic Safety</h5>
                    <p class="text-white-50 small mb-0">Road safety enforcement and accident prevention</p>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-robot"></i>
                    </div>
                    <h5 class="text-white fw-bold mb-2">AI Monitoring</h5>
                    <p class="text-white-50 small mb-0">AI-powered surveillance and threat detection</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Command Center Preview Section -->
<section class="py-5" style="background: linear-gradient(135deg, #0a1628 0%, #1a365d 100%);">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-warning text-dark px-4 py-2 rounded-pill mb-3">Live Preview</span>
            <h2 class="display-5 fw-bold text-white mb-3">Command Center Dashboard</h2>
            <p class="text-white-50 lead">Real-time emergency monitoring and response coordination</p>
        </div>
        <div class="command-center-preview">
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="map-placeholder">
                        <div class="text-center position-relative z-1">
                            <i class="fas fa-map-marked-alt text-white mb-3" style="font-size: 4rem;"></i>
                            <h4 class="text-white fw-bold">Interactive Emergency Map</h4>
                            <p class="text-white-50">Real-time incident tracking and officer deployment</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <h5 class="text-white fw-bold mb-3">
                        <i class="fas fa-bell text-danger me-2"></i>Active Alerts
                    </h5>
                    <div class="alert-card">
                        <div class="d-flex align-items-center">
                            <div class="bg-danger rounded-circle p-2 me-3">
                                <i class="fas fa-exclamation text-white"></i>
                            </div>
                            <div>
                                <h6 class="text-white fw-bold mb-1">Emergency Report</h6>
                                <p class="text-white-50 small mb-0">Kathmandu - High Priority</p>
                            </div>
                        </div>
                    </div>
                    <div class="alert-card">
                        <div class="d-flex align-items-center">
                            <div class="bg-warning rounded-circle p-2 me-3">
                                <i class="fas fa-exclamation text-dark"></i>
                            </div>
                            <div>
                                <h6 class="text-white fw-bold mb-1">Traffic Incident</h6>
                                <p class="text-white-50 small mb-0">Pokhara - Medium Priority</p>
                            </div>
                        </div>
                    </div>
                    <div class="alert-card">
                        <div class="d-flex align-items-center">
                            <div class="bg-info rounded-circle p-2 me-3">
                                <i class="fas fa-info text-white"></i>
                            </div>
                            <div>
                                <h6 class="text-white fw-bold mb-1">Missing Person</h6>
                                <p class="text-white-50 small mb-0">Lalitpur - Low Priority</p>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Safety Awareness Section -->
<section class="py-5 police-section" id="awareness">
    <div class="container position-relative">
        <div class="text-center mb-5">
            <span class="badge bg-warning text-dark px-4 py-2 rounded-pill mb-3">Citizen Awareness</span>
            <h2 class="display-5 fw-bold text-white mb-3">Safety Tips & Guidelines</h2>
            <p class="text-white-50 lead">Stay informed and stay safe with our expert safety guidelines</p>
        </div>
        <div class="row g-4">
            <div class="col-md-6">
                <div class="safety-tip-card">
                    <div class="d-flex align-items-start">
                        <div class="bg-success rounded-circle p-3 me-3">
                            <i class="fas fa-phone text-white"></i>
                        </div>
                        <div>
                            <h5 class="text-white fw-bold mb-2">Emergency Contacts</h5>
                            <p class="text-white-50 mb-0">Save emergency numbers: Police 100, Fire 101, Ambulance 102. Keep them accessible at all times.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="safety-tip-card">
                    <div class="d-flex align-items-start">
                        <div class="bg-primary rounded-circle p-3 me-3">
                            <i class="fas fa-shield-alt text-white"></i>
                        </div>
                        <div>
                            <h5 class="text-white fw-bold mb-2">Cyber Safety</h5>
                            <p class="text-white-50 mb-0">Protect your personal information online. Use strong passwords and enable two-factor authentication.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="safety-tip-card">
                    <div class="d-flex align-items-start">
                        <div class="bg-warning rounded-circle p-3 me-3">
                            <i class="fas fa-female text-dark"></i>
                        </div>
                        <div>
                            <h5 class="text-white fw-bold mb-2">Women Safety</h5>
                            <p class="text-white-50 mb-0">Stay aware of your surroundings. Use trusted transportation and share your location with family.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="safety-tip-card">
                    <div class="d-flex align-items-start">
                        <div class="bg-danger rounded-circle p-3 me-3">
                            <i class="fas fa-first-aid text-white"></i>
                        </div>
                        <div>
                            <h5 class="text-white fw-bold mb-2">Disaster Preparedness</h5>
                            <p class="text-white-50 mb-0">Have an emergency kit ready. Know evacuation routes and emergency shelter locations.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Trust & Testimonials Section -->
<section class="py-5" style="background: linear-gradient(135deg, #071b3a 0%, #0d2a57 100%);">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-warning text-dark px-4 py-2 rounded-pill mb-3">Trust & Security</span>
            <h2 class="display-5 fw-bold text-white mb-3">Why Trust SurakshaNet AI</h2>
            <p class="text-white-50 lead">Built with security and reliability at its core</p>
        </div>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="trust-badge">
                    <i class="fas fa-lock text-warning mb-3" style="font-size: 2rem;"></i>
                    <h5 class="text-white fw-bold mb-2">End-to-End Encryption</h5>
                    <p class="text-white-50 small mb-0">Your data is protected with military-grade encryption</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="trust-badge">
                    <i class="fas fa-certificate text-warning mb-3" style="font-size: 2rem;"></i>
                    <h5 class="text-white fw-bold mb-2">Police Certified</h5>
                    <p class="text-white-50 small mb-0">Officially partnered with Nepal Police</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="trust-badge">
                    <i class="fas fa-clock text-warning mb-3" style="font-size: 2rem;"></i>
                    <h5 class="text-white fw-bold mb-2">24/7 Monitoring</h5>
                    <p class="text-white-50 small mb-0">Round-the-clock emergency response system</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="trust-badge">
                    <i class="fas fa-users text-warning mb-3" style="font-size: 2rem;"></i>
                    <h5 class="text-white fw-bold mb-2">Community Trusted</h5>
                    <p class="text-white-50 small mb-0">Trusted by thousands of citizens nationwide</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- onetap Login Modal -->
<div class="modal fade" id="onetapLoginModal" tabindex="-1" data-bs-backdrop="static" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: rgba(10, 22, 40, 0.95); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 24px;">
            <div class="modal-header border-0">
                <h5 class="modal-title text-white"><i class="fas fa-shield-alt me-2"></i>One Tap Login</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="text-white-50 mb-4 text-center" style="border: 1px solid rgba(59, 130, 246, 0.3); padding: 10px; border-radius: 10px; color: #3b82f6 !important;">Sign in to your account for fast access</p>
                
                <div id="emergencyFlashContainer"></div>
                
                <div id="googleSignInButton" class="d-flex justify-content-center"></div>
                <br>
            </div>
        </div>
    </div>
</div>

<style>
.modal-backdrop {
    backdrop-filter: blur(20px) !important;
    -webkit-backdrop-filter: blur(20px) !important;
    background-color: rgba(0, 0, 0, 0.7) !important;
}
</style>

<script>
// Typing animation
const typingTexts = ['Public Safety', 'Emergency Response', 'Crime Prevention', 'Citizen Protection'];
let textIndex = 0;
let charIndex = 0;
let isDeleting = false;

function typeText() {
    const currentText = typingTexts[textIndex];
    const typingElement = document.getElementById('typingText');
    
    if (isDeleting) {
        typingElement.textContent = currentText.substring(0, charIndex - 1);
        charIndex--;
    } else {
        typingElement.textContent = currentText.substring(0, charIndex + 1);
        charIndex++;
    }
    
    if (!isDeleting && charIndex === currentText.length) {
        isDeleting = true;
        setTimeout(typeText, 2000);
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        textIndex = (textIndex + 1) % typingTexts.length;
        setTimeout(typeText, 500);
    } else {
        setTimeout(typeText, isDeleting ? 50 : 100);
    }
}

// Counter animation
function animateCounters() {
    const counters = document.querySelectorAll('.counter');
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-target'));
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const updateCounter = () => {
            current += step;
            if (current < target) {
                counter.textContent = Math.floor(current).toLocaleString();
                requestAnimationFrame(updateCounter);
            } else {
                counter.textContent = target.toLocaleString();
            }
        };
        
        updateCounter();
    });
}

// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Initialize animations when page loads
window.addEventListener('load', () => {
    typeText();
    
    // Intersection Observer for counter animation
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounters();
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    const statsSection = document.querySelector('.stats-card');
    if (statsSection) {
        observer.observe(statsSection.parentElement);
    }
});

// Google login handler
function handleGoogleCredential(response) {
    fetch('api/google_login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ credential: response.credential })
    })
    .then(r => r.json())
    .then(data => {
        if (data.redirect) {
            window.location.href = data.redirect;
        } else {
            const flashContainer = document.getElementById('emergencyFlashContainer');
            flashContainer.innerHTML = '<div class="alert alert-danger">' + (data.message || 'Google login failed') + '</div>';
        }
    })
    .catch(err => {
        console.error('Google login error:', err);
        const flashContainer = document.getElementById('emergencyFlashContainer');
        flashContainer.innerHTML = '<div class="alert alert-danger">Google login failed. Please try again.</div>';
    });
}

<?php if (GOOGLE_CLIENT_ID): ?>
window.onload = function() {
    const client_id = '<?= e(GOOGLE_CLIENT_ID) ?>';
    if (!client_id) {
        return;
    }
    
    google.accounts.id.initialize({
        client_id: client_id,
        callback: handleGoogleCredential,
        auto_select: false,
        itp_support: true,
        ux_mode: 'popup',
        prompt_parent_id: 'googleSignInButton'
    });
    
    google.accounts.id.renderButton(
        document.getElementById('googleSignInButton'),
        {
            theme: 'outline',
            size: 'large',
            type: 'standard',
            text: 'signin_with',
            shape: 'rectangular',
            logo_alignment: 'left',
            width: '360',
            locale: 'en',
            click_listener: function() {
                return true;
            }
        }
    );
};
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
