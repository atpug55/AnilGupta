<?php
require_once __DIR__ . '/../includes/helpers.php';
require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $allowed = ['acknowledged','resolved','false_alarm'];
    $status = in_array($_POST['status'] ?? '', $allowed, true) ? $_POST['status'] : 'acknowledged';
    
    // Get old status for comparison
    $oldSos = db()->prepare('SELECT status, user_id, emergency_category FROM sos_alerts WHERE id = ?');
    $oldSos->execute([(int)$_POST['id']]);
    $oldData = $oldSos->fetch();
    
    // Update SOS status
    db()->prepare('UPDATE sos_alerts SET status=? WHERE id=?')->execute([$status, (int)$_POST['id']]);
    
    // Add notification for citizen if status changed
    if ($oldData && $oldData['status'] !== $status) {
        $statusMessages = [
            'acknowledged' => 'Your SOS has been acknowledged by authorities',
            'resolved' => 'Your SOS has been resolved',
            'false_alarm' => 'Your SOS was marked as false alarm'
        ];
        
        $message = $statusMessages[$status] ?? "Your SOS status has been updated to: $status";
        
        db()->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)')
            ->execute([$oldData['user_id'], "SOS Status Updated: " . e($oldData['emergency_category']), $message, $status === 'resolved' ? 'success' : ($status === 'false_alarm' ? 'warning' : 'info')]);
    }
    
    flash('success', 'SOS status updated. Citizen has been notified.');
}
redirect('admin/dashboard.php');
