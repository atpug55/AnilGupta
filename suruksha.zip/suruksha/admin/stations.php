<?php
require_once __DIR__ . '/../includes/helpers.php';
require_role(['admin','super_admin','police_admin']);
$sections = ['Cyber Bureau','Traffic Police','Women Cell','Emergency Response','Crime Investigation','Missing Persons','Disaster Management'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $stmt = db()->prepare('INSERT INTO police_stations (name, district, section, email, phone, address, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([trim($_POST['name']), trim($_POST['district']), $_POST['section'], trim($_POST['email']), trim($_POST['phone']), trim($_POST['address']), $_POST['latitude'] ?: null, $_POST['longitude'] ?: null]);
    flash('success', 'Police station created.');
    redirect('admin/stations.php');
}

$stations = db()->query('SELECT * FROM police_stations ORDER BY created_at DESC')->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Police Stations Management</h2>
                <small class="text-white-50">Manage police stations across Nepal</small>
            </div>
            <a class="btn btn-admin-primary" href="dashboard.php">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>

        <!-- Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-building fa-2x text-primary"></i>
                        </div>
                        <div>
                            <div class="metric"><?= count($stations) ?></div>
                            <small class="text-white-50">Total Stations</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-map-marker-alt fa-2x text-info"></i>
                        </div>
                        <div>
                            <div class="metric"><?= count(array_unique(array_column($stations, 'district'))) ?></div>
                            <small class="text-white-50">Districts Covered</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-users fa-2x text-success"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM officers WHERE police_station_id IS NOT NULL")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Assigned Officers</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-file-alt fa-2x text-warning"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM incidents WHERE officer_id IS NOT NULL")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Cases Handled</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Create Station Form -->
        <div class="admin-card p-4 mb-4">
            <h4 class="fw-bold mb-3"><i class="fas fa-plus-circle me-2 text-success"></i>Add New Police Station</h4>
            <form method="post" class="row g-3">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <div class="col-md-4">
                    <label class="form-label">Station Name</label>
                    <input class="form-control form-control-admin" name="name" placeholder="Station name" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">District</label>
                    <input class="form-control form-control-admin" name="district" placeholder="District" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Section</label>
                    <select class="form-select form-select-admin" name="section">
                        <?php foreach ($sections as $section): ?>
                            <option><?= e($section) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Email</label>
                    <input class="form-control form-control-admin" type="email" name="email" placeholder="Station email">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Phone</label>
                    <input class="form-control form-control-admin" name="phone" placeholder="Phone">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Address</label>
                    <input class="form-control form-control-admin" name="address" placeholder="Address">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Latitude</label>
                    <input class="form-control form-control-admin" name="latitude" placeholder="Latitude">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Longitude</label>
                    <input class="form-control form-control-admin" name="longitude" placeholder="Longitude">
                </div>
                <div class="col-md-4">
                    <label class="form-label">&nbsp;</label>
                    <button class="btn btn-admin-success w-100">
                        <i class="fas fa-plus me-2"></i>Create Station
                    </button>
                </div>
            </form>
        </div>

        <!-- Stations Table -->
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0"><i class="fas fa-list me-2 text-primary"></i>All Police Stations</h4>
                <span class="badge bg-info"><?= count($stations) ?> Total</span>
            </div>
            
            <div class="table-responsive">
                <table class="table table-admin table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>District</th>
                            <th>Section</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>Coordinates</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($stations as $s): ?>
                            <tr>
                                <td>
                                    <strong><?= e($s['name']) ?></strong>
                                </td>
                                <td><?= e($s['district']) ?></td>
                                <td>
                                    <span class="badge bg-info"><?= e($s['section']) ?></span>
                                </td>
                                <td><?= e($s['email'] ?? '-') ?></td>
                                <td><?= e($s['phone'] ?? '-') ?></td>
                                <td><?= e(substr($s['address'] ?? '-', 0, 30)) ?>...</td>
                                <td>
                                    <?php if ($s['latitude'] && $s['longitude']): ?>
                                        <small><?= e($s['latitude']) ?>, <?= e($s['longitude']) ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= date('M d, Y', strtotime($s['created_at'])) ?></td>
                                <td>
                                    <button class="btn btn-sm btn-danger" onclick="showDeleteStationModal(<?= $s['id'] ?>, '<?= e($s['name']) ?>')">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Delete Station PIN Modal -->
<div class="modal fade" id="deleteStationModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: rgba(10, 22, 40, 0.95); border: 1px solid rgba(220, 53, 69, 0.3); border-radius: 20px;">
            <div class="modal-header border-0">
                <h5 class="modal-title text-white"><i class="fas fa-shield-alt me-2 text-danger"></i>Confirm Deletion</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="text-white-50 mb-3">Enter your admin PIN to delete this police station:</p>
                <p class="text-white fw-bold mb-3" id="deleteStationName"></p>
                <div class="mb-3">
                    <input type="password" class="form-control text-center" id="deleteStationPin" 
                        placeholder="Enter PIN" maxlength="8" style="font-size: 24px; letter-spacing: 8px; background: rgba(0, 0, 0, 0.4); border: 2px solid rgba(220, 53, 69, 0.5); color: #ffffff; padding: 12px;">
                </div>
                <div id="deleteStationError" class="text-danger small mb-3"></div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteStationBtn">Delete Station</button>
            </div>
        </div>
    </div>
</div>

<!-- Success Alert -->
<div id="deleteSuccessAlert" class="alert alert-success position-fixed" style="top: 20px; right: 20px; z-index: 9999; display: none;">
    <i class="fas fa-check-circle me-2"></i>Station deleted successfully!
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    let stationToDelete = null;

    window.showDeleteStationModal = function(stationId, stationName) {
        stationToDelete = stationId;
        document.getElementById('deleteStationName').textContent = stationName;
        document.getElementById('deleteStationPin').value = '';
        document.getElementById('deleteStationError').textContent = '';
        const modal = new bootstrap.Modal(document.getElementById('deleteStationModal'));
        modal.show();
    };

    document.getElementById('confirmDeleteStationBtn').addEventListener('click', async () => {
    const pin = document.getElementById('deleteStationPin').value.trim();
    const errorDiv = document.getElementById('deleteStationError');
    
    if (pin.length < 4) {
        errorDiv.textContent = 'PIN must be at least 4 digits';
        return;
    }
    
    try {
        console.log('Deleting station:', stationToDelete, 'with PIN:', pin);
        const res = await fetch('../api/delete_station.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                csrf_token: '<?= csrf_token() ?>',
                station_id: stationToDelete,
                pin: pin
            })
        });
        const data = await res.json();
        console.log('Response:', data);
        
        if (data.success) {
            bootstrap.Modal.getInstance(document.getElementById('deleteStationModal')).hide();
            const successAlert = document.getElementById('deleteSuccessAlert');
            successAlert.style.display = 'block';
            setTimeout(() => {
                successAlert.style.display = 'none';
                location.reload();
            }, 2000);
        } else {
            errorDiv.textContent = data.message || 'Deletion failed';
        }
    } catch (error) {
        errorDiv.textContent = 'Error deleting station';
    }
});

document.getElementById('deleteStationPin').addEventListener('input', (e) => {
    e.target.value = e.target.value.replace(/[^0-9]/g, '');
});

document.getElementById('deleteStationPin').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        document.getElementById('confirmDeleteStationBtn').click();
    }
});
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
