<?php
require_once __DIR__ . '/../includes/helpers.php';
require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);
$officers = db()->query("SELECT id, name, phone, section FROM users WHERE role IN ('officer','station_incharge','emergency_operator') ORDER BY name")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Live Emergency Command Center</h2>
                <small class="text-white-50">Real-time SOS tracking, response actions, officer assignment, and movement analysis</small>
            </div>
            <a class="btn btn-admin-primary" href="dashboard.php">
                <i class="fas fa-arrow-left me-2"></i>Dashboard
            </a>
        </div>

        <!-- Metrics Row -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="metric-icon metric-icon-danger me-3">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div>
                            <div class="text-white-50 small">Active SOS</div>
                            <div class="fw-bold fs-4" id="ccActive">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="metric-icon metric-icon-warning me-3">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div>
                            <div class="text-white-50 small">Responding</div>
                            <div class="fw-bold fs-4" id="ccResponding">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="metric-icon metric-icon-info me-3">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div>
                            <div class="text-white-50 small">Officer Assigned</div>
                            <div class="fw-bold fs-4" id="ccAssigned">0</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="metric-icon metric-icon-secondary me-3">
                            <i class="fas fa-power-off"></i>
                        </div>
                        <div>
                            <div class="text-white-50 small">Offline</div>
                            <div class="fw-bold fs-4" id="ccOffline">0</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="row g-4">
            <!-- Map Column -->
            <div class="col-lg-8">
                <div class="admin-card p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold mb-0"><i class="fas fa-map-marked-alt me-2 text-primary"></i>Live Map</h4>
                        <div class="d-flex gap-2">
                            <button class="btn btn-sm btn-outline-light" onclick="refreshMap()">
                                <i class="fas fa-sync-alt me-1"></i>Refresh
                            </button>
                            <button class="btn btn-sm btn-outline-light" onclick="fitMapBounds()">
                                <i class="fas fa-expand me-1"></i>Fit View
                            </button>
                        </div>
                    </div>

                    <!-- Map Legend -->
                    <div class="mb-3 p-2" style="background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <small class="text-white-50 fw-bold mb-2 d-block">Legend:</small>
                        <div class="d-flex flex-wrap gap-3">
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #dc3545;"></span>
                                <small class="text-white-50">SOS Active</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #ffc107;"></span>
                                <small class="text-white-50">SOS Responding</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #17a2b8;"></span>
                                <small class="text-white-50">Officer Assigned</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #6c757d;"></span>
                                <small class="text-white-50">Offline</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #fd7e14;"></span>
                                <small class="text-white-50">High Severity</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #0066cc;"></span>
                                <small class="text-white-50">Police Station</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #28a745;"></span>
                                <small class="text-white-50">Officer</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Map Filters -->
                    <div class="mb-3">
                        <div class="d-flex flex-wrap gap-2">
                            <button class="btn btn-sm btn-outline-light filter-btn active" data-filter="all" onclick="filterMapMarkers('all')">
                                <i class="fas fa-layer-group me-1"></i>All
                            </button>
                            <button class="btn btn-sm btn-outline-danger filter-btn" data-filter="sos" onclick="filterMapMarkers('sos')">
                                <i class="fas fa-exclamation-triangle me-1"></i>SOS
                            </button>
                            <button class="btn btn-sm btn-outline-warning filter-btn" data-filter="incident" onclick="filterMapMarkers('incident')">
                                <i class="fas fa-file-alt me-1"></i>Incidents
                            </button>
                            <button class="btn btn-sm btn-outline-info filter-btn" data-filter="station" onclick="filterMapMarkers('station')">
                                <i class="fas fa-building me-1"></i>Stations
                            </button>
                            <button class="btn btn-sm btn-outline-success filter-btn" data-filter="officer" onclick="filterMapMarkers('officer')">
                                <i class="fas fa-user-shield me-1"></i>Officers
                            </button>
                        </div>
                    </div>
                    
                    <!-- Map Status -->
                    <div id="mapStatus" class="mb-2 text-white-50 small">
                        <i class="fas fa-spinner fa-spin me-1"></i>Loading map...
                    </div>
                    
                    <div id="commandMap" style="height: 500px; border-radius: 8px;"></div>
                </div>
            </div>

            <!-- Feed Column -->
            <div class="col-lg-4">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-stream me-2 text-primary"></i>Live Feed</h4>
                    <div id="commandFeed" class="command-feed">
                        <div class="text-white-50 text-center py-4">Loading live feed...</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Emergency Details Modal -->
    <div class="modal fade" id="adminEmergencyModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content" style="background: rgba(10, 22, 40, 0.95); border: 1px solid rgba(59, 130, 246, 0.3); border-radius: 20px;">
                <div class="modal-header border-0">
                    <h5 class="modal-title text-white"><i class="fas fa-exclamation-triangle me-2"></i>Emergency Details</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="adminEmergencyDetails"></div>
                    <div id="modalMiniMap" style="height: 250px; margin-top: 15px; border-radius: 8px;"></div>
                </div>
                <div class="modal-footer border-0">
                    <a id="callCitizenBtn" href="#" class="btn btn-success"><i class="fas fa-phone me-1"></i>Call Citizen</a>
                    <a id="viewLiveMapBtn" href="#" target="_blank" class="btn btn-info"><i class="fas fa-map-marker-alt me-1"></i>View Live Map</a>
                    <button type="button" class="btn btn-warning" onclick="commandCaseAction('responding')"><i class="fas fa-clock me-1"></i>Mark Responding</button>
                    <button type="button" class="btn btn-primary" onclick="commandCaseAction('officer_assigned')"><i class="fas fa-user-shield me-1"></i>Assign Officer</button>
                    <button type="button" class="btn btn-success" onclick="commandCaseAction('resolved')"><i class="fas fa-check me-1"></i>Resolve</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Don't call initMap from app.js - we have our own map initialization
document.addEventListener('DOMContentLoaded', () => {
    setupCommandCenter();
});

let commandState = { map: null, markers: [], currentFilter: 'all' };

function setupCommandCenter() {
    // Initialize map
    try {
        if (typeof L === 'undefined') {
            console.error('Leaflet library not loaded');
            document.getElementById('mapStatus').innerHTML = '<i class="fas fa-exclamation-triangle me-1 text-danger"></i>Leaflet library not loaded';
            return;
        }
        
        const mapContainer = document.getElementById('commandMap');
        if (!mapContainer) {
            console.error('Map container not found');
            document.getElementById('mapStatus').innerHTML = '<i class="fas fa-exclamation-triangle me-1 text-danger"></i>Map container not found';
            return;
        }
        
        console.log('Initializing map...');
        commandState.map = L.map('commandMap').setView([27.7172, 85.3240], 12);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' }).addTo(commandState.map);
        console.log('Map initialized successfully');
        
        document.getElementById('mapStatus').innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Loading real-time data...';
        
        // Load real markers immediately
        refreshMap();
    } catch (error) {
        console.error('Error initializing map:', error);
        document.getElementById('mapStatus').innerHTML = '<i class="fas fa-exclamation-triangle me-1 text-danger"></i>Error: ' + error.message;
    }

    // Update metrics
    setInterval(() => {
        fetch('../api/command_metrics.php')
            .then(r => r.json())
            .then(data => {
                document.getElementById('ccActive').textContent = data.active || 0;
                document.getElementById('ccOffline').textContent = data.offline || 0;
                document.getElementById('ccResponding').textContent = data.responding || 0;
                document.getElementById('ccAssigned').textContent = data.assigned || 0;
            })
            .catch(err => console.error('Error fetching metrics:', err));
    }, 5000);

    // Live feed updates
    setInterval(() => {
        fetch('../api/live_feed.php')
            .then(r => r.json())
            .then(data => {
                const feed = document.getElementById('commandFeed');
                if (Array.isArray(data) && data.length > 0) {
                    feed.innerHTML = data.map(item => `
                        <div class="command-feed-item" onclick="showEmergencyModal(${item.id})">
                            <div class="d-flex align-items-start">
                                <div class="citizen-avatar me-3">
                                    ${item.name.charAt(0)}
                                </div>
                                <div class="flex-grow-1">
                                    <div class="d-flex justify-content-between">
                                        <strong>${item.name}</strong>
                                        <span class="badge bg-${item.status === 'active' ? 'danger' : 'success'}">
                                            ${item.status}
                                        </span>
                                    </div>
                                    <small class="text-white-50">${item.phone}</small>
                                    <div class="small mt-1">
                                        <i class="fas fa-clock me-1"></i>${item.time}
                                        <span class="ms-2">
                                            <i class="fas fa-fire me-1"></i>Severity ${item.severity}/5
                                        </span>
                                    </div>
                                    <div class="mt-2">
                                        <span class="badge bg-warning">${item.category}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('');
                } else {
                    feed.innerHTML = '<div class="text-white-50 text-center py-4">No active emergencies</div>';
                }
            })
            .catch(err => console.error('Error fetching live feed:', err));
    }, 10000);

    // Auto-refresh map markers every 15 seconds
    setInterval(() => {
        refreshMap();
    }, 15000);
}

function filterMapMarkers(filterType) {
    commandState.currentFilter = filterType;
    
    // Update button states
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === filterType) {
            btn.classList.add('active');
        }
    });
    
    // Refresh map with filter
    refreshMap();
}

function refreshMap() {
    if (!commandState.map) {
        console.error('Map not initialized');
        return;
    }
    
    const statusEl = document.getElementById('mapStatus');
    if (statusEl) {
        statusEl.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Refreshing map...';
    }
    
    console.log('Refreshing map with filter:', commandState.currentFilter);
    
    // Clear existing markers
    commandState.markers.forEach(marker => commandState.map.removeLayer(marker));
    commandState.markers = [];
    
    // Fetch markers
    fetch('../api/map_markers.php')
        .then(r => r.json())
        .then(items => {
            console.log('Received markers:', items.length);
            console.log('Markers data:', items);
            
            if (!Array.isArray(items)) {
                console.error('Invalid markers data:', items);
                if (statusEl) {
                    statusEl.innerHTML = '<i class="fas fa-exclamation-triangle me-1 text-danger"></i>Error loading markers';
                }
                return;
            }
            
            let addedCount = 0;
            items.forEach(item => {
                console.log('Processing item:', item.type, item.latitude, item.longitude);
                
                // Apply filter
                if (commandState.currentFilter !== 'all' && item.type !== commandState.currentFilter) {
                    console.log('Filtered out:', item.type);
                    return;
                }
                
                if (!item.latitude || !item.longitude) {
                    console.warn('Skipping item without coordinates:', item);
                    return;
                }
                
                const color = getMarkerColor(item);
                let marker;
                
                if (item.type === 'sos') {
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 12,
                        color: color,
                        fillColor: color,
                        fillOpacity: 0.9,
                        weight: 3
                    }).addTo(commandState.map);
                } else if (item.type === 'station') {
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 10,
                        color: '#0066cc',
                        fillColor: '#0066cc',
                        fillOpacity: 0.8,
                        weight: 2
                    }).addTo(commandState.map);
                } else if (item.type === 'officer') {
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 8,
                        color: '#28a745',
                        fillColor: '#28a745',
                        fillOpacity: 0.8,
                        weight: 2
                    }).addTo(commandState.map);
                } else {
                    marker = L.circleMarker([item.latitude, item.longitude], {
                        radius: 10,
                        color: color,
                        fillColor: color,
                        fillOpacity: 0.8,
                        weight: 2
                    }).addTo(commandState.map);
                }
                
                const popupContent = createMarkerPopup(item);
                marker.bindPopup(popupContent);
                commandState.markers.push(marker);
                addedCount++;
            });
            
            console.log('Added', addedCount, 'markers to map');
            
            if (statusEl) {
                const filterName = commandState.currentFilter === 'all' ? 'All' : 
                                   commandState.currentFilter === 'sos' ? 'SOS' :
                                   commandState.currentFilter === 'incident' ? 'Incidents' :
                                   commandState.currentFilter === 'station' ? 'Stations' : 'Officers';
                statusEl.innerHTML = `<i class="fas fa-check-circle me-1 text-success"></i>Showing ${addedCount} ${filterName} markers`;
            }
        })
        .catch(err => {
            console.error('Error loading map markers:', err);
            if (statusEl) {
                statusEl.innerHTML = '<i class="fas fa-exclamation-triangle me-1 text-danger"></i>Error loading markers';
            }
        });
}

function fitMapBounds() {
    if (commandState.markers.length === 0) return;
    
    const group = new L.featureGroup(commandState.markers);
    commandState.map.fitBounds(group.getBounds().pad(0.1));
}

function getMarkerColor(item) {
    if (item.type === 'sos') {
        if (item.live_status === 'OFFLINE') return '#6c757d';
        if (item.live_status === 'RESPONDING') return '#ffc107';
        if (item.live_status === 'OFFICER_ASSIGNED') return '#17a2b8';
        return '#dc3545';
    }
    
    if (item.type === 'station') return '#0066cc';
    
    if (item.type === 'officer') return '#28a745';
    
    if (item.type === 'incident') {
        const severity = parseInt(item.severity) || 1;
        if (severity >= 5) return '#dc3545';
        if (severity >= 4) return '#fd7e14';
        if (severity >= 3) return '#ffc107';
        return '#28a745';
    }
    
    return '#6c757d';
}

function createMarkerPopup(item) {
    let content = `<div style="min-width: 250px;">`;
    
    const typeIcon = getTypeIcon(item.type);
    content += `<h5 style="margin: 0 0 10px 0; color: ${getMarkerColor(item)};">${typeIcon} ${item.title || 'Unknown'}</h5>`;
    
    if (item.citizen_name) {
        content += `<div style="margin-bottom: 8px;"><strong>Citizen:</strong> ${item.citizen_name}</div>`;
        if (item.citizen_phone) {
            content += `<div style="margin-bottom: 8px;"><strong>Phone:</strong> <a href="tel:${item.citizen_phone}" style="color: #0066cc;">${item.citizen_phone}</a></div>`;
        }
    }
    
    content += `<div style="margin-bottom: 8px;"><strong>GPS:</strong> ${item.latitude.toFixed(6)}, ${item.longitude.toFixed(6)}</div>`;
    if (item.address) {
        content += `<div style="margin-bottom: 8px;"><strong>Address:</strong> ${item.address}</div>`;
    }
    
    if (item.status) {
        content += `<div style="margin-bottom: 8px;"><strong>Status:</strong> <span style="color: ${getMarkerColor(item)}; font-weight: bold;">${item.status}</span></div>`;
    }
    if (item.live_status) {
        content += `<div style="margin-bottom: 8px;"><strong>Live Status:</strong> <span style="color: ${getMarkerColor(item)}; font-weight: bold;">${item.live_status}</span></div>`;
    }
    if (item.severity) {
        content += `<div style="margin-bottom: 8px;"><strong>Severity:</strong> ${item.severity}/5</div>`;
    }
    
    if (item.type === 'sos') {
        if (item.speed_kmh !== null) {
            content += `<div style="margin-bottom: 8px;"><strong>Speed:</strong> ${item.speed_kmh} km/h</div>`;
        }
        if (item.movement_direction) {
            content += `<div style="margin-bottom: 8px;"><strong>Direction:</strong> ${item.movement_direction}</div>`;
        }
        if (item.battery_level !== null) {
            content += `<div style="margin-bottom: 8px;"><strong>Battery:</strong> ${item.battery_level}%</div>`;
        }
    }
    
    if (item.category) {
        content += `<div style="margin-bottom: 8px;"><strong>Category:</strong> ${item.category}</div>`;
    }
    
    if (item.created_at) {
        const date = new Date(item.created_at);
        content += `<div style="margin-bottom: 8px;"><strong>Time:</strong> ${date.toLocaleString()}</div>`;
    }
    
    if (item.district) {
        content += `<div style="margin-bottom: 8px;"><strong>District:</strong> ${item.district}</div>`;
    }
    if (item.section) {
        content += `<div style="margin-bottom: 8px;"><strong>Section:</strong> ${item.section}</div>`;
    }
    
    content += `<div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #ddd;">
        <a href="https://www.openstreetmap.org/?mlat=${item.latitude}&mlon=${item.longitude}#map=17/${item.latitude}/${item.longitude}" 
           target="_blank" style="color: #0066cc; text-decoration: none;">
            <i class="fas fa-external-link-alt"></i> View on OpenStreetMap
        </a>
    </div>`;
    
    content += `</div>`;
    return content;
}

function getTypeIcon(type) {
    switch(type) {
        case 'sos': return '<i class="fas fa-exclamation-triangle"></i>';
        case 'incident': return '<i class="fas fa-file-alt"></i>';
        case 'station': return '<i class="fas fa-building"></i>';
        case 'officer': return '<i class="fas fa-user-shield"></i>';
        default: return '<i class="fas fa-map-marker-alt"></i>';
    }
}

function showEmergencyModal(id) {
    fetch(`../api/emergency_details.php?id=${id}`)
        .then(r => r.json())
        .then(data => {
            commandState.selected = data;
            document.getElementById('adminEmergencyDetails').innerHTML = `
                <div class="text-white">
                    <div class="d-flex gap-3 align-items-center mb-3">
                        <div class="citizen-avatar">${(data.name || 'C').charAt(0)}</div>
                        <div>
                            <h4>${data.name}</h4>
                            <div>${data.phone || 'No phone'}</div>
                        </div>
                    </div>
                    <p><strong>Emergency:</strong> ${data.category}</p>
                    <p><strong>Severity:</strong> ${data.severity}/5</p>
                    <p><strong>Location:</strong> ${data.location}</p>
                    <p><strong>Status:</strong> ${data.status}</p>
                    <p><strong>Live Status:</strong> ${data.live_status || 'N/A'}</p>
                    ${data.speed_kmh ? `<p><strong>Speed:</strong> ${data.speed_kmh} km/h</p>` : ''}
                    ${data.movement_direction ? `<p><strong>Direction:</strong> ${data.movement_direction}</p>` : ''}
                    ${data.battery_level ? `<p><strong>Battery:</strong> ${data.battery_level}%</p>` : ''}
                </div>
            `;
            document.getElementById('callCitizenBtn').href = `tel:${data.phone || ''}`;
            document.getElementById('viewLiveMapBtn').href = `https://www.openstreetmap.org/?mlat=${data.latitude}&mlon=${data.longitude}#map=17/${data.latitude}/${data.longitude}`;
            new bootstrap.Modal(document.getElementById('adminEmergencyModal')).show();
            
            // Render mini map after modal is shown
            setTimeout(() => renderMiniMap(data), 300);
        });
}

function renderMiniMap(data) {
    if (!data.latitude || !data.longitude) return;
    
    // Remove existing mini map if any
    if (commandState.miniMap) {
        commandState.miniMap.remove();
    }
    
    commandState.miniMap = L.map('modalMiniMap').setView([data.latitude, data.longitude], 16);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(commandState.miniMap);
    
    const color = getMarkerColor(data);
    L.circleMarker([data.latitude, data.longitude], {
        radius: 12,
        color: color,
        fillColor: color,
        fillOpacity: 0.9,
        weight: 3
    }).addTo(commandState.miniMap).bindPopup('Emergency Location').openPopup();
}

function commandCaseAction(action) {
    if (!commandState.selected) {
        alert('Please select an emergency first');
        return;
    }
    
    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content || '';
    
    fetch('../api/case_action.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            csrf_token: csrfToken,
            sos_alert_id: commandState.selected.id,
            action: action
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            alert(data.message);
            // Close modal and refresh
            bootstrap.Modal.getInstance(document.getElementById('adminEmergencyModal')).hide();
            refreshMap();
        } else {
            alert('Error: ' + data.message);
        }
    })
    .catch(err => {
        console.error('Error:', err);
        alert('Failed to update case');
    });
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
