<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    verify_csrf();
    $allowedStatuses = ['submitted', 'searching', 'found', 'closed'];
    $status = in_array($_POST['status'] ?? '', $allowedStatuses, true) ? $_POST['status'] : 'submitted';
    
    // Get old status for comparison
    $oldMissing = db()->prepare('SELECT status, user_id, full_name FROM missing_persons WHERE id = ?');
    $oldMissing->execute([(int)$_POST['id']]);
    $oldData = $oldMissing->fetch();
    
    // Update status
    db()->prepare('UPDATE missing_persons SET status=? WHERE id=?')->execute([$status, (int)$_POST['id']]);
    
    // Add notification for citizen if status changed
    if ($oldData && $oldData['status'] !== $status) {
        $statusMessages = [
            'submitted' => 'Your missing person report has been submitted',
            'searching' => 'Search operations have begun for the missing person',
            'found' => 'The missing person has been found!',
            'closed' => 'The missing person case has been closed'
        ];
        
        $message = $statusMessages[$status] ?? "Missing person status updated to: $status";
        
        db()->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)')
            ->execute([$oldData['user_id'], "Missing Person Status Updated: " . e($oldData['full_name']), $message, $status === 'found' ? 'success' : ($status === 'closed' ? 'info' : 'warning')]);
    }
    
    flash('success', 'Missing person status updated. Citizen has been notified.');
    redirect('admin/missing_persons.php');
}

// Get all missing person reports with pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 15;
$offset = ($page - 1) * $perPage;

// Filter by status
$statusFilter = $_GET['status'] ?? '';
$whereClause = '';
$params = [];

if ($statusFilter && in_array($statusFilter, ['submitted', 'searching', 'found', 'closed'])) {
    $whereClause = 'WHERE m.status = ?';
    $params[] = $statusFilter;
}

$totalQuery = "SELECT COUNT(*) as count FROM missing_persons m $whereClause";
$totalStmt = db()->prepare($totalQuery);
$totalStmt->execute($params);
$totalCount = $totalStmt->fetch()['count'];
$totalPages = ceil($totalCount / $perPage);

$query = "SELECT m.*, u.name AS reporter_name, u.phone AS reporter_phone, u.email AS reporter_email, u.username AS reporter_username, u.profile_photo AS reporter_photo, u.role AS reporter_role, u.is_verified AS reporter_verified FROM missing_persons m JOIN users u ON u.id=m.user_id $whereClause ORDER BY m.created_at DESC LIMIT ? OFFSET ?";
$reportsStmt = db()->prepare($query);
$reportsStmt->execute(array_merge($params, [$perPage, $offset]));
$reports = $reportsStmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Missing Persons Management</h2>
                <small class="text-white-50">Track and manage missing person reports</small>
            </div>
            <a class="btn btn-admin-primary" href="dashboard.php">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>

        <!-- Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-folder fa-2x text-info"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM missing_persons")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Total Reports</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-search fa-2x text-warning"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM missing_persons WHERE status='searching'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Searching</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-check-circle fa-2x text-success"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM missing_persons WHERE status='found'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Found</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-archive fa-2x text-secondary"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM missing_persons WHERE status='closed'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Closed</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter -->
        <div class="admin-card p-4 mb-4">
            <div class="d-flex align-items-center gap-3 flex-wrap">
                <h5 class="fw-bold mb-0"><i class="fas fa-filter me-2"></i>Filter by Status:</h5>
                <div class="filter-pills">
                    <a href="missing_persons.php" class="filter-pill <?= $statusFilter === '' ? 'active' : '' ?>">All</a>
                    <a href="?status=submitted" class="filter-pill <?= $statusFilter === 'submitted' ? 'active' : '' ?>">Submitted</a>
                    <a href="?status=searching" class="filter-pill <?= $statusFilter === 'searching' ? 'active' : '' ?>">Searching</a>
                    <a href="?status=found" class="filter-pill <?= $statusFilter === 'found' ? 'active' : '' ?>">Found</a>
                    <a href="?status=closed" class="filter-pill <?= $statusFilter === 'closed' ? 'active' : '' ?>">Closed</a>
                </div>
            </div>
        </div>

        <!-- Reports Table -->
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0"><i class="fas fa-list me-2 text-primary"></i>Missing Person Reports</h4>
                <span class="badge bg-info"><?= $totalCount ?> Total</span>
            </div>
            
            <?php if (count($reports) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-admin table-hover">
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Description</th>
                                <th>Last Seen Location</th>
                                <th>Last Seen Date</th>
                                <th>Reporter</th>
                                <th>Status</th>
                                <th>Reported Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reports as $report): ?>
                                <tr>
                                    <td>
                                        <?php if ($report['photo_path']): ?>
                                            <img src="<?= APP_URL ?>/<?= e($report['photo_path']) ?>" alt="Photo" class="rounded-circle" style="width: 50px; height: 50px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                                <i class="fas fa-user text-white"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?= e($report['full_name']) ?></strong>
                                    </td>
                                    <td><?= $report['age'] ?? '-' ?></td>
                                    <td><?= e($report['gender']) ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-primary" onclick="showDescriptionModal('<?= e($report['full_name']) ?>', '<?= e(addslashes($report['description'])) ?>', '<?= e($report['last_seen_location']) ?>', '<?= e($report['last_seen_at']) ?>', '<?= e($report['age']) ?>', '<?= e($report['gender']) ?>', '<?= e($report['photo_path']) ?>')">
                                            <i class="fas fa-eye me-1"></i>View
                                        </button>
                                    </td>
                                    <td><?= e(substr($report['last_seen_location'], 0, 25)) ?><?= strlen($report['last_seen_location']) > 25 ? '...' : '' ?></td>
                                    <td><?= $report['last_seen_at'] ? date('M d, Y H:i', strtotime($report['last_seen_at'])) : '-' ?></td>
                                    <td>
                                        <a href="#" class="text-decoration-none" onclick="showReporterModal(<?= htmlspecialchars(json_encode([
                                            'name' => $report['reporter_name'],
                                            'phone' => $report['reporter_phone'],
                                            'email' => $report['reporter_email'],
                                            'username' => $report['reporter_username'],
                                            'photo' => $report['reporter_photo'],
                                            'role' => $report['reporter_role'],
                                            'verified' => $report['reporter_verified']
                                        ])) ?>); return false;">
                                            <?= e($report['reporter_name']) ?>
                                        </a>
                                    </td>
                                    <td>
                                        <span class="status-pill status-pill-<?= $report['status'] === 'found' ? 'resolved' : ($report['status'] === 'searching' ? 'assigned' : ($report['status'] === 'closed' ? 'pending' : 'pending')) ?>">
                                            <?= ucfirst($report['status']) ?>
                                        </span>
                                    </td>
                                    <td><?= date('M d, Y H:i', strtotime($report['created_at'])) ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-admin-primary" data-bs-toggle="modal" data-bs-target="#updateModal<?= e($report['id']) ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php if ($report['photo_path']): ?>
                                                <button type="button" class="btn btn-sm btn-admin-success" onclick="showPhotoModal('<?= APP_URL ?>/<?= e($report['photo_path']) ?>', '<?= e($report['full_name']) ?>', '<?= e($report['id']) ?>')">
                                                    <i class="fas fa-image"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link bg-dark text-white border-secondary" href="?page=<?= $page - 1 ?>&status=<?= $statusFilter ?>">Previous</a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link <?= $i === $page ? 'bg-primary' : 'bg-dark text-white border-secondary' ?>" href="?page=<?= $i ?>&status=<?= $statusFilter ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link bg-dark text-white border-secondary" href="?page=<?= $page + 1 ?>&status=<?= $statusFilter ?>">Next</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center text-muted py-5">
                    <i class="fas fa-user-friends fa-4x mb-3" style="opacity: 0.3;"></i>
                    <p class="mb-0">No missing person reports found</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Update Status Modals -->
<?php foreach ($reports as $report): ?>
<div class="modal fade" id="updateModal<?= e($report['id']) ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">Update Status - <?= e($report['full_name']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="id" value="<?= e($report['id']) ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Current Status</label>
                        <div>
                            <span class="status-pill status-pill-<?= $report['status'] === 'found' ? 'resolved' : ($report['status'] === 'searching' ? 'assigned' : 'pending') ?>">
                                <?= ucfirst($report['status']) ?>
                            </span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Update Status</label>
                        <select class="form-select form-select-admin" name="status">
                            <option value="submitted" <?= $report['status'] === 'submitted' ? 'selected' : '' ?>>Submitted</option>
                            <option value="searching" <?= $report['status'] === 'searching' ? 'selected' : '' ?>>Searching</option>
                            <option value="found" <?= $report['status'] === 'found' ? 'selected' : '' ?>>Found</option>
                            <option value="closed" <?= $report['status'] === 'closed' ? 'selected' : '' ?>>Closed</option>
                        </select>
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        The citizen will be automatically notified of this status change.
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-admin-success">Update Status</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Reporter Info Modal -->
<div class="modal fade" id="reporterModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title"><i class="fas fa-user me-2"></i>Reporter Information</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <div id="reporterModalPhoto" class="rounded-circle bg-primary d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 100px; height: 100px; font-size: 2.5rem;">
                        <i class="fas fa-user"></i>
                    </div>
                    <h4 id="reporterModalName" class="mb-1"></h4>
                    <span id="reporterModalVerified" class="badge bg-success d-none"><i class="fas fa-check-circle me-1"></i>Verified</span>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Username</small>
                            <div id="reporterModalUsername" class="fw-bold"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Role</small>
                            <div id="reporterModalRole" class="fw-bold"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Phone</small>
                            <div id="reporterModalPhone" class="fw-bold"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Email</small>
                            <div id="reporterModalEmail" class="fw-bold"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Description Details Modal -->
<div class="modal fade" id="descriptionModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title"><i class="fas fa-info-circle me-2"></i>Missing Person Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-center mb-4">
                    <div id="descModalPhoto" class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 120px; height: 120px; font-size: 3rem;">
                        <i class="fas fa-user"></i>
                    </div>
                    <h4 id="descModalName" class="mb-1"></h4>
                    <div class="d-flex justify-content-center gap-3 mb-3">
                        <span id="descModalAge" class="badge bg-info"></span>
                        <span id="descModalGender" class="badge bg-secondary"></span>
                    </div>
                </div>
                <div class="admin-card p-4 mb-3">
                    <h6 class="text-warning mb-2"><i class="fas fa-align-left me-2"></i>Description</h6>
                    <p id="descModalDescription" class="mb-0 text-white-50" style="white-space: pre-wrap;"></p>
                </div>
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Last Seen Location</small>
                            <div id="descModalLocation" class="fw-bold"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Last Seen Date</small>
                            <div id="descModalLastSeen" class="fw-bold"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Photo View Modal -->
<div class="modal fade" id="photoModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title"><i class="fas fa-image me-2"></i><span id="photoModalTitle">Photo</span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="photoModalImage" src="" alt="Missing Person Photo" class="img-fluid rounded" style="max-height: 500px;">
            </div>
            <div class="modal-footer border-secondary">
                <a id="photoModalDownload" href="" download class="btn btn-admin-info me-2" style="color: white;">
                    <i class="fas fa-download me-1" style="color: white;"></i>Download
                </a>
              
            </div>
        </div>
    </div>
</div>

<script>
function showReporterModal(reporter) {
    document.getElementById('reporterModalName').textContent = reporter.name;
    document.getElementById('reporterModalUsername').textContent = reporter.username;
    document.getElementById('reporterModalRole').textContent = reporter.role;
    document.getElementById('reporterModalPhone').textContent = reporter.phone;
    document.getElementById('reporterModalEmail').textContent = reporter.email || 'Not provided';
    
    const photoContainer = document.getElementById('reporterModalPhoto');
    if (reporter.photo) {
        photoContainer.innerHTML = `<img src="<?= APP_URL ?>/` + reporter.photo + '" class="rounded-circle" style="width: 100px; height: 100px; object-fit: cover;">';
    } else {
        photoContainer.innerHTML = `<i class="fas fa-user"></i>`;
    }
    
    const verifiedBadge = document.getElementById('reporterModalVerified');
    if (reporter.verified) {
        verifiedBadge.classList.remove('d-none');
    } else {
        verifiedBadge.classList.add('d-none');
    }
    
    new bootstrap.Modal(document.getElementById('reporterModal')).show();
}

function showDescriptionModal(fullName, description, location, lastSeen, age, gender, photoPath) {
    document.getElementById('descModalName').textContent = fullName;
    document.getElementById('descModalAge').textContent = age ? age + ' years' : 'Age not specified';
    document.getElementById('descModalGender').textContent = gender || 'Gender not specified';
    document.getElementById('descModalDescription').textContent = description || 'No description provided';
    document.getElementById('descModalLocation').textContent = location || 'Not specified';
    
    if (lastSeen) {
        const date = new Date(lastSeen);
        document.getElementById('descModalLastSeen').textContent = date.toLocaleString();
    } else {
        document.getElementById('descModalLastSeen').textContent = 'Not specified';
    }
    
    const photoContainer = document.getElementById('descModalPhoto');
    if (photoPath) {
        photoContainer.innerHTML = `<img src="<?= APP_URL ?>/` + photoPath + '" class="rounded-circle" style="width: 120px; height: 120px; object-fit: cover;">';
    } else {
        photoContainer.innerHTML = `<i class="fas fa-user"></i>`;
    }
    
    new bootstrap.Modal(document.getElementById('descriptionModal')).show();
}

function showPhotoModal(photoUrl, personName, id) {
    document.getElementById('photoModalTitle').textContent = personName;
    document.getElementById('photoModalImage').src = photoUrl;
    document.getElementById('photoModalDownload').href = photoUrl;
    document.getElementById('photoModalDownload').download = 'missing_person_' + id + '.jpg';
    new bootstrap.Modal(document.getElementById('photoModal')).show();
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
