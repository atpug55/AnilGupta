<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);

// Get date range
$startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
$endDate = $_GET['end_date'] ?? date('Y-m-d');

// Analytics queries
$incidentsByStatus = db()->prepare("SELECT status, COUNT(*) as count FROM incidents WHERE created_at BETWEEN ? AND ? GROUP BY status");
$incidentsByStatus->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
$incidentsStatusData = $incidentsByStatus->fetchAll();

$incidentsBySeverity = db()->prepare("SELECT severity, COUNT(*) as count FROM incidents WHERE created_at BETWEEN ? AND ? GROUP BY severity");
$incidentsBySeverity->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
$incidentsSeverityData = $incidentsBySeverity->fetchAll();

$incidentsByCategory = db()->prepare("SELECT category, COUNT(*) as count FROM incidents WHERE created_at BETWEEN ? AND ? GROUP BY category ORDER BY count DESC LIMIT 10");
$incidentsByCategory->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
$incidentsCategoryData = $incidentsByCategory->fetchAll();

$sosByStatus = db()->prepare("SELECT status, COUNT(*) as count FROM sos_alerts WHERE created_at BETWEEN ? AND ? GROUP BY status");
$sosByStatus->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
$sosStatusData = $sosByStatus->fetchAll();

$missingByStatus = db()->prepare("SELECT status, COUNT(*) as count FROM missing_persons WHERE created_at BETWEEN ? AND ? GROUP BY status");
$missingByStatus->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
$missingStatusData = $missingByStatus->fetchAll();

$dailyIncidents = db()->prepare("SELECT DATE(created_at) as date, COUNT(*) as count FROM incidents WHERE created_at BETWEEN ? AND ? GROUP BY DATE(created_at) ORDER BY date");
$dailyIncidents->execute([$startDate . ' 00:00:00', $endDate . ' 23:59:59']);
$dailyIncidentData = $dailyIncidents->fetchAll();

$responseTime = db()->query("SELECT AVG(TIMESTAMPDIFF(MINUTE, i.created_at, i.updated_at)) as avg_minutes FROM incidents i WHERE i.status = 'resolved' AND i.updated_at IS NOT NULL")->fetch();

$topOfficers = db()->query("SELECT u.name, COUNT(i.id) as resolved_count FROM users u JOIN incidents i ON u.id = i.officer_id WHERE i.status = 'resolved' GROUP BY u.id ORDER BY resolved_count DESC LIMIT 5")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Analytics Dashboard</h2>
                <small class="text-white-50">Comprehensive performance metrics and statistics</small>
            </div>
            <a class="btn btn-admin-primary" href="dashboard.php">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>

        <!-- Date Filter -->
        <div class="admin-card p-4 mb-4">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Start Date</label>
                    <input type="date" class="form-control form-control-admin" name="start_date" value="<?= e($startDate) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">End Date</label>
                    <input type="date" class="form-control form-control-admin" name="end_date" value="<?= e($endDate) ?>">
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-admin-primary w-100">
                        <i class="fas fa-filter me-2"></i>Apply Filter
                    </button>
                </div>
                <div class="col-md-3">
                    <a href="analytics.php" class="btn btn-secondary w-100">
                        <i class="fas fa-redo me-2"></i>Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Key Metrics -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-icon stat-card-icon-primary">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-card-value"><?= array_sum(array_column($incidentsStatusData, 'count')) ?></div>
                    <div class="stat-card-label">Total Incidents</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-icon stat-card-icon-success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-card-value"><?= $incidentsStatusData[array_search('resolved', array_column($incidentsStatusData, 'status'))]['count'] ?? 0 ?></div>
                    <div class="stat-card-label">Resolved Cases</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-icon stat-card-icon-danger">
                        <i class="fas fa-exclamation-circle"></i>
                    </div>
                    <div class="stat-card-value"><?= array_sum(array_column($sosStatusData, 'count')) ?></div>
                    <div class="stat-card-label">SOS Alerts</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-icon stat-card-icon-warning">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-card-value"><?= round($responseTime['avg_minutes'] ?? 0, 1) ?>h</div>
                    <div class="stat-card-label">Avg Response Time</div>
                </div>
            </div>
        </div>

        <!-- Charts Row 1 -->
        <div class="row g-4 mb-4">
            <div class="col-lg-6">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-chart-pie me-2 text-primary"></i>Incidents by Status</h4>
                    <canvas id="incidentsStatusChart" height="250"></canvas>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-chart-bar me-2 text-warning"></i>Incidents by Severity</h4>
                    <canvas id="incidentsSeverityChart" height="250"></canvas>
                </div>
            </div>
        </div>

        <!-- Charts Row 2 -->
        <div class="row g-4 mb-4">
            <div class="col-lg-6">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-chart-line me-2 text-success"></i>Daily Incident Trend</h4>
                    <canvas id="dailyIncidentsChart" height="250"></canvas>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-tags me-2 text-info"></i>Top Incident Categories</h4>
                    <canvas id="incidentsCategoryChart" height="250"></canvas>
                </div>
            </div>
        </div>

        <!-- Additional Stats -->
        <div class="row g-4 mb-4">
            <div class="col-lg-4">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-exclamation-triangle me-2 text-danger"></i>SOS Alerts Status</h4>
                    <canvas id="sosStatusChart" height="200"></canvas>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-user-friends me-2 text-warning"></i>Missing Persons Status</h4>
                    <canvas id="missingStatusChart" height="200"></canvas>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="admin-card p-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-trophy me-2 text-success"></i>Top Performing Officers</h4>
                    <div class="activity-feed">
                        <?php foreach ($topOfficers as $officer): ?>
                            <div class="activity-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?= e($officer['name']) ?></strong>
                                    </div>
                                    <span class="badge bg-success"><?= $officer['resolved_count'] ?> Resolved</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($topOfficers)): ?>
                            <div class="text-center text-muted py-3">
                                <small>No data available</small>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Detailed Statistics Table -->
        <div class="admin-card p-4">
            <h4 class="fw-bold mb-3"><i class="fas fa-table me-2 text-primary"></i>Category Breakdown</h4>
            <div class="table-responsive">
                <table class="table table-admin table-hover">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Total Incidents</th>
                            <th>Percentage</th>
                            <th>Avg Severity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $totalIncidents = array_sum(array_column($incidentsCategoryData, 'count'));
                        foreach ($incidentsCategoryData as $cat): 
                            $categorySeverity = db()->prepare("SELECT AVG(severity) as avg_sev FROM incidents WHERE category = ? AND created_at BETWEEN ? AND ?");
                            $categorySeverity->execute([$cat['category'], $startDate . ' 00:00:00', $endDate . ' 23:59:59']);
                            $avgSeverity = $categorySeverity->fetch()['avg_sev'];
                        ?>
                            <tr>
                                <td><?= e($cat['category']) ?></td>
                                <td><?= $cat['count'] ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="progress me-2" style="width: 100px; height: 8px; background: rgba(255,255,255,0.1);">
                                            <div class="progress-bar bg-primary" style="width: <?= ($cat['count'] / $totalIncidents) * 100 ?>%;"></div>
                                        </div>
                                        <small><?= round(($cat['count'] / $totalIncidents) * 100, 1) ?>%</small>
                                    </div>
                                </td>
                                <td><?= round($avgSeverity ?? 0, 1) ?>/5</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Chart.js Configuration
Chart.defaults.color = '#e8eefc';
Chart.defaults.borderColor = 'rgba(255, 255, 255, 0.1)';

// Incidents by Status Chart
const incidentsStatusCtx = document.getElementById('incidentsStatusChart').getContext('2d');
new Chart(incidentsStatusCtx, {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($incidentsStatusData, 'status')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($incidentsStatusData, 'count')) ?>,
            backgroundColor: ['#3b82f6', '#f59e0b', '#10b981', '#ef4444', '#6b7280'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// Incidents by Severity Chart
const incidentsSeverityCtx = document.getElementById('incidentsSeverityChart').getContext('2d');
new Chart(incidentsSeverityCtx, {
    type: 'bar',
    data: {
        labels: ['Severity 1', 'Severity 2', 'Severity 3', 'Severity 4', 'Severity 5'],
        datasets: [{
            label: 'Count',
            data: <?= json_encode(array_fill(0, 5, 0)) ?>,
            backgroundColor: ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#7c2d12'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Update severity data
<?php foreach ($incidentsSeverityData as $sev): ?>
document.querySelector('#incidentsSeverityChart').data.datasets[0].data[<?= $sev['severity'] - 1 ?>] = <?= $sev['count'] ?>;
<?php endforeach; ?>
document.querySelector('#incidentsSeverityChart').update();

// Daily Incidents Chart
const dailyIncidentsCtx = document.getElementById('dailyIncidentsChart').getContext('2d');
new Chart(dailyIncidentsCtx, {
    type: 'line',
    data: {
        labels: <?= json_encode(array_column($dailyIncidentData, 'date')) ?>,
        datasets: [{
            label: 'Incidents',
            data: <?= json_encode(array_column($dailyIncidentData, 'count')) ?>,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Incidents by Category Chart
const incidentsCategoryCtx = document.getElementById('incidentsCategoryChart').getContext('2d');
new Chart(incidentsCategoryCtx, {
    type: 'polarArea',
    data: {
        labels: <?= json_encode(array_column($incidentsCategoryData, 'category')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($incidentsCategoryData, 'count')) ?>,
            backgroundColor: ['#3b82f6', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16', '#f97316', '#6366f1'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'right'
            }
        }
    }
});

// SOS Status Chart
const sosStatusCtx = document.getElementById('sosStatusChart').getContext('2d');
new Chart(sosStatusCtx, {
    type: 'pie',
    data: {
        labels: <?= json_encode(array_column($sosStatusData, 'status')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($sosStatusData, 'count')) ?>,
            backgroundColor: ['#ef4444', '#10b981', '#f59e0b', '#6b7280'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});

// Missing Persons Status Chart
const missingStatusCtx = document.getElementById('missingStatusChart').getContext('2d');
new Chart(missingStatusCtx, {
    type: 'doughnut',
    data: {
        labels: <?= json_encode(array_column($missingStatusData, 'status')) ?>,
        datasets: [{
            data: <?= json_encode(array_column($missingStatusData, 'count')) ?>,
            backgroundColor: ['#3b82f6', '#f59e0b', '#10b981', '#6b7280'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
