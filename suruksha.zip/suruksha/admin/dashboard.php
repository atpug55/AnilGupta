<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);

// Advanced metrics - optimized with single combined query
try {
    $metricResults = db()->query("
        SELECT 
            (SELECT COUNT(*) FROM incidents WHERE status NOT IN ('resolved','rejected')) as active,
            (SELECT COUNT(*) FROM sos_alerts WHERE status='active') as sos,
            (SELECT COUNT(*) FROM incidents WHERE severity >= 4 AND status NOT IN ('resolved','rejected')) as high,
            (SELECT COUNT(*) FROM officers WHERE status='available') as officers,
            (SELECT COUNT(*) FROM incidents WHERE status='resolved' AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) +
            (SELECT COUNT(*) FROM sos_alerts WHERE status IN ('resolved','acknowledged') AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) +
            (SELECT COUNT(*) FROM missing_persons WHERE status='found' AND updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)) as resolved_today,
            (SELECT COUNT(*) FROM missing_persons WHERE status IN ('submitted','searching')) as missing_active,
            (SELECT COUNT(*) FROM police_stations) as stations,
            (SELECT COUNT(*) FROM officers) as total_officers
    ")->fetch();
    
    $metrics = [
        'active' => (int)$metricResults['active'],
        'sos' => (int)$metricResults['sos'],
        'high' => (int)$metricResults['high'],
        'officers' => (int)$metricResults['officers'],
        'resolved_today' => (int)$metricResults['resolved_today'],
        'missing_active' => (int)$metricResults['missing_active'],
        'stations' => (int)$metricResults['stations'],
        'total_officers' => (int)$metricResults['total_officers'],
    ];
} catch (Exception $e) {
    // Fallback to individual queries if combined query fails
    $metrics = [
        'active' => db()->query("SELECT COUNT(*) c FROM incidents WHERE status NOT IN ('resolved','rejected')")->fetch()['c'],
        'sos' => db()->query("SELECT COUNT(*) c FROM sos_alerts WHERE status='active'")->fetch()['c'],
        'high' => db()->query("SELECT COUNT(*) c FROM incidents WHERE severity >= 4 AND status NOT IN ('resolved','rejected')")->fetch()['c'],
        'officers' => db()->query("SELECT COUNT(*) c FROM officers WHERE status='available'")->fetch()['c'],
        'resolved_today' => 0,
        'missing_active' => db()->query("SELECT COUNT(*) c FROM missing_persons WHERE status='searching'")->fetch()['c'],
        'stations' => db()->query("SELECT COUNT(*) c FROM police_stations")->fetch()['c'],
        'total_officers' => db()->query("SELECT COUNT(*) c FROM officers")->fetch()['c'],
    ];
}

// Recent data
$incidents = db()->query('SELECT i.*, u.name AS citizen_name, officer.name AS officer_name FROM incidents i JOIN users u ON u.id=i.user_id LEFT JOIN users officer ON officer.id=i.officer_id ORDER BY i.severity DESC, i.created_at DESC LIMIT 12')->fetchAll();
$sos = db()->query('SELECT s.*, u.name, u.phone FROM sos_alerts s JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC LIMIT 8')->fetchAll();
$officers = db()->query("SELECT o.*, u.name, ps.name AS station_name FROM officers o JOIN users u ON u.id=o.user_id LEFT JOIN police_stations ps ON ps.id=o.police_station_id ORDER BY o.status='available' DESC, u.name LIMIT 8")->fetchAll();

// Recent activity
$activity = db()->query("SELECT 'incident' as type, i.title as description, i.status, i.created_at, u.name as actor_name FROM incidents i JOIN users u ON u.id=i.user_id 
    UNION ALL
    SELECT 'sos' as type, CONCAT('SOS: ', s.emergency_category) as description, s.status, s.created_at, u.name as actor_name FROM sos_alerts s JOIN users u ON u.id=s.user_id 
    UNION ALL
    SELECT 'missing' as type, CONCAT('Missing: ', m.full_name) as description, m.status, m.created_at, u.name as actor_name FROM missing_persons m JOIN users u ON u.id=m.user_id 
    ORDER BY created_at DESC LIMIT 10")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Nepal Police Command Dashboard</h2>
                <small class="text-white-50">Real-time emergency response and incident management system</small>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a class="btn btn-admin-danger" href="live_command_center.php">
                    <i class="fas fa-satellite-dish me-2"></i>Live Command Center
                </a>
                <a class="btn btn-admin-primary" href="stations.php">
                    <i class="fas fa-building me-2"></i>Stations
                </a>
                <a class="btn btn-admin-primary" href="officers.php">
                    <i class="fas fa-user-shield me-2"></i>Officers
                </a>
                <a class="btn btn-admin-warning" href="notifications.php">
                    <i class="fas fa-bullhorn me-2"></i>Broadcast Alert
                </a>
            </div>
        </div>

        <!-- Live Alert Popup -->
        <div id="liveAlertPopup" class="alert d-none mb-4" style="background-color: #ffffff; border: 2px solid #dc3545; border-left: 5px solid #dc3545;">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1 text-danger"><i class="fas fa-exclamation-triangle me-2"></i>LIVE SOS EMERGENCY</h4>
                    <div id="liveAlertText" class="text-danger"></div>
                    <div class="small text-danger">Response timer: <span id="responseTimer" class="fw-bold">00:00</span></div>
                </div>
                <button class="btn btn-danger btn-sm" onclick="document.getElementById('liveAlertPopup').classList.add('d-none')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <a href="incidents.php" class="text-decoration-none">
                    <div class="stat-card" style="cursor: pointer; transition: transform 0.2s;">
                        <div class="stat-card-icon stat-card-icon-primary">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div class="stat-card-value"><?= e($metrics['active']) ?></div>
                        <div class="stat-card-label">Active Incidents</div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="sos.php" class="text-decoration-none">
                    <div class="stat-card emergency-flash" style="cursor: pointer; transition: transform 0.2s;">
                        <div class="stat-card-icon stat-card-icon-danger">
                            <i class="fas fa-exclamation-circle"></i>
                        </div>
                        <div class="stat-card-value text-danger" id="activeSosMetric"><?= e($metrics['sos']) ?></div>
                        <div class="stat-card-label">Active SOS Alerts</div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-card-icon stat-card-icon-warning">
                        <i class="fas fa-fire"></i>
                    </div>
                    <div class="stat-card-value text-warning"><?= e($metrics['high']) ?></div>
                    <div class="stat-card-label">High Severity</div>
                </div>
            </div>
            <div class="col-md-3">
                <a href="officers.php" class="text-decoration-none">
                    <div class="stat-card" style="cursor: pointer; transition: transform 0.2s;">
                        <div class="stat-card-icon stat-card-icon-success">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <div class="stat-card-value text-success"><?= e($metrics['officers']) ?></div>
                        <div class="stat-card-label">Available Officers</div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Secondary Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-check-circle fa-2x text-success"></i>
                        </div>
                        <div>
                            <div class="metric"><?= e($metrics['resolved_today']) ?></div>
                            <small class="text-white-50">Resolved Today</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-user-friends fa-2x text-warning"></i>
                        </div>
                        <div>
                            <div class="metric"><?= e($metrics['missing_active']) ?></div>
                            <small class="text-white-50">Missing Persons</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-building fa-2x text-info"></i>
                        </div>
                        <div>
                            <div class="metric"><?= e($metrics['stations']) ?></div>
                            <small class="text-white-50">Police Stations</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-users fa-2x text-primary"></i>
                        </div>
                        <div>
                            <div class="metric"><?= e($metrics['total_officers']) ?></div>
                            <small class="text-white-50">Total Officers</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row g-3 mb-4">
            <div class="col-12">
                <div class="admin-card p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-bolt me-2 text-warning"></i>Quick Actions</h5>
                    <div class="row g-3">
                        <div class="col-md-2 col-4">
                            <a href="live_command_center.php" class="quick-action">
                                <div class="quick-action-icon">
                                    <i class="fas fa-satellite-dish"></i>
                                </div>
                                <div class="quick-action-label">Live Command</div>
                            </a>
                        </div>
                        <div class="col-md-2 col-4">
                            <a href="officers.php" class="quick-action">
                                <div class="quick-action-icon">
                                    <i class="fas fa-user-plus"></i>
                                </div>
                                <div class="quick-action-label">Add Officer</div>
                            </a>
                        </div>
                        <div class="col-md-2 col-4">
                            <a href="stations.php" class="quick-action">
                                <div class="quick-action-icon">
                                    <i class="fas fa-building"></i>
                                </div>
                                <div class="quick-action-label">Add Station</div>
                            </a>
                        </div>
                        <div class="col-md-2 col-4">
                            <a href="notifications.php" class="quick-action">
                                <div class="quick-action-icon">
                                    <i class="fas fa-bullhorn"></i>
                                </div>
                                <div class="quick-action-label">Broadcast</div>
                            </a>
                        </div>
                        <div class="col-md-2 col-4">
                            <a href="missing_persons.php" class="quick-action">
                                <div class="quick-action-icon">
                                    <i class="fas fa-search"></i>
                                </div>
                                <div class="quick-action-label">Missing Persons</div>
                            </a>
                        </div>
                        <div class="col-md-2 col-4">
                            <a href="analytics.php" class="quick-action">
                                <div class="quick-action-icon">
                                    <i class="fas fa-chart-bar"></i>
                                </div>
                                <div class="quick-action-label">Analytics</div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="row g-4">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- Live Map -->
                <div class="admin-card p-4 mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold mb-0"><i class="fas fa-map-marked-alt me-2 text-primary"></i>Live Incident Map</h4>
                        <span class="badge bg-success">Live</span>
                    </div>
                    
                    <!-- Map Legend -->
                    <div class="mb-3 p-2" style="background: rgba(255,255,255,0.1); border-radius: 8px;">
                        <small class="text-white-50 fw-bold mb-2 d-block">Legend:</small>
                        <div class="d-flex flex-wrap gap-3">
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #dc3545;"></span>
                                <small class="text-white-50">SOS Active</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #ffc107;"></span>
                                <small class="text-white-50">SOS Responding</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #17a2b8;"></span>
                                <small class="text-white-50">Officer Assigned</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #6c757d;"></span>
                                <small class="text-white-50">Offline</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #fd7e14;"></span>
                                <small class="text-white-50">High Severity</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #0066cc;"></span>
                                <small class="text-white-50">Police Station</small>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="d-inline-block rounded-circle me-1" style="width: 12px; height: 12px; background: #28a745;"></span>
                                <small class="text-white-50">Officer</small>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Map Filters -->
                    <div class="mb-3">
                        <div class="d-flex flex-wrap gap-2">
                            <button class="btn btn-sm btn-outline-light filter-btn active" data-filter="all" onclick="filterMapMarkers('all')">
                                <i class="fas fa-layer-group me-1"></i>All
                            </button>
                            <button class="btn btn-sm btn-outline-danger filter-btn" data-filter="sos" onclick="filterMapMarkers('sos')">
                                <i class="fas fa-exclamation-triangle me-1"></i>SOS
                            </button>
                            <button class="btn btn-sm btn-outline-warning filter-btn" data-filter="incident" onclick="filterMapMarkers('incident')">
                                <i class="fas fa-file-alt me-1"></i>Incidents
                            </button>
                            <button class="btn btn-sm btn-outline-info filter-btn" data-filter="station" onclick="filterMapMarkers('station')">
                                <i class="fas fa-building me-1"></i>Stations
                            </button>
                            <button class="btn btn-sm btn-outline-success filter-btn" data-filter="officer" onclick="filterMapMarkers('officer')">
                                <i class="fas fa-user-shield me-1"></i>Officers
                            </button>
                        </div>
                    </div>
                    
                    <div id="adminMap" class="map-box"></div>
                </div>
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <!-- Recent Activity -->
                <div class="admin-card p-4 mb-4">
                    <h4 class="fw-bold mb-3"><i class="fas fa-history me-2 text-primary"></i>Recent Activity</h4>
                    <div class="activity-feed">
                        <?php foreach ($activity as $item): ?>
                            <div class="activity-item">
                                <div class="d-flex align-items-start">
                                    <div class="activity-icon activity-icon-<?= $item['type'] === 'sos' ? 'danger' : ($item['type'] === 'missing' ? 'warning' : 'info') ?>">
                                        <i class="fas fa-<?= $item['type'] === 'sos' ? 'exclamation-circle' : ($item['type'] === 'missing' ? 'user-friends' : 'file-alt') ?>"></i>
                                    </div>
                                    <div class="activity-content">
                                        <div class="activity-title"><?= e(substr($item['description'], 0, 40)) ?>...</div>
                                        <div class="activity-time">
                                            <i class="fas fa-user me-1"></i><?= e($item['actor_name']) ?>
                                            <span class="ms-2"><i class="fas fa-clock me-1"></i><?= date('H:i', strtotime($item['created_at'])) ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Available Officers -->
                <div class="admin-card p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold mb-0"><i class="fas fa-user-shield me-2 text-success"></i>Available Officers</h4>
                    </div>
                    <div class="activity-feed">
                        <?php foreach ($officers as $officer): ?>
                            <div class="activity-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?= e($officer['name']) ?></strong>
                                        <div class="small text-white-50">
                                            <?= e($officer['station_name'] ?? 'No Station') ?>
                                        </div>
                                    </div>
                                    <span class="officer-status officer-status-<?= $officer['status'] ?>">
                                        <?= ucfirst($officer['status']) ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
let adminMapLayers = [];
let allMapMarkers = [];

document.addEventListener('DOMContentLoaded', () => {
    initAdminMap();
    setupLiveUpdates();
    setupLivePoliceAlerts('../api/live_alerts.php');
});

function initAdminMap() {
    initMap('adminMap', '../api/map_markers.php', { followUser: false });
    
    // Store markers for filtering
    setTimeout(() => {
        const map = L.map('adminMap');
        map.eachLayer(layer => {
            if (layer instanceof L.CircleMarker) {
                allMapMarkers.push(layer);
                adminMapLayers.push(layer);
            }
        });
    }, 2000);
}

function filterMapMarkers(filterType) {
    // Update button active states
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.filter === filterType) {
            btn.classList.add('active');
        }
    });
    
    // Filter markers
    const map = L.map('adminMap');
    
    // Remove all markers
    allMapMarkers.forEach(marker => {
        map.removeLayer(marker);
    });
    
    // Add back filtered markers
    allMapMarkers.forEach(marker => {
        const markerData = marker.getPopup() ? marker.getPopup().getContent() : '';
        
        if (filterType === 'all') {
            map.addLayer(marker);
        } else {
            // Check marker type based on popup content or custom data
            let shouldShow = false;
            
            if (filterType === 'sos' && markerData.includes('SOS')) {
                shouldShow = true;
            } else if (filterType === 'incident' && markerData.includes('Incident')) {
                shouldShow = true;
            } else if (filterType === 'station' && markerData.includes('Station')) {
                shouldShow = true;
            } else if (filterType === 'officer' && markerData.includes('Officer')) {
                shouldShow = true;
            }
            
            if (shouldShow) {
                map.addLayer(marker);
            }
        }
    });
}

function setupLiveUpdates() {
    // Update metrics every 30 seconds
    setInterval(() => {
        fetch('../api/metrics.php')
            .then(r => r.json())
            .then(data => {
                document.getElementById('activeSosMetric').textContent = data.sos;
            });
    }, 30000);
    
    // Refresh map markers every 60 seconds
    setInterval(() => {
        const map = L.map('adminMap');
        allMapMarkers.forEach(marker => {
            map.removeLayer(marker);
        });
        allMapMarkers = [];
        
        fetch('../api/map_markers.php')
            .then(r => r.json())
            .then(items => {
                items.forEach(item => {
                    if (!item.latitude || !item.longitude) return;
                    
                    const color = getMarkerColor(item);
                    let marker;
                    
                    if (item.type === 'sos') {
                        marker = L.circleMarker([item.latitude, item.longitude], {
                            radius: 12,
                            color: color,
                            fillColor: color,
                            fillOpacity: 0.9,
                            weight: 3
                        }).addTo(map);
                    } else if (item.type === 'station') {
                        marker = L.circleMarker([item.latitude, item.longitude], {
                            radius: 10,
                            color: '#0066cc',
                            fillColor: '#0066cc',
                            fillOpacity: 0.8,
                            weight: 2
                        }).addTo(map);
                    } else if (item.type === 'officer') {
                        marker = L.circleMarker([item.latitude, item.longitude], {
                            radius: 8,
                            color: '#28a745',
                            fillColor: '#28a745',
                            fillOpacity: 0.8,
                            weight: 2
                        }).addTo(map);
                    } else {
                        marker = L.circleMarker([item.latitude, item.longitude], {
                            radius: 10,
                            color: color,
                            fillColor: color,
                            fillOpacity: 0.8,
                            weight: 2
                        }).addTo(map);
                    }
                    
                    const popupContent = createMarkerPopup(item);
                    marker.bindPopup(popupContent);
                    allMapMarkers.push(marker);
                });
            });
    }, 60000);
}
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
