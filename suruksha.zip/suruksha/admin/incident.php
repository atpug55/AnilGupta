<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['admin','dispatcher']);
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $officerId = $_POST['officer_id'] ?: null;
    $status = $_POST['status'];
    
    // Get old status for comparison
    $oldIncident = db()->prepare('SELECT status, user_id, title FROM incidents WHERE id = ?');
    $oldIncident->execute([$id]);
    $oldData = $oldIncident->fetch();
    
    // Update incident
    db()->prepare('UPDATE incidents SET status = ?, officer_id = ? WHERE id = ?')->execute([$status, $officerId, $id]);
    if ($officerId) db()->prepare("UPDATE officers SET status='assigned' WHERE user_id=?")->execute([$officerId]);
    
    // Add notification for citizen if status changed
    if ($oldData && $oldData['status'] !== $status) {
        $statusMessages = [
            'submitted' => 'Your report has been submitted',
            'verified' => 'Your report has been verified',
            'assigned' => 'An officer has been assigned to your report',
            'in_progress' => 'Your report is being processed',
            'resolved' => 'Your report has been resolved',
            'rejected' => 'Your report has been rejected'
        ];
        
        $message = $statusMessages[$status] ?? "Your report status has been updated to: $status";
        
        db()->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)')
            ->execute([$oldData['user_id'], "Report Status Updated: " . e($oldData['title']), $message, $status === 'resolved' ? 'success' : ($status === 'rejected' ? 'danger' : 'info')]);
    }
    
    flash('success', 'Incident updated. Citizen has been notified.');
    redirect('admin/dashboard.php');
}
$stmt = db()->prepare('SELECT i.*, u.name AS citizen_name, u.email, u.phone FROM incidents i JOIN users u ON u.id=i.user_id WHERE i.id=?');
$stmt->execute([$id]);
$incident = $stmt->fetch();
if (!$incident) exit('Incident not found.');
$officers = db()->query("SELECT o.*, u.name FROM officers o JOIN users u ON u.id=o.user_id ORDER BY o.status='available' DESC, u.name")->fetchAll();
require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4"><div class="container"><div class="admin-card p-4"><h3><?= e($incident['title']) ?></h3><p><?= e($incident['description']) ?></p><div class="row"><div class="col-md-6"><p><strong>Citizen:</strong> <?= e($incident['citizen_name']) ?> | <?= e($incident['phone']) ?></p><p><strong>AI:</strong> <?= e($incident['category']) ?>, severity <?= e($incident['severity']) ?>/5</p><p><strong>Location:</strong> <?= e($incident['address']) ?> <?= e($incident['latitude']) ?>, <?= e($incident['longitude']) ?></p><p><strong>Current Status:</strong> <span class="badge bg-<?= $incident['status'] === 'resolved' ? 'success' : ($incident['status'] === 'in_progress' ? 'warning' : 'info') ?>"><?= ucfirst($incident['status']) ?></span></p><?php if ($incident['evidence_path']): ?><a class="btn btn-outline-light" target="_blank" href="../<?= e($incident['evidence_path']) ?>">View Evidence</a><?php endif; ?></div><div class="col-md-6"><form method="post"><input type="hidden" name="csrf_token" value="<?= csrf_token() ?>"><input type="hidden" name="id" value="<?= e($incident['id']) ?>"><label>Status</label><select class="form-select mb-3" name="status"><option value="submitted" <?= $incident['status'] === 'submitted' ? 'selected' : '' ?>>Submitted</option><option value="verified" <?= $incident['status'] === 'verified' ? 'selected' : '' ?>>Verified</option><option value="assigned" <?= $incident['status'] === 'assigned' ? 'selected' : '' ?>>Assigned</option><option value="in_progress" <?= $incident['status'] === 'in_progress' ? 'selected' : '' ?>>In Progress</option><option value="resolved" <?= $incident['status'] === 'resolved' ? 'selected' : '' ?>>Resolved</option><option value="rejected" <?= $incident['status'] === 'rejected' ? 'selected' : '' ?>>Rejected</option></select><label>Assign Officer</label><select class="form-select mb-3" name="officer_id"><option value="">Unassigned</option><?php foreach ($officers as $o): ?><option value="<?= e($o['user_id']) ?>" <?= $incident['officer_id'] == $o['user_id'] ? 'selected' : '' ?>><?= e($o['name']) ?> (<?= ucfirst($o['status']) ?>)</option><?php endforeach; ?></select><button class="btn btn-warning">Update Incident</button></form></div></div></div></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
