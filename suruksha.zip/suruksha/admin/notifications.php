<?php
require_once __DIR__ . '/../includes/helpers.php';
require_role(['admin','dispatcher']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    db()->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (NULL, ?, ?, ?)')->execute([trim($_POST['title']), trim($_POST['message']), $_POST['type']]);
    flash('success', 'Emergency notification broadcasted.');
    redirect('admin/dashboard.php');
}
require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4"><div class="container"><div class="admin-card p-4"><h3>Broadcast Emergency Alert</h3><form method="post"><input type="hidden" name="csrf_token" value="<?= csrf_token() ?>"><input class="form-control mb-3" name="title" placeholder="Alert title" required><textarea class="form-control mb-3" name="message" rows="4" placeholder="Alert message" required></textarea><select class="form-select mb-3" name="type"><option value="info">Info</option><option value="warning">Warning</option><option value="danger">Danger</option><option value="success">Success</option></select><button class="btn btn-warning">Broadcast</button></form></div></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
