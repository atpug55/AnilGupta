<?php
require_once __DIR__ . '/../includes/helpers.php';
require_role(['admin','super_admin','police_admin','station_incharge']);
$roles = ['super_admin' => 'Super Admin', 'police_admin' => 'Police Admin', 'station_incharge' => 'Station Incharge', 'officer' => 'Officer', 'emergency_operator' => 'Emergency Operator'];
$sections = ['Cyber Bureau','Traffic Police','Women Cell','Emergency Response','Crime Investigation','Missing Persons','Disaster Management'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name']);
    $username = trim($_POST['username']);
    $email = strtolower(trim($_POST['email']));
    $password = $_POST['password'];
    $role = $_POST['role'];
    $stationId = $_POST['police_station_id'] ?: null;
    $section = $_POST['section'];
    $badge = trim($_POST['badge_number']);
    
    if ($name && $username && filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($password) >= 8 && isset($roles[$role])) {
        try {
            db()->prepare('INSERT INTO users (name, username, email, password_hash, role, police_station_id, section, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 1)')
                ->execute([$name, $username, $email, password_hash($password, PASSWORD_DEFAULT), $role, $stationId, $section]);
            $userId = (int)db()->lastInsertId();
            $roleStmt = db()->prepare('SELECT id FROM officer_roles WHERE name = ? LIMIT 1');
            $roleStmt->execute([$roles[$role]]);
            $roleId = $roleStmt->fetch()['id'] ?? null;
            db()->prepare('INSERT INTO officers (user_id, police_station_id, officer_role_id, badge_number, section) VALUES (?, ?, ?, ?, ?)')
                ->execute([$userId, $stationId, $roleId, $badge ?: null, $section]);
            flash('success', 'Police account created. Officer can login immediately.');
            redirect('admin/officers.php');
        } catch (PDOException $e) {
            flash('danger', 'Username, email, or badge already exists.');
        }
    } else {
        flash('danger', 'Enter valid officer details. Password must be at least 8 characters.');
    }
}

$stations = db()->query('SELECT * FROM police_stations ORDER BY name')->fetchAll();
$officers = db()->query("SELECT u.id, u.name, u.username, u.email, u.role, u.section, u.created_at, ps.name AS station_name, o.badge_number, o.status FROM users u LEFT JOIN officers o ON o.user_id = u.id LEFT JOIN police_stations ps ON ps.id = u.police_station_id WHERE u.role IN ('super_admin','police_admin','station_incharge','officer','emergency_operator') ORDER BY u.created_at DESC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Officers Management</h2>
                <small class="text-white-50">Manage police officers and staff accounts</small>
            </div>
            <a class="btn btn-admin-primary" href="dashboard.php">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>

        <!-- Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-users fa-2x text-primary"></i>
                        </div>
                        <div>
                            <div class="metric"><?= count($officers) ?></div>
                            <small class="text-white-50">Total Officers</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-user-check fa-2x text-success"></i>
                        </div>
                        <div>
                            <div class="metric"><?= count(array_filter($officers, fn($o) => $o['status'] === 'available')) ?></div>
                            <small class="text-white-50">Available</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-user-clock fa-2x text-warning"></i>
                        </div>
                        <div>
                            <div class="metric"><?= count(array_filter($officers, fn($o) => $o['status'] === 'assigned')) ?></div>
                            <small class="text-white-50">Assigned</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-bed fa-2x text-secondary"></i>
                        </div>
                        <div>
                            <div class="metric"><?= count(array_filter($officers, fn($o) => $o['status'] === 'off_duty')) ?></div>
                            <small class="text-white-50">Off Duty</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Create Officer Form -->
        <div class="admin-card p-4 mb-4">
            <h4 class="fw-bold mb-3"><i class="fas fa-user-plus me-2 text-success"></i>Create New Officer Account</h4>
            <form method="post" class="row g-3">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <div class="col-md-3">
                    <label class="form-label">Full Name</label>
                    <input class="form-control form-control-admin" name="name" placeholder="Officer name" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Username</label>
                    <input class="form-control form-control-admin" name="username" placeholder="Username" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Email</label>
                    <input class="form-control form-control-admin" type="email" name="email" placeholder="Email" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Password</label>
                    <input class="form-control form-control-admin" type="password" name="password" placeholder="Password (min 8 chars)" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Badge Number</label>
                    <input class="form-control form-control-admin" name="badge_number" placeholder="Badge number">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Role</label>
                    <select class="form-select form-select-admin" name="role">
                        <?php foreach ($roles as $value => $label): ?>
                            <option value="<?= e($value) ?>"><?= e($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Police Station</label>
                    <select class="form-select form-select-admin" name="police_station_id">
                        <option value="">No station</option>
                        <?php foreach ($stations as $s): ?>
                            <option value="<?= e($s['id']) ?>"><?= e($s['name']) ?> - <?= e($s['district']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Section</label>
                    <select class="form-select form-select-admin" name="section">
                        <?php foreach ($sections as $section): ?>
                            <option><?= e($section) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-12">
                    <button class="btn btn-admin-success">
                        <i class="fas fa-plus me-2"></i>Create Officer Account
                    </button>
                </div>
            </form>
        </div>

        <!-- Officers Table -->
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0"><i class="fas fa-list me-2 text-primary"></i>All Officers</h4>
                <span class="badge bg-info"><?= count($officers) ?> Total</span>
            </div>
            
            <div class="table-responsive">
                <table class="table table-admin table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Badge Number</th>
                            <th>Section</th>
                            <th>Station</th>
                            <th>Status</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($officers as $o): ?>
                            <tr>
                                <td>
                                    <strong><?= e($o['name']) ?></strong>
                                </td>
                                <td><?= e($o['username']) ?></td>
                                <td>
                                    <span class="badge bg-primary"><?= e($o['role']) ?></span>
                                </td>
                                <td><?= e($o['badge_number'] ?? '-') ?></td>
                                <td><?= e($o['section'] ?? '-') ?></td>
                                <td><?= e($o['station_name'] ?? 'No Station') ?></td>
                                <td>
                                    <span class="officer-status officer-status-<?= $o['status'] ?? 'available' ?>">
                                        <?= ucfirst($o['status'] ?? 'available') ?>
                                    </span>
                                </td>
                                <td><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
