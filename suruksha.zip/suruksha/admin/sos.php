<?php
require_once __DIR__ . '/../includes/helpers.php';
require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    verify_csrf();
    $allowedStatuses = ['active', 'acknowledged', 'resolved', 'false_alarm'];
    $status = in_array($_POST['status'] ?? '', $allowedStatuses, true) ? $_POST['status'] : 'active';
    $responseMessage = trim($_POST['response_message'] ?? '');
    $resolutionNotes = trim($_POST['resolution_notes'] ?? '');
    
    // Get old status for comparison
    $oldSos = db()->prepare('SELECT status, user_id, emergency_category, latitude, longitude, address FROM sos_alerts WHERE id = ?');
    $oldSos->execute([(int)$_POST['id']]);
    $oldData = $oldSos->fetch();
    
    if (!$oldData) {
        flash('danger', 'SOS alert not found.');
        redirect('admin/sos.php');
    }
    
    // If false alarm, delete the SOS from database after sending notification
    if ($status === 'false_alarm') {
        // Delete the SOS record
        db()->prepare('DELETE FROM sos_alerts WHERE id=?')->execute([(int)$_POST['id']]);
    } else {
        // Update SOS status with additional fields
        $updateQuery = 'UPDATE sos_alerts SET status=?, updated_at=NOW()';
        $updateParams = [$status];
        
        if ($status === 'resolved' && $resolutionNotes) {
            $updateQuery .= ', ai_summary=?';
            $updateParams[] = 'RESOLVED: ' . $resolutionNotes;
        }
        
        $updateQuery .= ' WHERE id=?';
        $updateParams[] = (int)$_POST['id'];
        
        db()->prepare($updateQuery)->execute($updateParams);
    }
    
    // Add notification for citizen if status changed
    if ($oldData['status'] !== $status) {
        $statusMessages = [
            'active' => 'Your SOS is active and being monitored',
            'acknowledged' => 'Your SOS has been acknowledged by authorities. Help is on the way.',
            'resolved' => 'Your emergency has been resolved. ' . ($responseMessage ?: 'Stay safe.'),
            'false_alarm' => 'Your SOS was marked as false alarm. If this was an emergency, please contact authorities directly.'
        ];
        
        $message = $statusMessages[$status] ?? "Your SOS status has been updated to: $status";
        if ($responseMessage && $status === 'resolved') {
            $message .= " Response: " . $responseMessage;
        }
        if ($resolutionNotes && $status === 'resolved') {
            $message .= " Resolution Notes: " . $resolutionNotes;
        }
        
        db()->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)')
            ->execute([$oldData['user_id'], "SOS Status Updated: " . e($oldData['emergency_category']), $message, $status === 'resolved' ? 'success' : ($status === 'false_alarm' ? 'warning' : 'info')]);
    }
    
    flash('success', 'SOS status updated. Citizen has been notified.');
    redirect('admin/sos.php');
}

// Get all SOS alerts with pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 15;
$offset = ($page - 1) * $perPage;

// Filter by status
$statusFilter = $_GET['status'] ?? '';
$whereClause = '';
$params = [];

if ($statusFilter && in_array($statusFilter, ['active', 'acknowledged', 'resolved', 'false_alarm'])) {
    $whereClause = 'WHERE s.status = ?';
    $params[] = $statusFilter;
}

$totalQuery = "SELECT COUNT(*) as count FROM sos_alerts s $whereClause";
$totalStmt = db()->prepare($totalQuery);
$totalStmt->execute($params);
$totalCount = $totalStmt->fetch()['count'];
$totalPages = ceil($totalCount / $perPage);

$query = "SELECT s.*, u.name AS citizen_name, u.phone AS citizen_phone, u.email AS citizen_email, u.profile_photo, (SELECT ip_address FROM sos_logs WHERE sos_alert_id=s.id ORDER BY created_at DESC LIMIT 1) AS ip_address FROM sos_alerts s JOIN users u ON u.id=s.user_id $whereClause ORDER BY s.created_at DESC LIMIT ? OFFSET ?";
$sosStmt = db()->prepare($query);
$sosStmt->execute(array_merge($params, [$perPage, $offset]));
$sosAlerts = $sosStmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Emergency SOS Management</h2>
                <small class="text-white-50">Track and manage all SOS emergency alerts</small>
            </div>
            <a class="btn btn-admin-primary" href="dashboard.php">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>

        <!-- Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-folder fa-2x text-info"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM sos_alerts")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Total</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3 emergency-flash">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-exclamation-circle fa-2x text-danger"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM sos_alerts WHERE status='active'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Active</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-check-circle fa-2x text-warning"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM sos_alerts WHERE status='acknowledged'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Acknowledged</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-check-double fa-2x text-success"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM sos_alerts WHERE status='resolved'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Resolved</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter -->
        <div class="admin-card p-4 mb-4">
            <div class="d-flex align-items-center gap-3 flex-wrap">
                <h5 class="fw-bold mb-0"><i class="fas fa-filter me-2"></i>Filter by Status:</h5>
                <div class="filter-pills">
                    <a href="sos.php" class="filter-pill <?= $statusFilter === '' ? 'active' : '' ?>">All</a>
                    <a href="?status=active" class="filter-pill <?= $statusFilter === 'active' ? 'active' : '' ?>">Active</a>
                    <a href="?status=acknowledged" class="filter-pill <?= $statusFilter === 'acknowledged' ? 'active' : '' ?>">Acknowledged</a>
                    <a href="?status=resolved" class="filter-pill <?= $statusFilter === 'resolved' ? 'active' : '' ?>">Resolved</a>
                    <a href="?status=false_alarm" class="filter-pill <?= $statusFilter === 'false_alarm' ? 'active' : '' ?>">False Alarm</a>
                </div>
            </div>
        </div>

        <!-- SOS Alerts Table -->
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0"><i class="fas fa-list me-2 text-primary"></i>Emergency SOS Alerts</h4>
                <span class="badge bg-info"><?= $totalCount ?> Total</span>
            </div>
            
            <?php if (count($sosAlerts) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-admin table-hover">
                        <thead>
                            <tr>
                                <th>Citizen</th>
                                <th>Emergency Type</th>
                                <th>Location</th>
                                <th>Time Pressed</th>
                                <th>Device Info</th>
                                <th>Status</th>
                                <th>Severity</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sosAlerts as $sos): ?>
                                <tr class="<?= $sos['status'] === 'active' ? 'table-danger' : '' ?>">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if ($sos['profile_photo']): ?>
                                                <img src="<?= APP_URL ?>/<?= e($sos['profile_photo']) ?>" alt="Photo" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-user text-white"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <strong><?= e($sos['citizen_name']) ?></strong>
                                                <div class="small text-black-50"><?= e($sos['citizen_phone']) ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger"><?= e($sos['emergency_category']) ?></span>
                                    </td>
                                    <td>
                                        <div>
                                            <i class="fas fa-map-marker-alt me-1"></i>
                                            <?= e(substr($sos['address'] ?? 'Unknown location', 0, 25)) ?>...
                                        </div>
                                        <small class="text-black-50">
                                            <?= e($sos['latitude']) ?>, <?= e($sos['longitude']) ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div>
                                            <i class="fas fa-clock me-1"></i>
                                            <?= date('M d, Y H:i:s', strtotime($sos['created_at'])) ?>
                                        </div>
                                        <?php if ($sos['last_active_at']): ?>
                                            <small class="text-black-50">
                                                Last active: <?= date('H:i:s', strtotime($sos['last_active_at'])) ?>
                                            </small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-cyan-solid" data-bs-toggle="modal" data-bs-target="#deviceModal<?= e($sos['id']) ?>">
                                            <i class="fas fa-mobile-alt me-1"></i>View Device
                                        </button>
                                    </td>
                                    <td>
                                        <span class="status-pill status-pill-<?= $sos['status'] === 'resolved' ? 'resolved' : ($sos['status'] === 'active' ? 'critical' : 'pending') ?>">
                                            <?= ucfirst($sos['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="priority-badge priority-<?= $sos['severity'] >= 4 ? 'critical' : ($sos['severity'] >= 3 ? 'high' : 'medium') ?>">
                                            <?= $sos['severity'] ?>/5
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-admin-primary" data-bs-toggle="modal" data-bs-target="#detailModal<?= e($sos['id']) ?>">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button type="button" class="btn btn-sm btn-admin-warning" data-bs-toggle="modal" data-bs-target="#updateModal<?= e($sos['id']) ?>">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php if ($sos['latitude'] && $sos['longitude']): ?>
                                                <a href="https://maps.google.com/?q=<?= e($sos['latitude']) ?>,<?= e($sos['longitude']) ?>" target="_blank" class="btn btn-sm btn-admin-success">
                                                    <i class="fas fa-map"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link bg-dark text-white border-secondary" href="?page=<?= $page - 1 ?>&status=<?= $statusFilter ?>">Previous</a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link <?= $i === $page ? 'bg-primary' : 'bg-dark text-white border-secondary' ?>" href="?page=<?= $i ?>&status=<?= $statusFilter ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link bg-dark text-white border-secondary" href="?page=<?= $page + 1 ?>&status=<?= $statusFilter ?>">Next</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-exclamation-triangle fa-4x mb-3 text-white" style="opacity: 0.6;"></i>
                    <p class="mb-0 text-white-50">No SOS alerts found</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Detail Modals -->
<?php foreach ($sosAlerts as $sos): ?>
<div class="modal fade" id="detailModal<?= e($sos['id']) ?>" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">
                    <i class="fas fa-exclamation-triangle me-2 text-danger"></i>SOS Alert Details
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center mb-3">
                            <?php if ($sos['profile_photo']): ?>
                                <img src="<?= APP_URL ?>/<?= e($sos['profile_photo']) ?>" alt="Photo" class="rounded-circle" style="width: 120px; height: 120px; object-fit: cover;">
                            <?php else: ?>
                                <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mx-auto" style="width: 120px; height: 120px; font-size: 3rem;">
                                    <i class="fas fa-user text-white"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <h5 class="text-center"><?= e($sos['citizen_name']) ?></h5>
                        <p class="text-center text-white-50"><?= e($sos['citizen_phone']) ?></p>
                        <p class="text-center text-white-50"><?= e($sos['citizen_email']) ?></p>
                    </div>
                    <div class="col-md-8">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="admin-card p-3">
                                    <small class="text-white-50">Emergency Type</small>
                                    <div class="fw-bold text-danger"><?= e($sos['emergency_category']) ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="admin-card p-3">
                                    <small class="text-white-50">Severity</small>
                                    <div class="fw-bold"><?= $sos['severity'] ?>/5</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="admin-card p-3">
                                    <small class="text-white-50">Status</small>
                                    <div>
                                        <span class="status-pill status-pill-<?= $sos['status'] === 'resolved' ? 'resolved' : ($sos['status'] === 'active' ? 'critical' : 'pending') ?>">
                                            <?= ucfirst($sos['status']) ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="admin-card p-3">
                                    <small class="text-white-50">Time Pressed</small>
                                    <div><?= date('M d, Y H:i:s', strtotime($sos['created_at'])) ?></div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="admin-card p-3">
                                    <small class="text-white-50">Location</small>
                                    <div class="fw-bold"><?= e($sos['address'] ?? 'Unknown location') ?></div>
                                    <small class="text-white-50">
                                        Lat: <?= e($sos['latitude']) ?>, Lng: <?= e($sos['longitude']) ?>
                                    </small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="admin-card p-3">
                                    <small class="text-white-50">Device Info</small>
                                    <div><?= e($sos['device_info'] ?? 'Unknown') ?></div>
                                    <button type="button" class="btn btn-sm btn-outline-info mt-2" data-bs-toggle="modal" data-bs-target="#deviceModal<?= e($sos['id']) ?>">
                                        <i class="fas fa-info-circle me-1"></i>View Full Details
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="admin-card p-3">
                                    <small class="text-white-50">Battery Level</small>
                                    <div><?= e($sos['battery_level'] ?? 'Unknown') ?>%</div>
                                </div>
                            </div>
                            <?php if ($sos['speed_kmh']): ?>
                                <div class="col-md-6">
                                    <div class="admin-card p-3">
                                        <small class="text-white-50">Movement Speed</small>
                                        <div><?= e($sos['speed_kmh']) ?> km/h</div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if ($sos['movement_direction']): ?>
                                <div class="col-md-6">
                                    <div class="admin-card p-3">
                                        <small class="text-white-50">Direction</small>
                                        <div><?= e($sos['movement_direction']) ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if ($sos['ai_summary']): ?>
                                <div class="col-12">
                                    <div class="admin-card p-3">
                                        <small class="text-white-50">AI Summary</small>
                                        <div><?= e($sos['ai_summary']) ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="updateModal<?= e($sos['id']) ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">Update SOS Status - <?= e($sos['citizen_name']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="id" value="<?= e($sos['id']) ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Current Status</label>
                        <div>
                            <span class="status-pill status-pill-<?= $sos['status'] === 'resolved' ? 'resolved' : ($sos['status'] === 'active' ? 'critical' : 'pending') ?>">
                                <?= ucfirst($sos['status']) ?>
                            </span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Update Status</label>
                        <select class="form-select form-select-admin" name="status" id="statusSelect<?= e($sos['id']) ?>">
                            <option value="active" <?= $sos['status'] === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="acknowledged" <?= $sos['status'] === 'acknowledged' ? 'selected' : '' ?>>Acknowledged</option>
                            <option value="resolved" <?= $sos['status'] === 'resolved' ? 'selected' : '' ?>>Resolved</option>
                            <option value="false_alarm" <?= $sos['status'] === 'false_alarm' ? 'selected' : '' ?>>False Alarm</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Response Message (sent to citizen)</label>
                        <textarea class="form-control form-control-admin" name="response_message" rows="2" placeholder="Optional message to send to citizen..."></textarea>
                    </div>
                    <div class="mb-3" id="resolutionNotesDiv<?= e($sos['id']) ?>" style="display: none;">
                        <label class="form-label">Resolution Notes (internal record)</label>
                        <textarea class="form-control form-control-admin" name="resolution_notes" rows="3" placeholder="Detailed resolution notes for internal records..."></textarea>
                    </div>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        The citizen will be automatically notified of this status change.
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-admin-success">Update Status</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Device Details Modal -->
<?php
$deviceInfo = parse_device_info($sos['device_info'] ?? null);
$deviceIcon = $deviceInfo['device_type'] === 'Mobile' ? 'mobile-alt' : ($deviceInfo['device_type'] === 'Tablet' ? 'tablet-alt' : 'desktop');
$osIcon = 'globe';
if (stripos($deviceInfo['os'], 'Windows') !== false) $osIcon = 'windows';
elseif (stripos($deviceInfo['os'], 'Android') !== false) $osIcon = 'android';
elseif (stripos($deviceInfo['os'], 'iOS') !== false || stripos($deviceInfo['os'], 'macOS') !== false) $osIcon = 'apple';
elseif (stripos($deviceInfo['os'], 'Linux') !== false) $osIcon = 'linux';
$browserIcon = 'globe';
if (stripos($deviceInfo['browser'], 'Chrome') !== false) $browserIcon = 'chrome';
elseif (stripos($deviceInfo['browser'], 'Firefox') !== false) $browserIcon = 'firefox';
elseif (stripos($deviceInfo['browser'], 'Safari') !== false) $browserIcon = 'safari';
elseif (stripos($deviceInfo['browser'], 'Edge') !== false) $browserIcon = 'edge';
?>
<div class="modal fade" id="deviceModal<?= e($sos['id']) ?>" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">
                    <i class="fas fa-mobile-alt me-2 text-info"></i>Device Information
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">IP Address</small>
                            <div class="fw-bold text-info"><?= e($sos['ip_address'] ?? 'Not available') ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Device Type</small>
                            <div class="fw-bold">
                                <i class="fas fa-<?= $deviceIcon ?> me-2"></i>
                                <?= e($deviceInfo['device_type']) ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Operating System</small>
                            <div class="fw-bold">
                                <i class="fab fa-<?= $osIcon ?> me-2"></i>
                                <?= e($deviceInfo['os']) ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Browser</small>
                            <div class="fw-bold">
                                <i class="fab fa-<?= $browserIcon ?> me-2"></i>
                                <?= e($deviceInfo['browser']) ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Platform/Architecture</small>
                            <div class="fw-bold"><?= e($deviceInfo['platform']) ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Battery Level</small>
                            <div class="fw-bold">
                                <?php if ($sos['battery_level']): ?>
                                    <span class="<?= $sos['battery_level'] < 20 ? 'text-danger' : ($sos['battery_level'] < 50 ? 'text-warning' : 'text-success') ?>">
                                        <?= e($sos['battery_level']) ?>%
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">Unknown</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php if ($sos['speed_kmh']): ?>
                        <div class="col-md-6">
                            <div class="admin-card p-3">
                                <small class="text-white-50">Movement Speed</small>
                                <div class="fw-bold"><?= e($sos['speed_kmh']) ?> km/h</div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ($sos['movement_direction']): ?>
                        <div class="col-md-6">
                            <div class="admin-card p-3">
                                <small class="text-white-50">Movement Direction</small>
                                <div class="fw-bold"><?= e($sos['movement_direction']) ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="col-12">
                        <div class="admin-card p-3">
                            <small class="text-white-50">Raw User Agent String</small>
                            <div class="small text-white-50 font-monospace" style="word-break: break-all; font-family: monospace; font-size: 0.85rem;">
                                <?= e($deviceInfo['raw']) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-secondary">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<script>
// Show resolution notes field only when status is "resolved"
document.addEventListener('DOMContentLoaded', function() {
    <?php foreach ($sosAlerts as $sos): ?>
    const statusSelect<?= e($sos['id']) ?> = document.getElementById('statusSelect<?= e($sos['id']) ?>');
    const resolutionNotesDiv<?= e($sos['id']) ?> = document.getElementById('resolutionNotesDiv<?= e($sos['id']) ?>');
    
    if (statusSelect<?= e($sos['id']) ?> && resolutionNotesDiv<?= e($sos['id']) ?>) {
        statusSelect<?= e($sos['id']) ?>.addEventListener('change', function() {
            if (this.value === 'resolved') {
                resolutionNotesDiv<?= e($sos['id']) ?>.style.display = 'block';
            } else {
                resolutionNotesDiv<?= e($sos['id']) ?>.style.display = 'none';
            }
        });
        
        // Initialize based on current status
        if (statusSelect<?= e($sos['id']) ?>.value === 'resolved') {
            resolutionNotesDiv<?= e($sos['id']) ?>.style.display = 'block';
        }
    }
    <?php endforeach; ?>
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
