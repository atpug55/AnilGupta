<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['admin','dispatcher','police_admin','station_incharge','emergency_operator']);

// Handle status update and officer assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_incident') {
    verify_csrf();
    $allowedStatuses = ['submitted', 'verified', 'assigned', 'in_progress', 'resolved', 'rejected'];
    $status = in_array($_POST['status'] ?? '', $allowedStatuses, true) ? $_POST['status'] : 'submitted';
    $officerId = $_POST['officer_id'] ?: null;
    
    // Get old status for comparison
    $oldIncident = db()->prepare('SELECT status, user_id, title FROM incidents WHERE id = ?');
    $oldIncident->execute([(int)$_POST['id']]);
    $oldData = $oldIncident->fetch();
    
    // Update incident
    db()->prepare('UPDATE incidents SET status = ?, officer_id = ? WHERE id = ?')->execute([$status, $officerId, (int)$_POST['id']]);
    
    // Update officer status if assigned
    if ($officerId) {
        db()->prepare("UPDATE officers SET status='assigned' WHERE user_id=?")->execute([$officerId]);
    }
    
    // Add notification for citizen if status changed
    if ($oldData && $oldData['status'] !== $status) {
        $statusMessages = [
            'submitted' => 'Your report has been submitted',
            'verified' => 'Your report has been verified',
            'assigned' => 'An officer has been assigned to your report',
            'in_progress' => 'Your report is being processed',
            'resolved' => 'Your report has been resolved',
            'rejected' => 'Your report has been rejected'
        ];
        
        $message = $statusMessages[$status] ?? "Your report status has been updated to: $status";
        
        db()->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)')
            ->execute([$oldData['user_id'], "Report Status Updated: " . e($oldData['title']), $message, $status === 'resolved' ? 'success' : ($status === 'rejected' ? 'danger' : 'info')]);
    }
    
    flash('success', 'Incident updated. Citizen has been notified.');
    redirect('admin/incidents.php');
}

// Get all incidents with pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 15;
$offset = ($page - 1) * $perPage;

// Filter by status and severity
$statusFilter = $_GET['status'] ?? '';
$severityFilter = $_GET['severity'] ?? '';
$whereClause = 'WHERE 1=1';
$params = [];

if ($statusFilter && in_array($statusFilter, ['submitted', 'verified', 'assigned', 'in_progress', 'resolved', 'rejected'])) {
    $whereClause .= ' AND i.status = ?';
    $params[] = $statusFilter;
}

if ($severityFilter && in_array($severityFilter, ['1', '2', '3', '4', '5'])) {
    $whereClause .= ' AND i.severity = ?';
    $params[] = (int)$severityFilter;
}

$totalQuery = "SELECT COUNT(*) as count FROM incidents i $whereClause";
$totalStmt = db()->prepare($totalQuery);
$totalStmt->execute($params);
$totalCount = $totalStmt->fetch()['count'];
$totalPages = ceil($totalCount / $perPage);

$query = "SELECT i.*, u.name AS citizen_name, u.phone AS citizen_phone, officer.name AS officer_name, o.badge_number FROM incidents i JOIN users u ON u.id=i.user_id LEFT JOIN officers o ON o.user_id=i.officer_id LEFT JOIN users officer ON officer.id=i.officer_id $whereClause ORDER BY i.severity DESC, i.created_at DESC LIMIT ? OFFSET ?";
$incidentsStmt = db()->prepare($query);
$incidentsStmt->execute(array_merge($params, [$perPage, $offset]));
$incidents = $incidentsStmt->fetchAll();

// Get officers for assignment
$officers = db()->query("SELECT o.*, u.name FROM officers o JOIN users u ON u.id=o.user_id ORDER BY o.status='available' DESC, u.name")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<link rel="stylesheet" href="<?= APP_URL ?>/assets/css/admin.css">
<div class="admin-shell py-4">
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
            <div>
                <h2 class="fw-bold mb-1">Incidents Management</h2>
                <small class="text-white-50">Track and manage all incident reports</small>
            </div>
            <a class="btn btn-admin-primary" href="dashboard.php">
                <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
            </a>
        </div>

        <!-- Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-2">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-2">
                            <i class="fas fa-folder fa-2x text-info"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM incidents")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Total</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-2">
                            <i class="fas fa-clock fa-2x text-primary"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM incidents WHERE status='submitted'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Pending</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-2">
                            <i class="fas fa-cog fa-2x text-warning"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM incidents WHERE status='in_progress'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">In Progress</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-2">
                            <i class="fas fa-check-circle fa-2x text-success"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM incidents WHERE status='resolved'")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Resolved</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-2">
                            <i class="fas fa-fire fa-2x text-danger"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM incidents WHERE severity >= 4")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">High Severity</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="admin-card p-3">
                    <div class="d-flex align-items-center">
                        <div class="me-2">
                            <i class="fas fa-user-shield fa-2x text-success"></i>
                        </div>
                        <div>
                            <div class="metric"><?= db()->query("SELECT COUNT(*) FROM incidents WHERE officer_id IS NOT NULL")->fetch()['COUNT(*)'] ?></div>
                            <small class="text-white-50">Assigned</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filter -->
        <div class="admin-card p-4 mb-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <h5 class="fw-bold mb-2"><i class="fas fa-filter me-2"></i>Filter by Status:</h5>
                    <div class="filter-pills">
                        <a href="incidents.php" class="filter-pill <?= $statusFilter === '' ? 'active' : '' ?>">All</a>
                        <a href="?status=submitted" class="filter-pill <?= $statusFilter === 'submitted' ? 'active' : '' ?>">Submitted</a>
                        <a href="?status=verified" class="filter-pill <?= $statusFilter === 'verified' ? 'active' : '' ?>">Verified</a>
                        <a href="?status=assigned" class="filter-pill <?= $statusFilter === 'assigned' ? 'active' : '' ?>">Assigned</a>
                        <a href="?status=in_progress" class="filter-pill <?= $statusFilter === 'in_progress' ? 'active' : '' ?>">In Progress</a>
                        <a href="?status=resolved" class="filter-pill <?= $statusFilter === 'resolved' ? 'active' : '' ?>">Resolved</a>
                        <a href="?status=rejected" class="filter-pill <?= $statusFilter === 'rejected' ? 'active' : '' ?>">Rejected</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <h5 class="fw-bold mb-2"><i class="fas fa-signal me-2"></i>Filter by Severity:</h5>
                    <div class="filter-pills">
                        <a href="incidents.php" class="filter-pill <?= $severityFilter === '' ? 'active' : '' ?>">All</a>
                        <a href="?severity=5" class="filter-pill <?= $severityFilter === '5' ? 'active' : '' ?>">Critical (5)</a>
                        <a href="?severity=4" class="filter-pill <?= $severityFilter === '4' ? 'active' : '' ?>">High (4)</a>
                        <a href="?severity=3" class="filter-pill <?= $severityFilter === '3' ? 'active' : '' ?>">Medium (3)</a>
                        <a href="?severity=2" class="filter-pill <?= $severityFilter === '2' ? 'active' : '' ?>">Low (2)</a>
                        <a href="?severity=1" class="filter-pill <?= $severityFilter === '1' ? 'active' : '' ?>">Minor (1)</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Incidents Table -->
        <div class="admin-card p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="fw-bold mb-0"><i class="fas fa-list me-2 text-primary"></i>Incident Reports</h4>
                <span class="badge bg-info"><?= $totalCount ?> Total</span>
            </div>
            
            <?php if (count($incidents) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-admin table-hover">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Category</th>
                                <th>Severity</th>
                                <th>Status</th>
                                <th>Citizen</th>
                                <th>Officer</th>
                                <th>Location</th>
                                <th>Evidence</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($incidents as $incident): ?>
                                <tr>
                                    <td>
                                        <strong><?= e($incident['title']) ?></strong>
                                        <?php if ($incident['is_spam']): ?>
                                            <span class="badge bg-warning ms-1">⚠️ Spam Risk</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= e($incident['category']) ?></td>
                                    <td>
                                        <span class="priority-badge priority-<?= $incident['severity'] >= 4 ? 'critical' : ($incident['severity'] >= 3 ? 'high' : ($incident['severity'] >= 2 ? 'medium' : 'low')) ?>">
                                            <?= $incident['severity'] ?>/5
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-pill status-pill-<?= $incident['status'] === 'resolved' ? 'resolved' : ($incident['status'] === 'in_progress' ? 'assigned' : ($incident['status'] === 'rejected' ? 'pending' : 'pending')) ?>">
                                            <?= ucfirst($incident['status']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div><?= e($incident['citizen_name']) ?></div>
                                        <small class="text-black-50"><?= e($incident['citizen_phone']) ?></small>
                                    </td>
                                    <td>
                                        <?php if ($incident['officer_name']): ?>
                                            <div><?= e($incident['officer_name']) ?></div>
                                            <small class="text-black-50"><?= e($incident['badge_number'] ?? '-') ?></small>
                                        <?php else: ?>
                                            <span class="text-muted">Unassigned</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($incident['address']): ?>
                                            <small><?= e(substr($incident['address'], 0, 20)) ?>...</small>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($incident['evidence_path']): ?>
                                            <a href="<?= APP_URL ?>/<?= e($incident['evidence_path']) ?>" target="_blank" class="btn btn-sm btn-admin-success">
                                                <i class="fas fa-paperclip"></i>
                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('M d, H:i', strtotime($incident['created_at'])) ?></td>
                                    <td>
                                        <button type="button" class="btn btn-sm btn-admin-primary" data-bs-toggle="modal" data-bs-target="#updateModal<?= e($incident['id']) ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav class="mt-4">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link bg-dark text-white border-secondary" href="?page=<?= $page - 1 ?>&status=<?= $statusFilter ?>&severity=<?= $severityFilter ?>">Previous</a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                    <a class="page-link <?= $i === $page ? 'bg-primary' : 'bg-dark text-white border-secondary' ?>" href="?page=<?= $i ?>&status=<?= $statusFilter ?>&severity=<?= $severityFilter ?>"><?= $i ?></a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link bg-dark text-white border-secondary" href="?page=<?= $page + 1 ?>&status=<?= $statusFilter ?>&severity=<?= $severityFilter ?>">Next</a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center text-muted py-5">
                    <i class="fas fa-file-alt fa-4x mb-3" style="opacity: 0.3;"></i>
                    <p class="mb-0">No incidents found</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Update Incident Modals -->
<?php foreach ($incidents as $incident): ?>
<div class="modal fade" id="updateModal<?= e($incident['id']) ?>" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content" style="background: var(--admin-card); color: white; border: 1px solid var(--admin-border);">
            <div class="modal-header border-secondary">
                <h5 class="modal-title">Manage Incident - <?= e($incident['title']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                <input type="hidden" name="action" value="update_incident">
                <input type="hidden" name="id" value="<?= e($incident['id']) ?>">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Description</label>
                                <div class="p-3 bg-dark rounded" style="background: rgba(0,0,0,0.3);">
                                    <?= e($incident['description']) ?>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">AI Summary</label>
                                <div class="p-3 bg-dark rounded" style="background: rgba(0,0,0,0.3);">
                                    <?= e($incident['ai_summary'] ?? 'No AI summary available') ?>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Location</label>
                                <div><?= e($incident['address'] ?? 'Not provided') ?></div>
                                <?php if ($incident['latitude'] && $incident['longitude']): ?>
                                    <small class="text-white-50">
                                        Lat: <?= e($incident['latitude']) ?>, Lng: <?= e($incident['longitude']) ?>
                                    </small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Current Status</label>
                                <div>
                                    <span class="status-pill status-pill-<?= $incident['status'] === 'resolved' ? 'resolved' : ($incident['status'] === 'in_progress' ? 'assigned' : 'pending') ?>">
                                        <?= ucfirst($incident['status']) ?>
                                    </span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Update Status</label>
                                <select class="form-select form-select-admin" name="status">
                                    <option value="submitted" <?= $incident['status'] === 'submitted' ? 'selected' : '' ?>>Submitted</option>
                                    <option value="verified" <?= $incident['status'] === 'verified' ? 'selected' : '' ?>>Verified</option>
                                    <option value="assigned" <?= $incident['status'] === 'assigned' ? 'selected' : '' ?>>Assigned</option>
                                    <option value="in_progress" <?= $incident['status'] === 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                                    <option value="resolved" <?= $incident['status'] === 'resolved' ? 'selected' : '' ?>>Resolved</option>
                                    <option value="rejected" <?= $incident['status'] === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Assign Officer</label>
                                <select class="form-select form-select-admin" name="officer_id">
                                    <option value="">Unassigned</option>
                                    <?php foreach ($officers as $o): ?>
                                        <option value="<?= e($o['user_id']) ?>" <?= $incident['officer_id'] == $o['user_id'] ? 'selected' : '' ?>>
                                            <?= e($o['name']) ?> - <?= e($o['badge_number'] ?? '-') ?> (<?= ucfirst($o['status']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                The citizen will be automatically notified of status changes.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-admin-success">Update Incident</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
