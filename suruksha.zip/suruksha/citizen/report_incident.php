<?php
require_once __DIR__ . '/../includes/ai.php';
require_once __DIR__ . '/../includes/upload.php';
require_once __DIR__ . '/../includes/emergency_mailer.php';
require_once __DIR__ . '/../includes/language.php';
$user = require_role(['citizen']);

// Handle language change
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ne'])) {
    set_language($_GET['lang']);
    header('Location: ' . APP_URL . '/citizen/report_incident.php');
    exit;
}

// Get user's recent reports for status tracking
$recentReports = db()->prepare('SELECT * FROM incidents WHERE user_id = ? ORDER BY created_at DESC LIMIT 5');
$recentReports->execute([$user['id']]);
$reports = $recentReports->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    try {
        $evidencePath = null;
        $evidenceType = null;
        
        // Handle evidence upload
        if (isset($_FILES['evidence']) && $_FILES['evidence']['error'] === UPLOAD_ERR_OK) {
            [$evidencePath, $evidenceType] = save_upload('evidence', ['image/jpeg','image/png','image/webp','video/mp4','video/webm']);
        }
        
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? 'General');
        $language = $_POST['language'] ?? 'auto';
        
        $ai = analyze_incident_with_ai($title, $description, $language);
        $stmt = db()->prepare('INSERT INTO incidents (user_id, title, description, category, severity, latitude, longitude, address, evidence_path, evidence_type, language, is_spam, ai_summary) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$user['id'], $title, $description, $ai['category'], $ai['severity'], $_POST['latitude'] ?: null, $_POST['longitude'] ?: null, trim($_POST['address'] ?? ''), $evidencePath, $evidenceType, $language, $ai['is_spam'] ? 1 : 0, $ai['summary']]);
        $incidentId = (int)db()->lastInsertId();
        
        if ((int)$ai['severity'] >= 4 && !$ai['is_spam']) {
            $caseStmt = db()->prepare('SELECT i.*, u.name AS citizen_name, u.phone, u.email FROM incidents i JOIN users u ON u.id = i.user_id WHERE i.id = ?');
            $caseStmt->execute([$incidentId]);
            $case = $caseStmt->fetch();
            if ($case) {
                send_emergency_alert_emails($case, 'High Priority Incident', $ai['category'], 'incident');
            }
        }
        flash('success', 'Incident submitted successfully. Track status on your dashboard.');
        redirect('citizen/dashboard.php');
    } catch (Throwable $e) {
        flash('danger', $e->getMessage());
    }
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
    <div class="row g-4">
        <!-- Language Switcher and Back Button -->
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i><?= t('back') ?>
                </a>
                <div class="d-flex gap-2">
                    <a href="?lang=en" class="btn btn-sm btn-outline-primary <?= get_language() === 'en' ? 'active' : '' ?>">English</a>
                    <a href="?lang=ne" class="btn btn-sm btn-outline-primary <?= get_language() === 'ne' ? 'active' : '' ?>">नेपाली</a>
                </div>
            </div>
        </div>
        
        <!-- Report Form -->
        <div class="col-lg-8">
            <div class="card dashboard-card p-4">
                <div class="d-flex align-items-center mb-4">
                    <i class="fas fa-exclamation-triangle fa-2x text-danger me-3"></i>
                    <div>
                        <h3 class="mb-0"><?= t('report_crime_emergency') ?></h3>
                        <p class="text-muted mb-0"><?= t('submit_incident_evidence') ?></p>
                    </div>
                </div>
                
                <form method="post" enctype="multipart/form-data" id="incidentForm">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <input type="hidden" name="latitude" id="latitude">
                    <input type="hidden" name="longitude" id="longitude">
                    
                    <!-- Language Selection -->
                    <div class="row g-3 mb-4">
                        
                        <div class="col-md-6">
                            <label class="form-label fw-bold">
                                <i class="fas fa-tag me-2"></i><?= t('category') ?>
                            </label>
                            <select class="form-select" name="category" id="categorySelect">
                                <option value="General"><?= t('general') ?></option>
                                <option value="Theft"><?= t('theft') ?></option>
                                <option value="Assault"><?= t('assault') ?></option>
                                <option value="Fraud"><?= t('fraud') ?></option>
                                <option value="Vandalism"><?= t('vandalism') ?></option>
                                <option value="Traffic"><?= t('traffic') ?></option>
                                <option value="Other"><?= t('other') ?></option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Title -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">
                            <i class="fas fa-heading me-2"></i><?= t('report_title') ?> <span class="text-danger">*</span>
                        </label>
                        <input class="form-control" name="title" placeholder="<?= t('enter_incident_title') ?>" required>
                    </div>
                    
                    <!-- Description -->
                    <div class="mb-3">
                        <label class="form-label fw-bold">
                            <i class="fas fa-align-left me-2"></i><?= t('description') ?> <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control" name="description" rows="5" placeholder="<?= t('describe_what_happened') ?>" required></textarea>
                    </div>
                    
                    <!-- Location -->
                    <div class="row g-3 mb-3">
                        <div class="col-md-8">
                            <label class="form-label fw-bold">
                                <i class="fas fa-map-marker-alt me-2"></i><?= t('address') ?>
                            </label>
                            <input class="form-control" name="address" placeholder="<?= t('enter_address_landmark') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">
                                <i class="fas fa-crosshairs me-2"></i><?= t('gps_location') ?>
                            </label>
                            <button type="button" class="btn btn-outline-primary w-100" id="getLocationBtn" onclick="getLocation()">
                                <i class="fas fa-location-arrow me-2"></i><?= t('get_location') ?>
                            </button>
                            <div id="locationStatus" class="small mt-1 text-muted"></div>
                        </div>
                    </div>
                    
                    <!-- Evidence Upload -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="fas fa-camera me-2"></i><?= t('evidence_upload') ?>
                        </label>
                        <div class="border rounded p-4 text-center" style="background: rgba(59, 130, 246, 0.05);">
                            <input class="form-control" type="file" name="evidence" accept="image/*,video/mp4,video/webm" id="evidenceInput">
                            <small class="text-muted"><?= t('supported_formats') ?></small>
                        </div>
                        <div id="evidencePreview" class="mt-2"></div>
                    </div>
                    
                    <!-- Submit Button -->
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-danger flex-grow-1">
                            <i class="fas fa-paper-plane me-2"></i><?= t('submit_report') ?>
                        </button>
                        <button type="button" class="btn btn-outline-secondary" onclick="window.location.href='dashboard.php'">
                            <i class="fas fa-times me-2"></i><?= t('cancel') ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Status Tracking Sidebar -->
        <div class="col-lg-4">
            <div class="card dashboard-card p-4">
                <h4 class="fw-bold mb-3">
                    <i class="fas fa-history me-2 text-primary"></i><?= t('recent_reports') ?>
                </h4>
                <?php if (count($reports) > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($reports as $report): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?= e($report['title']) ?></h6>
                                        <small class="text-muted"><?= date('M d, Y', strtotime($report['created_at'])) ?></small>
                                    </div>
                                    <span class="badge bg-<?= $report['status'] === 'resolved' ? 'success' : ($report['status'] === 'investigating' ? 'warning' : 'info') ?>">
                                        <?= t($report['status']) ?>
                                    </span>
                                </div>
                                <div class="mt-2">
                                    <small class="text-muted"><?= t('severity') ?>: </small>
                                    <span class="badge bg-<?= $report['severity'] >= 4 ? 'danger' : ($report['severity'] >= 3 ? 'warning' : 'info') ?>">
                                        <?= $report['severity'] ?>/5
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="my_reports.php" class="btn btn-outline-primary btn-sm w-100 mt-3">
                        <?= t('view_all_reports') ?>
                    </a>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-3x mb-3" style="opacity: 0.3;"></i>
                        <p><?= t('no_reports_yet') ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Help Card -->
            <div class="card dashboard-card p-4 mt-4" style="background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(30, 64, 175, 0.05) 100%);">
                <h5 class="fw-bold mb-3">
                    <i class="fas fa-info-circle me-2 text-primary"></i><?= t('help') ?>
                </h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Provide accurate details</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Upload clear evidence</li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i>Use GPS for location</li>
                    <li class="mb-0"><i class="fas fa-check text-success me-2"></i>Track status on dashboard</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
const translations = {
    en: {
        location_captured: 'Location Captured',
        update_location: 'Update Location',
        getting_location: 'Getting Location...',
        requesting_location: 'Requesting location...',
        click_get_location: 'Click "Get Location" to capture GPS',
        geolocation_not_supported: 'Geolocation not supported',
        location_permission_denied: 'Location permission denied. Please enable GPS.',
        location_unavailable: 'Location information unavailable.',
        location_timeout: 'Location request timed out.',
        unknown_error: 'Unknown error occurred.',
        get_location: 'Get Location'
    },
    ne: {
        location_captured: 'स्थान क्याप्चर गरियो',
        update_location: 'स्थान अपडेट गर्नुहोस्',
        getting_location: 'स्थान प्राप्त गर्दै...',
        requesting_location: 'स्थान अनुरोध गर्दै...',
        click_get_location: 'जीपीएस क्याप्चर गर्न "स्थान प्राप्त गर्नुहोस्" क्लिक गर्नुहोस्',
        geolocation_not_supported: 'जियोलोकेसन समर्थित छैन',
        location_permission_denied: 'स्थान अनुमति अस्वीकार गरियो। कृपया जीपीएस सक्षम गर्नुहोस्।',
        location_unavailable: 'स्थान जानकारी उपलब्ध छैन।',
        location_timeout: 'स्थान अनुरोध समय समाप्त भयो।',
        unknown_error: 'अज्ञात त्रुटि भयो।',
        get_location: 'स्थान प्राप्त गर्नुहोस्'
    }
};

const currentLang = '<?= get_language() ?>';
const t = (key) => translations[currentLang][key] || translations['en'][key] || key;

function getLocation() {
    const btn = document.getElementById('getLocationBtn');
    const status = document.getElementById('locationStatus');
    
    if (!navigator.geolocation) {
        status.textContent = t('geolocation_not_supported');
        status.className = 'small mt-1 text-danger';
        return;
    }
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>' + t('getting_location');
    status.textContent = t('requesting_location');
    status.className = 'small mt-1 text-info';
    
    navigator.geolocation.getCurrentPosition(
        (position) => {
            document.getElementById('latitude').value = position.coords.latitude;
            document.getElementById('longitude').value = position.coords.longitude;
            btn.innerHTML = '<i class="fas fa-check me-2"></i>' + t('location_captured');
            btn.className = 'btn btn-success w-100';
            status.textContent = 'Lat: ' + position.coords.latitude.toFixed(6) + ', Lng: ' + position.coords.longitude.toFixed(6);
            status.className = 'small mt-1 text-success';
            
            setTimeout(() => {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-location-arrow me-2"></i>' + t('update_location');
                btn.className = 'btn btn-outline-primary w-100';
            }, 2000);
        },
        (error) => {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-location-arrow me-2"></i>' + t('get_location');
            let errorMsg = t('unknown_error');
            
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMsg = t('location_permission_denied');
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMsg = t('location_unavailable');
                    break;
                case error.TIMEOUT:
                    errorMsg = t('location_timeout');
                    break;
                default:
                    errorMsg = t('unknown_error');
            }
            
            status.textContent = errorMsg;
            status.className = 'small mt-1 text-danger';
        },
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    );
}

// Evidence preview
document.getElementById('evidenceInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('evidencePreview');
    
    if (file) {
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.innerHTML = '<img src="' + e.target.result + '" class="img-fluid rounded" style="max-height: 200px;">';
            };
            reader.readAsDataURL(file);
        } else if (file.type.startsWith('video/')) {
            preview.innerHTML = '<video src="' + URL.createObjectURL(file) + '" class="img-fluid rounded" style="max-height: 200px;" controls></video>';
        }
    } else {
        preview.innerHTML = '';
    }
});

// Auto-get location on page load with user permission
document.addEventListener('DOMContentLoaded', function() {
    const status = document.getElementById('locationStatus');
    
    if (navigator.geolocation) {
        status.textContent = t('click_get_location');
        status.className = 'small mt-1 text-muted';
    } else {
        status.textContent = t('geolocation_not_supported');
        status.className = 'small mt-1 text-danger';
    }
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
