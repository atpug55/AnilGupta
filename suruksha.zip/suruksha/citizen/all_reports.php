<?php
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/language.php';
$user = require_role(['citizen']);

// Handle language change
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ne'])) {
    set_language($_GET['lang']);
    header('Location: ' . APP_URL . '/citizen/all_reports.php');
    exit;
}

// Get all incidents with pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

$totalIncidents = db()->prepare('SELECT COUNT(*) as count FROM incidents WHERE user_id = ?');
$totalIncidents->execute([$user['id']]);
$totalIncidentCount = $totalIncidents->fetch()['count'];

$totalMissing = db()->prepare('SELECT COUNT(*) as count FROM missing_persons WHERE user_id = ?');
$totalMissing->execute([$user['id']]);
$totalMissingCount = $totalMissing->fetch()['count'];

$totalCount = $totalIncidentCount + $totalMissingCount;
$totalPages = ceil($totalCount / $perPage);

$incidents = db()->prepare('SELECT * FROM incidents WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?');
$incidents->execute([$user['id'], $perPage, $offset]);
$incidentReports = $incidents->fetchAll();

$missingReports = db()->prepare('SELECT * FROM missing_persons WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?');
$missingReports->execute([$user['id'], $perPage, $offset]);
$missingPersonReports = $missingReports->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
    <div class="row g-4">
        <!-- Language Switcher and Back Button -->
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i><?= t('back') ?>
                </a>
                <div class="d-flex gap-2">
                    <a href="?lang=en" class="btn btn-sm btn-outline-primary <?= get_language() === 'en' ? 'active' : '' ?>">English</a>
                    <a href="?lang=ne" class="btn btn-sm btn-outline-primary <?= get_language() === 'ne' ? 'active' : '' ?>">नेपाली</a>
                </div>
            </div>
        </div>
        
        <!-- Reports Tabs -->
        <div class="col-12">
            <div class="card dashboard-card p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-bold mb-0">
                        <i class="fas fa-file-alt me-2 text-primary"></i><?= t('recent_reports') ?>
                    </h3>
                    <div class="d-flex gap-2">
                        <span class="badge bg-info"><?= $totalIncidentCount ?> Incident Reports</span>
                        <span class="badge bg-warning"><?= $totalMissingCount ?> Missing Person Reports</span>
                    </div>
                </div>
                
                <!-- Tab Navigation -->
                <ul class="nav nav-tabs mb-4" id="reportsTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="incidents-tab" data-bs-toggle="tab" data-bs-target="#incidents" type="button" role="tab">
                            <i class="fas fa-exclamation-triangle me-2"></i>Incident Reports (<?= $totalIncidentCount ?>)
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="missing-tab" data-bs-toggle="tab" data-bs-target="#missing" type="button" role="tab">
                            <i class="fas fa-user-friends me-2"></i>Missing Person Reports (<?= $totalMissingCount ?>)
                        </button>
                    </li>
                </ul>
                
                <!-- Tab Content -->
                <div class="tab-content" id="reportsTabContent">
                    <!-- Incident Reports Tab -->
                    <div class="tab-pane fade show active" id="incidents" role="tabpanel">
                        <?php if (count($incidentReports) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th><?= t('report_title') ?></th>
                                            <th><?= t('category') ?></th>
                                            <th><?= t('severity') ?></th>
                                            <th><?= t('status') ?></th>
                                            <th><?= t('date_time') ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($incidentReports as $report): ?>
                                            <tr>
                                                <td>
                                                    <strong><?= e($report['title']) ?></strong>
                                                    <?php if ($report['evidence_path']): ?>
                                                        <i class="fas fa-paperclip text-muted ms-1"></i>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?= e($report['category']) ?></td>
                                                <td>
                                                    <span class="badge bg-<?= $report['severity'] >= 4 ? 'danger' : ($report['severity'] >= 3 ? 'warning' : 'info') ?>">
                                                        <?= $report['severity'] ?>/5
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?= $report['status'] === 'resolved' ? 'success' : ($report['status'] === 'in_progress' ? 'warning' : 'info') ?>">
                                                        <?= t($report['status']) ?>
                                                    </span>
                                                </td>
                                                <td><?= date('M d, Y H:i', strtotime($report['created_at'])) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center text-muted py-5">
                                <i class="fas fa-inbox fa-4x mb-3" style="opacity: 0.3;"></i>
                                <p class="mb-0">No incident reports yet</p>
                                <a href="report_incident.php" class="btn btn-primary mt-3">
                                    <i class="fas fa-plus me-2"></i><?= t('report_crime') ?>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Missing Person Reports Tab -->
                    <div class="tab-pane fade" id="missing" role="tabpanel">
                        <?php if (count($missingPersonReports) > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th><?= t('full_name') ?></th>
                                            <th><?= t('age') ?></th>
                                            <th><?= t('gender') ?></th>
                                            <th><?= t('last_seen_location') ?></th>
                                            <th><?= t('status') ?></th>
                                            <th><?= t('date_time') ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($missingPersonReports as $report): ?>
                                            <tr>
                                                <td>
                                                    <div class="d-flex align-items-center">
                                                        <?php if ($report['photo_path']): ?>
                                                            <img src="<?= APP_URL ?>/<?= e($report['photo_path']) ?>" alt="Photo" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                                        <?php else: ?>
                                                            <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                                                <i class="fas fa-user text-white small"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                        <strong><?= e($report['full_name']) ?></strong>
                                                    </div>
                                                </td>
                                                <td><?= $report['age'] ?? '-' ?></td>
                                                <td><?= e($report['gender']) ?></td>
                                                <td><?= e(substr($report['last_seen_location'], 0, 30)) ?>...</td>
                                                <td>
                                                    <span class="badge bg-<?= $report['status'] === 'found' ? 'success' : ($report['status'] === 'investigating' ? 'warning' : 'info') ?>">
                                                        <?= t($report['status'] ?? 'pending') ?>
                                                    </span>
                                                </td>
                                                <td><?= date('M d, Y H:i', strtotime($report['created_at'])) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center text-muted py-5">
                                <i class="fas fa-user-friends fa-4x mb-3" style="opacity: 0.3;"></i>
                                <p class="mb-0">No missing person reports yet</p>
                                <a href="missing_person.php" class="btn btn-warning mt-3" style="color: white;">
                                    <i class="fas fa-plus me-2"></i><?= t('missing_person_report') ?>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
