<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['citizen']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    
    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/profiles/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Delete old profile picture if exists
        if (!empty($user['profile_photo']) && file_exists(__DIR__ . '/../' . $user['profile_photo'])) {
            unlink(__DIR__ . '/../' . $user['profile_photo']);
        }
        
        $file = $_FILES['profile_picture'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'profile_' . $user['id'] . '_' . time() . '.' . $ext;
        $filepath = $uploadDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $relativePath = 'uploads/profiles/' . $filename;
            db()->prepare('UPDATE users SET profile_photo = ? WHERE id = ?')
                ->execute([$relativePath, $user['id']]);
            flash('success', 'Profile picture updated successfully.');
        } else {
            flash('danger', 'Failed to upload profile picture.');
        }
    }
    
    // Handle profile update
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    
    if ($name) {
        db()->prepare('UPDATE users SET name = ?, phone = ? WHERE id = ?')
            ->execute([$name, $phone, $user['id']]);
        flash('success', 'Profile updated successfully.');
    }
    
    redirect('citizen/settings.php');
}

require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-5">
    <div class="row">
        <div class="col-lg-4">
            <div class="card dashboard-card p-4">
                <h4 class="fw-bold mb-4">Profile Picture</h4>
                <div class="text-center mb-4">
                    <?php if (!empty($user['profile_photo'])): ?>
                        <img src="<?= APP_URL ?>/<?= e($user['profile_photo']) ?>" alt="Profile" class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                    <?php else: ?>
                        <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-3" style="width: 150px; height: 150px;">
                            <i class="fas fa-user fa-4x text-white-50"></i>
                        </div>
                    <?php endif; ?>
                </div>
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <div class="mb-3">
                        <label class="form-label">Upload New Picture</label>
                        <input type="file" class="form-control" name="profile_picture" accept="image/*" id="profilePictureInput">
                    </div>
                    <div class="mb-3" id="cropContainer" style="display: none;">
                        <img id="cropImage" style="max-width: 100%;">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Update Profile Picture</button>
                </form>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="card dashboard-card p-4">
                <h4 class="fw-bold mb-4">Profile Settings</h4>
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-control" name="name" value="<?= e($user['name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" value="<?= e($user['email']) ?>" disabled>
                        <small class="text-muted">Email cannot be changed</small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" name="phone" value="<?= e($user['phone'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" class="form-control" value="<?= e($user['username']) ?>" disabled>
                        <small class="text-muted">Username cannot be changed</small>
                    </div>
                    <button type="submit" class="btn btn-primary">Update Profile</button>
                </form>
            </div>
            
            <div class="card dashboard-card p-4 mt-4">
                <h4 class="fw-bold mb-4">Security</h4>
                <a href="security.php" class="btn btn-outline-primary w-100 mb-2">
                    <i class="fas fa-shield-alt me-2"></i>Change SOS PIN
                </a>
                <a href="forgot_password.php" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-key me-2"></i>Change Password
                </a>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>
<script>
let cropper;

document.getElementById('profilePictureInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            const img = document.getElementById('cropImage');
            img.src = event.target.result;
            document.getElementById('cropContainer').style.display = 'block';
            
            if (cropper) {
                cropper.destroy();
            }
            
            cropper = new Cropper(img, {
                aspectRatio: 1,
                viewMode: 1,
                autoCropArea: 0.8,
                responsive: true,
                checkCrossOrigin: false
            });
        };
        reader.readAsDataURL(file);
    }
});

document.querySelector('form').addEventListener('submit', function(e) {
    if (cropper) {
        const canvas = cropper.getCroppedCanvas({
            width: 300,
            height: 300
        });
        
        canvas.toBlob(function(blob) {
            const file = new File([blob], 'cropped_profile.jpg', { type: 'image/jpeg' });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            document.getElementById('profilePictureInput').files = dataTransfer.files;
        });
    }
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
