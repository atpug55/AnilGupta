<?php
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/language.php';
$user = require_role(['citizen']);

// Handle language change
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ne'])) {
    set_language($_GET['lang']);
    header('Location: ' . APP_URL . '/citizen/my_missing_reports.php');
    exit;
}

// Get all missing person reports with pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

$totalReports = db()->prepare('SELECT COUNT(*) as count FROM missing_persons WHERE user_id = ?');
$totalReports->execute([$user['id']]);
$totalCount = $totalReports->fetch()['count'];
$totalPages = ceil($totalCount / $perPage);

$reports = db()->prepare('SELECT * FROM missing_persons WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?');
$reports->execute([$user['id'], $perPage, $offset]);
$missingReports = $reports->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
    <div class="row g-4">
        <!-- Language Switcher and Back Button -->
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i><?= t('back') ?>
                </a>
                <div class="d-flex gap-2">
                    <a href="?lang=en" class="btn btn-sm btn-outline-primary <?= get_language() === 'en' ? 'active' : '' ?>">English</a>
                    <a href="?lang=ne" class="btn btn-sm btn-outline-primary <?= get_language() === 'ne' ? 'active' : '' ?>">नेपाली</a>
                </div>
            </div>
        </div>
        
        <!-- Reports List -->
        <div class="col-12">
            <div class="card dashboard-card p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-bold mb-0">
                        <i class="fas fa-user-friends me-2 text-warning"></i><?= t('missing_person_report') ?>
                    </h3>
                    <span class="badge bg-warning"><?= $totalCount ?> Reports</span>
                </div>
                
                <?php if (count($missingReports) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?= t('full_name') ?></th>
                                    <th><?= t('age') ?></th>
                                    <th><?= t('gender') ?></th>
                                    <th><?= t('last_seen_location') ?></th>
                                    <th><?= t('status') ?></th>
                                    <th><?= t('date_time') ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($missingReports as $report): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <?php if ($report['photo_path']): ?>
                                                    <img src="<?= APP_URL ?>/<?= e($report['photo_path']) ?>" alt="Photo" class="rounded-circle me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                                <?php else: ?>
                                                    <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                                        <i class="fas fa-user text-white small"></i>
                                                    </div>
                                                <?php endif; ?>
                                                <strong><?= e($report['full_name']) ?></strong>
                                            </div>
                                        </td>
                                        <td><?= $report['age'] ?? '-' ?></td>
                                        <td><?= e($report['gender']) ?></td>
                                        <td><?= e(substr($report['last_seen_location'], 0, 30)) ?>...</td>
                                        <td>
                                            <span class="badge bg-<?= $report['status'] === 'found' ? 'success' : ($report['status'] === 'investigating' ? 'warning' : 'info') ?>">
                                                <?= t($report['status'] ?? 'pending') ?>
                                            </span>
                                        </td>
                                        <td><?= date('M d, Y H:i', strtotime($report['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-user-friends fa-4x mb-3" style="opacity: 0.3;"></i>
                        <p class="mb-0"><?= t('no_reports_yet') ?></p>
                        <a href="missing_person.php" class="btn btn-warning mt-3" style="color: white;">
                            <i class="fas fa-plus me-2"></i><?= t('missing_person_report') ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
