<?php
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/language.php';
$user = require_role(['citizen']);

// Handle language change
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ne'])) {
    set_language($_GET['lang']);
    header('Location: ' . APP_URL . '/citizen/my_reports.php');
    exit;
}

// Get all incidents with pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;

$totalIncidents = db()->prepare('SELECT COUNT(*) as count FROM incidents WHERE user_id = ?');
$totalIncidents->execute([$user['id']]);
$totalCount = $totalIncidents->fetch()['count'];
$totalPages = ceil($totalCount / $perPage);

$incidents = db()->prepare('SELECT * FROM incidents WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?');
$incidents->execute([$user['id'], $perPage, $offset]);
$reports = $incidents->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
    <div class="row g-4">
        <!-- Language Switcher and Back Button -->
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i><?= t('back') ?>
                </a>
                <div class="d-flex gap-2">
                    <a href="?lang=en" class="btn btn-sm btn-outline-primary <?= get_language() === 'en' ? 'active' : '' ?>">English</a>
                    <a href="?lang=ne" class="btn btn-sm btn-outline-primary <?= get_language() === 'ne' ? 'active' : '' ?>">नेपाली</a>
                </div>
            </div>
        </div>
        
        <!-- Reports List -->
        <div class="col-12">
            <div class="card dashboard-card p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-bold mb-0">
                        <i class="fas fa-file-alt me-2 text-primary"></i><?= t('recent_reports') ?>
                    </h3>
                    <span class="badge bg-info"><?= $totalCount ?> <?= t('total_reports') ?></span>
                </div>
                
                <?php if (count($reports) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th><?= t('report_title') ?></th>
                                    <th><?= t('category') ?></th>
                                    <th><?= t('severity') ?></th>
                                    <th><?= t('status') ?></th>
                                    <th><?= t('date_time') ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reports as $report): ?>
                                    <tr>
                                        <td>
                                            <strong><?= e($report['title']) ?></strong>
                                            <?php if ($report['evidence_path']): ?>
                                                <i class="fas fa-paperclip text-muted ms-1"></i>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= e($report['category']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $report['severity'] >= 4 ? 'danger' : ($report['severity'] >= 3 ? 'warning' : 'info') ?>">
                                                <?= $report['severity'] ?>/5
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?= $report['status'] === 'resolved' ? 'success' : ($report['status'] === 'in_progress' ? 'warning' : 'info') ?>">
                                                <?= t($report['status']) ?>
                                            </span>
                                        </td>
                                        <td><?= date('M d, Y H:i', strtotime($report['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php if ($page > 1): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $page - 1 ?>">Previous</a>
                                    </li>
                                <?php endif; ?>
                                
                                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                        <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                                    </li>
                                <?php endfor; ?>
                                
                                <?php if ($page < $totalPages): ?>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=<?= $page + 1 ?>">Next</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-5">
                        <i class="fas fa-inbox fa-4x mb-3" style="opacity: 0.3;"></i>
                        <p class="mb-0"><?= t('no_reports_yet') ?></p>
                        <a href="report_incident.php" class="btn btn-primary mt-3">
                            <i class="fas fa-plus me-2"></i><?= t('report_crime') ?>
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
