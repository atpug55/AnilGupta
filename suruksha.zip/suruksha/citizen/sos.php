<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['citizen']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $lat = $_POST['latitude'] !== '' ? $_POST['latitude'] : null;
    $lng = $_POST['longitude'] !== '' ? $_POST['longitude'] : null;
    db()->prepare('INSERT INTO sos_alerts (user_id, latitude, longitude) VALUES (?, ?, ?)')->execute([$user['id'], $lat, $lng]);
    db()->prepare('INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)')->execute([$user['id'], 'Emergency SOS Alert', $user['name'] . ' triggered SOS.', 'danger']);
    flash('danger', 'SOS sent to police control room. Stay safe and keep your phone reachable.');
}
redirect('citizen/dashboard.php');
