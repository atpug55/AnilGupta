<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['citizen']);

// Get statistics
$incidentCount = db()->prepare('SELECT COUNT(*) as count FROM incidents WHERE user_id = ?');
$incidentCount->execute([$user['id']]);
$totalIncidents = $incidentCount->fetch()['count'];

$sosCount = db()->prepare('SELECT COUNT(*) as count FROM sos_alerts WHERE user_id = ?');
$sosCount->execute([$user['id']]);
$totalSos = $sosCount->fetch()['count'];

$missingCount = db()->prepare('SELECT COUNT(*) as count FROM missing_persons WHERE user_id = ?');
$missingCount->execute([$user['id']]);
$totalMissing = $missingCount->fetch()['count'];

$totalReports = $totalIncidents + $totalSos + $totalMissing;

$incidentsStmt = db()->prepare('SELECT * FROM incidents WHERE user_id = ? ORDER BY created_at DESC LIMIT 5');
$incidentsStmt->execute([$user['id']]);
$incidents = $incidentsStmt->fetchAll();

$sosStmt = db()->prepare('SELECT * FROM sos_alerts WHERE user_id = ? ORDER BY created_at DESC LIMIT 3');
$sosStmt->execute([$user['id']]);
$sos = $sosStmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4" data-citizen-name="<?= e($user['name']) ?>" data-citizen-phone="<?= e($user['phone'] ?? '') ?>">
    <!-- Welcome Section -->
    <div class="row g-4 mb-4">
        <div class="col-12">
            <div class="card dashboard-card p-4" style="background: linear-gradient(135deg, rgba(59, 130, 246, 0.15) 0%, rgba(30, 64, 175, 0.1) 100%); border: 1px solid rgba(59, 130, 246, 0.3);">
                <div class="d-flex align-items-center">
                    <div class="profile-avatar me-4 flex-shrink-0">
                        <?php if (!empty($user['profile_photo'])): ?>
                            <img src="<?= APP_URL ?>/<?= e($user['profile_photo']) ?>" alt="Profile" class="rounded-circle" style="width: 90px; height: 90px; object-fit: cover; border: 3px solid #3b82f6; box-shadow: 0 0 25px rgba(59, 130, 246, 0.6);">
                        <?php else: ?>
                            <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center" style="width: 90px; height: 90px; border: 3px solid #3b82f6; box-shadow: 0 0 25px rgba(59, 130, 246, 0.6);">
                                <i class="fas fa-user fa-3x text-white"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="flex-grow-1 ms-2">
                        <div class="d-flex align-items-center mb-2">
                            <img src="https://flagcdn.com/w40/np.png" alt="Nepal" class="me-2" style="width: 32px; height: auto;">
                            <h2 class="mb-0" style="color: #000000; font-weight: 700;">Welcome back, <span style="color: #1d67c2;"><?= e($user['name']) ?></span>!</h2>
                        </div>
                        <p class="mb-0" style="color: rgb(0, 0, 0); font-size: 1.1rem;">Citizen Dashboard - SurakshaNet AI</p>
                    </div>
                    <div class="text-end flex-shrink-0">
                        <a href="settings.php" class="btn btn-primary" style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); border: none; padding: 10px 24px; font-weight: 600;">
                            <i class="fas fa-cog me-2"></i>Settings
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card dashboard-card p-4" style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); color: white; border: none;">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-file-alt fa-3x mb-2" style="opacity: 0.8;"></i>
                    </div>
                    <div class="ms-3">
                        <h3 class="mb-0 fw-bold"><?= $totalReports ?></h3>
                        <p class="mb-0" style="opacity: 0.9;">Total Reports</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card dashboard-card p-4" style="background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%); color: white; border: none;">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-exclamation-triangle fa-3x mb-2" style="opacity: 0.8;"></i>
                    </div>
                    <div class="ms-3">
                        <h3 class="mb-0 fw-bold"><?= $totalSos ?></h3>
                        <p class="mb-0" style="opacity: 0.9;">SOS Alerts Sent</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card dashboard-card p-4" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; border: none;">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-shield-alt fa-3x mb-2" style="opacity: 0.8;"></i>
                    </div>
                    <div class="ms-3">
                        <h3 class="mb-0 fw-bold">Active</h3>
                        <p class="mb-0" style="opacity: 0.9;">Account Status</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<br>
    <!-- Main Content -->
    <div class="row g-4">
        <!-- Left Column -->
        <div class="col-lg-4">
            <!-- SOS Card -->
            <div class="card dashboard-card p-4 text-center mb-4">
                <h4 class="fw-bold mb-3"><i class="fas fa-bell me-2 text-danger"></i>Secure Emergency SOS</h4>
                <select id="sosCategory" class="form-select mb-3">
                    <option>Emergency Response</option>
                    <option>Crime Investigation</option>
                    <option>Traffic Police</option>
                    <option>Women Cell</option>
                    <option>Cyber Bureau</option>
                    <option>Missing Persons</option>
                    <option>Disaster Management</option>
                </select>
                <button id="secureSosBtn" class="btn btn-emergency w-100" data-csrf="<?= csrf_token() ?>">
                    <i class="fas fa-exclamation-circle me-2"></i>SEND SECURE SOS
                </button>
                <div id="sosMessage" class="small mt-3"></div>
                <a href="security.php" class="small d-block mt-2 text-decoration-none">
                    <i class="fas fa-key me-1"></i>Set or change SOS PIN
                </a>
            </div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
            <!-- Quick Actions -->
            <div class="card dashboard-card p-4">
                <h5 class="fw-bold mb-3"><i class="fas fa-bolt me-2 text-warning"></i>Quick Actions</h5>
                <a class="btn btn-primary w-100 mb-2" href="report_incident.php">
                    <i class="fas fa-file-medical me-2"></i>Report Crime
                </a>
                <a class="btn btn-outline-primary w-100 mb-2" href="missing_person.php">
                    <i class="fas fa-user-friends me-2"></i>Missing Person Report
                </a>
                
            </div>
        </div>

        <!-- Right Column -->
        <div class="col-lg-8">
            <!-- Live Safety Map -->
            <div class="card dashboard-card p-4 mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="fw-bold mb-0"><i class="fas fa-map-marked-alt me-2 text-primary"></i>Live Safety Map</h4>
                    <span class="badge bg-success">Live</span>
                </div>
                <div id="citizenMap" class="map-box" style="height: 300px;"></div>
                <div id="trackingStatus" class="small mt-2 text-muted">
                    <i class="fas fa-spinner fa-spin me-1"></i>Requesting location...
                </div>
            </div>

            <!-- Recent Reports -->
            <div class="card dashboard-card p-4">
                <h4 class="fw-bold mb-3"><i class="fas fa-history me-2 text-primary"></i>Recent Reports</h4>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Severity</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($incidents) > 0): ?>
                                <?php foreach ($incidents as $row): ?>
                                    <tr>
                                        <td><?= e($row['title']) ?></td>
                                        <td>
                                            <span class="badge bg-<?= $row['severity'] >= 4 ? 'danger' : ($row['severity'] >= 3 ? 'warning' : 'info') ?>">
                                                <?= e($row['severity']) ?>/5
                                            </span>
                                        </td>
                                        <td><span class="badge bg-info"><?= e($row['status']) ?></span></td>
                                        <td><?= date('M d, Y', strtotime($row['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted">No reports yet</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if (count($incidents) > 0): ?>
                    <a href="all_reports.php" class="btn btn-outline-primary btn-sm mt-2">View All Reports</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bottom Row -->
    <div class="row g-4 mt-2">
        <!-- Recent SOS Alerts -->
        <div class="col-lg-6">
            <div class="card dashboard-card p-4">
                <h4 class="fw-bold mb-3"><i class="fas fa-exclamation-circle me-2 text-danger"></i>Recent SOS Alerts</h4>
                <?php if (count($sos) > 0): ?>
                    <?php foreach ($sos as $alert): ?>
                        <div class="alert alert-danger alert-dismissible fade show mb-2" role="alert">
                            <strong><?= e($alert['emergency_category']) ?></strong>
                            <small class="d-block text-muted"><?= date('M d, Y H:i', strtotime($alert['created_at'])) ?></small>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-muted mb-0">No SOS alerts sent yet</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Notifications -->
        <div class="col-lg-6">
            <div class="card dashboard-card p-4">
                <h4 class="fw-bold mb-3"><i class="fas fa-bell me-2 text-primary"></i>Notifications</h4>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered" style="border-collapse: separate; border-spacing: 0;">
                        <thead>
                            <tr class="table-light">
                                <th style="border: 1px solid #dee2e6;">Title</th>
                                <th style="border: 1px solid #dee2e6;">Message</th>
                                <th style="border: 1px solid #dee2e6;">Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $notes = db()->prepare('SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY created_at DESC LIMIT 3');
                            $notes->execute([$user['id']]);
                            $notifications = $notes->fetchAll();
                            if (count($notifications) > 0): 
                                foreach ($notifications as $n): 
                                    $message = strtolower($n['message']);
                                    $bgClass = 'bg-white';
                                    if (strpos($message, 'found') !== false || strpos($message, 'resolved') !== false || strpos($message, 'completed') !== false || strpos($message, 'approved') !== false) {
                                        $bgClass = 'bg-success bg-opacity-10';
                                    } elseif (strpos($message, 'false alarm') !== false || strpos($message, 'cancelled') !== false) {
                                        $bgClass = 'bg-warning bg-opacity-10';
                                    } elseif (strpos($message, 'active') !== false || strpos($message, 'monitoring') !== false || strpos($message, 'pending') !== false) {
                                        $bgClass = 'bg-info bg-opacity-10';
                                    } elseif (strpos($message, 'emergency') !== false || strpos($message, 'alert') !== false || strpos($message, 'sos') !== false) {
                                        $bgClass = 'bg-danger bg-opacity-10';
                                    } elseif ($n['type'] == 'danger') {
                                        $bgClass = 'bg-danger bg-opacity-10';
                                    } elseif ($n['type'] == 'success') {
                                        $bgClass = 'bg-success bg-opacity-10';
                                    } elseif ($n['type'] == 'warning') {
                                        $bgClass = 'bg-warning bg-opacity-10';
                                    } elseif ($n['type'] == 'info') {
                                        $bgClass = 'bg-info bg-opacity-10';
                                    } elseif ($n['type'] == 'primary') {
                                        $bgClass = 'bg-primary bg-opacity-10';
                                    }
                            ?>
                                <tr style="border: 1px solid #dee2e6;">
                                    <td class="fw-bold" style="border: 1px solid #dee2e6;"><?= e($n['title']) ?></td>
                                    <td class="<?= $bgClass ?>" style="border: 1px solid #dee2e6;"><?= e($n['message']) ?></td>
                                    <td style="border: 1px solid #dee2e6;"><?= date('M d, Y', strtotime($n['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="text-center text-muted">No notifications</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php 
                $totalNotes = db()->prepare('SELECT COUNT(*) as count FROM notifications WHERE user_id = ? OR user_id IS NULL');
                $totalNotes->execute([$user['id']]);
                $total = $totalNotes->fetch()['count'];
                if ($total > 3): 
                ?>
                    <a href="all_notifications.php" class="btn btn-outline-primary btn-sm mt-2">View All Notifications</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    initMap('citizenMap', '../api/map_markers.php', { followUser: true });
    setupSecureSos();
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
