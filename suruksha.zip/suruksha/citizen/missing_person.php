<?php
require_once __DIR__ . '/../includes/upload.php';
require_once __DIR__ . '/../includes/language.php';
$user = require_role(['citizen']);

// Handle language change
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'ne'])) {
    set_language($_GET['lang']);
    header('Location: ' . APP_URL . '/citizen/missing_person.php');
    exit;
}

// Get user's recent missing person reports
$recentReports = db()->prepare('SELECT * FROM missing_persons WHERE user_id = ? ORDER BY created_at DESC LIMIT 5');
$recentReports->execute([$user['id']]);
$reports = $recentReports->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    try {
        $photoPath = null;
        
        // Handle photo upload
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            [$photoPath] = save_upload('photo', ['image/jpeg','image/png','image/webp']);
        }
        
        $stmt = db()->prepare('INSERT INTO missing_persons (user_id, full_name, age, gender, last_seen_location, last_seen_at, description, photo_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$user['id'], trim($_POST['full_name']), $_POST['age'] ?: null, trim($_POST['gender']), trim($_POST['last_seen_location']), $_POST['last_seen_at'] ?: null, trim($_POST['description']), $photoPath]);
        flash('success', 'Missing person report submitted successfully. Track status on your dashboard.');
        redirect('citizen/dashboard.php');
    } catch (Throwable $e) { 
        flash('danger', $e->getMessage()); 
    }
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
    <div class="row g-4">
        <!-- Language Switcher and Back Button -->
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <a href="dashboard.php" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i><?= t('back') ?>
                </a>
                <div class="d-flex gap-2">
                    <a href="?lang=en" class="btn btn-sm btn-outline-primary <?= get_language() === 'en' ? 'active' : '' ?>">English</a>
                    <a href="?lang=ne" class="btn btn-sm btn-outline-primary <?= get_language() === 'ne' ? 'active' : '' ?>">नेपाली</a>
                </div>
            </div>
        </div>
        
        <!-- Report Form -->
        <div class="col-lg-8">
            <div class="card dashboard-card p-4">
                <div class="d-flex align-items-center mb-4">
                    <i class="fas fa-user-friends fa-2x text-warning me-3"></i>
                    <div>
                        <h3 class="mb-0"><?= t('missing_person_report') ?></h3>
                        <p class="text-muted mb-0"><?= t('report_missing_person') ?></p>
                    </div>
                </div>
                
                <form method="post" enctype="multipart/form-data" id="missingPersonForm">
                    <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                    
                    <!-- Personal Information -->
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">
                                <i class="fas fa-user me-2"></i><?= t('full_name') ?> <span class="text-danger">*</span>
                            </label>
                            <input class="form-control" name="full_name" placeholder="<?= t('enter_full_name') ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold">
                                <i class="fas fa-birthday-cake me-2"></i><?= t('age') ?>
                            </label>
                            <input class="form-control" type="number" name="age" placeholder="<?= t('age') ?>" min="0" max="150">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-bold">
                                <i class="fas fa-venus-mars me-2"></i><?= t('gender') ?>
                            </label>
                            <select class="form-select" name="gender">
                                <option value="">Select</option>
                                <option value="Male"><?= t('male') ?></option>
                                <option value="Female"><?= t('female') ?></option>
                                <option value="Other"><?= t('other_gender') ?></option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Last Seen Information -->
                    <div class="row g-3 mb-4">
                        <div class="col-md-8">
                            <label class="form-label fw-bold">
                                <i class="fas fa-map-marker-alt me-2"></i><?= t('last_seen_location') ?> <span class="text-danger">*</span>
                            </label>
                            <input class="form-control" name="last_seen_location" placeholder="<?= t('enter_location') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">
                                <i class="fas fa-clock me-2"></i><?= t('date_time') ?>
                            </label>
                            <input class="form-control" type="datetime-local" name="last_seen_at">
                        </div>
                    </div>
                    
                    <!-- Description -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="fas fa-align-left me-2"></i><?= t('description') ?> <span class="text-danger">*</span>
                        </label>
                        <textarea class="form-control" name="description" rows="5" placeholder="<?= t('describe_appearance') ?>" required></textarea>
                    </div>
                    
                    <!-- Photo Upload -->
                    <div class="mb-4">
                        <label class="form-label fw-bold">
                            <i class="fas fa-camera me-2"></i><?= t('photo_upload') ?>
                        </label>
                        <div class="border rounded p-4 text-center" style="background: rgba(245, 158, 11, 0.05);">
                            <input class="form-control" type="file" name="photo" accept="image/*" id="photoInput">
                            <small class="text-muted"><?= t('supported_images') ?></small>
                        </div>
                        <div id="photoPreview" class="mt-2"></div>
                    </div>
                    
                    <!-- Submit Button -->
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-warning flex-grow-1" style="color: white;">
                            <i class="fas fa-paper-plane me-2"></i><?= t('submit_report') ?>
                        </button>
                        <button type="button" class="btn btn-outline-secondary" onclick="window.location.href='dashboard.php'">
                            <i class="fas fa-times me-2"></i><?= t('cancel') ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Status Tracking Sidebar -->
        <div class="col-lg-4">
            <div class="card dashboard-card p-4">
                <h4 class="fw-bold mb-3">
                    <i class="fas fa-history me-2 text-warning"></i><?= t('recent_reports') ?>
                </h4>
                <?php if (count($reports) > 0): ?>
                    <div class="list-group list-group-flush">
                        <?php foreach ($reports as $report): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?= e($report['full_name']) ?></h6>
                                        <small class="text-muted"><?= date('M d, Y', strtotime($report['created_at'])) ?></small>
                                    </div>
                                    <span class="badge bg-<?= $report['status'] === 'found' ? 'success' : ($report['status'] === 'investigating' ? 'warning' : 'info') ?>">
                                        <?= t($report['status'] ?? 'pending') ?>
                                    </span>
                                </div>
                                <div class="mt-2">
                                    <small class="text-muted">Last seen: </small>
                                    <span class="text-muted"><?= e(substr($report['last_seen_location'], 0, 30)) ?>...</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <a href="my_missing_reports.php" class="btn btn-outline-warning btn-sm w-100 mt-3">
                        <?= t('view_all_reports') ?>
                    </a>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-user-friends fa-3x mb-3" style="opacity: 0.3;"></i>
                        <p><?= t('no_reports_yet') ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Help Card -->
            <div class="card dashboard-card p-4 mt-4" style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(217, 119, 6, 0.05) 100%);">
                <h5 class="fw-bold mb-3">
                    <i class="fas fa-info-circle me-2 text-warning"></i><?= t('help') ?>
                </h5>
                <ul class="list-unstyled mb-0">
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i><?= t('provide_clear_photo') ?></li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i><?= t('include_age_gender') ?></li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i><?= t('describe_clothing') ?></li>
                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i><?= t('specify_last_seen') ?></li>
                    <li class="mb-0"><i class="fas fa-check text-success me-2"></i><?= t('track_status_dashboard') ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
// Photo preview
document.getElementById('photoInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    const preview = document.getElementById('photoPreview');
    
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.innerHTML = '<img src="' + e.target.result + '" class="img-fluid rounded" style="max-height: 300px; max-width: 100%;">';
        };
        reader.readAsDataURL(file);
    } else {
        preview.innerHTML = '';
    }
});
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
