<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['citizen']);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="fas fa-bell me-2 text-primary"></i>All Notifications</h2>
        <a href="dashboard.php" class="btn btn-outline-primary">
            <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
        </a>
    </div>

    <div class="card dashboard-card p-4">
        <div class="table-responsive">
            <table class="table table-hover table-bordered" style="border-collapse: separate; border-spacing: 0;">
                <thead>
                    <tr class="table-light">
                        <th style="border: 1px solid #dee2e6;">Title</th>
                        <th style="border: 1px solid #dee2e6;">Message</th>
                        <th style="border: 1px solid #dee2e6;">Type</th>
                        <th style="border: 1px solid #dee2e6;">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $notes = db()->prepare('SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY created_at DESC');
                    $notes->execute([$user['id']]);
                    $notifications = $notes->fetchAll();
                    if (count($notifications) > 0): 
                        foreach ($notifications as $n): 
                            $bgClass = 'bg-white';
                            if ($n['type'] == 'danger') $bgClass = 'bg-danger bg-opacity-10';
                            elseif ($n['type'] == 'success') $bgClass = 'bg-success bg-opacity-10';
                            elseif ($n['type'] == 'warning') $bgClass = 'bg-warning bg-opacity-10';
                            elseif ($n['type'] == 'info') $bgClass = 'bg-info bg-opacity-10';
                            elseif ($n['type'] == 'primary') $bgClass = 'bg-primary bg-opacity-10';
                            
                            $badgeClass = 'bg-secondary';
                            if ($n['type'] == 'danger') $badgeClass = 'bg-danger';
                            elseif ($n['type'] == 'success') $badgeClass = 'bg-success';
                            elseif ($n['type'] == 'warning') $badgeClass = 'bg-warning';
                            elseif ($n['type'] == 'info') $badgeClass = 'bg-info';
                            elseif ($n['type'] == 'primary') $badgeClass = 'bg-primary';
                    ?>
                        <tr class="<?= $bgClass ?>" style="border: 1px solid #dee2e6;">
                            <td class="fw-bold" style="border: 1px solid #dee2e6;"><?= e($n['title']) ?></td>
                            <td style="border: 1px solid #dee2e6;"><?= e($n['message']) ?></td>
                            <td style="border: 1px solid #dee2e6;"><span class="badge <?= $badgeClass ?>"><?= e($n['type']) ?></span></td>
                            <td style="border: 1px solid #dee2e6;"><?= date('M d, Y H:i', strtotime($n['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center text-muted">No notifications</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
