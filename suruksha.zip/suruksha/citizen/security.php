<?php
require_once __DIR__ . '/../includes/helpers.php';
$user = require_role(['citizen']);
ensure_sos_pin_column();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $accountPassword = $_POST['account_password'] ?? '';
    $sosPin = trim($_POST['sos_pin'] ?? '');
    
    // Google users don't have password, skip password verification
    if (!empty($user['password_hash']) && !password_verify($accountPassword, $user['password_hash'])) {
        flash('danger', 'Account password is wrong. SOS PIN was not changed.');
    } elseif (!preg_match('/^[0-9]{4,8}$/', $sosPin)) {
        flash('danger', 'SOS PIN must be 4 to 8 numbers.');
    } else {
        db()->prepare('UPDATE users SET sos_pin_hash=? WHERE id=?')->execute([password_hash($sosPin, PASSWORD_DEFAULT), $user['id']]);
        flash('success', 'SOS PIN saved successfully. You can now use this PIN for emergency SOS.');
        redirect('citizen/dashboard.php');
    }
}
require_once __DIR__ . '/../includes/header.php';
?>
<div class="container py-5"><div class="row justify-content-center"><div class="col-md-6"><div class="card dashboard-card p-4"><h3 class="fw-bold">SOS Security PIN</h3><p class="text-muted">Create a fast numeric PIN for emergency SOS. SOS will only send after the correct account password or SOS PIN is verified.</p><form method="post"><input type="hidden" name="csrf_token" value="<?= csrf_token() ?>"><?php if (!empty($user['password_hash'])): ?><label class="form-label">Current account password</label><input class="form-control mb-3" type="password" name="account_password" required><?php endif; ?><label class="form-label">New SOS PIN</label><input class="form-control mb-3" type="password" name="sos_pin" pattern="[0-9]{4,8}" maxlength="8" inputmode="numeric" placeholder="4-8 digit PIN" required><button class="btn btn-primary w-100">Save SOS PIN</button></form><a class="btn btn-outline-secondary w-100 mt-3" href="dashboard.php">Back to Dashboard</a></div></div></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
