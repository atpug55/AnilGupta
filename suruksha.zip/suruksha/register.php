<?php
require_once __DIR__ . '/includes/mailer.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    if (strlen($password) < 8) {
        flash('danger', 'Password must be at least 8 characters.');
    } elseif ($password !== $confirmPassword) {
        flash('danger', 'Passwords do not match.');
    } else {
        $stmt = db()->prepare('INSERT INTO users (name, username, email, phone, password_hash, auth_provider, account_status, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 1)');
        try {
            $stmt->execute([$name, generate_username($name), $email, $phone, password_hash($password, PASSWORD_DEFAULT), 'local', 'active']);
            
            // Auto-login the user
            $userId = db()->lastInsertId();
            session_regenerate_id(true);
            $_SESSION['user_id'] = $userId;
            
            flash('success', 'Account created successfully! You are now logged in.');
            redirect('citizen/dashboard.php');
        } catch (PDOException $e) {
            flash('danger', 'Email already exists. Please login or reset password.');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - SurakshaNet AI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            position: relative;
        }
        
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="0.5"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
            pointer-events: none;
            z-index: 0;
        }
        
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            z-index: 1;
        }
        
        .auth-card {
            background: linear-gradient(145deg, rgba(255, 255, 255, 0.95) 0%, rgba(240, 245, 255, 0.95) 100%);
            border-radius: 16px;
            padding: 0;
            max-width: 1100px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.1);
            animation: fadeInUp 0.7s ease-out;
            overflow: hidden;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(40px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .auth-illustration {
            background: linear-gradient(135deg, #003366 0%, #004080 50%, #0052a3 100%);
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            min-height: 960px;
            position: relative;
            overflow: hidden;
        }
        
        .auth-illustration::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
        }
        
        .auth-illustration::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -30%;
            width: 80%;
            height: 80%;
            background: radial-gradient(circle, rgba(255,255,255,0.05) 0%, transparent 70%);
        }
        
        .police-badge {
            width: 140px;
            height: 140px;
            background: linear-gradient(135deg, #ffd700 0%, #ffed4a 50%, #ffd700 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.5);
            position: relative;
            z-index: 2;
            animation: badgeGlow 3s ease-in-out infinite;
        }
        
        @keyframes badgeGlow {
            0%, 100% { box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.5), 0 0 20px rgba(255, 215, 0, 0.3); }
            50% { box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3), inset 0 2px 10px rgba(255, 255, 255, 0.5), 0 0 40px rgba(255, 215, 0, 0.5); }
        }
        
        .police-badge i {
            font-size: 60px;
            color: #003366;
        }
        
        .auth-illustration h2 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 15px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            position: relative;
            z-index: 2;
        }
        
        .auth-illustration p {
            font-size: 16px;
            opacity: 0.9;
            margin-bottom: 30px;
            position: relative;
            z-index: 2;
        }
        
        .police-features {
            display: flex;
            flex-direction: column;
            gap: 15px;
            position: relative;
            z-index: 2;
        }
        
        .police-feature {
            display: flex;
            align-items: center;
            gap: 12px;
            background: rgba(255, 255, 255, 0.1);
            padding: 12px 20px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .police-feature i {
            color: #ffd700;
            font-size: 18px;
        }
        
        .police-feature span {
            font-size: 14px;
            font-weight: 500;
        }
        
        .auth-form {
            padding: 50px 45px;
            background: white;
        }
        
        .auth-header {
            text-align: center;
            margin-bottom: 35px;
        }
        
        .auth-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            font-size: 26px;
            font-weight: 700;
            color: #003366;
            margin-bottom: 10px;
        }
        
        .auth-logo i {
            color: #dc2626;
            font-size: 32px;
        }
        
        .auth-subtitle {
            color: #64748b;
            font-size: 15px;
            margin-bottom: 0;
        }
        
        .form-label {
            color: #374151;
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        .form-control {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            padding: 14px 18px;
            color: #1e293b;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            background: white;
            border-color: #003366;
            box-shadow: 0 0 0 4px rgba(0, 51, 102, 0.1);
            color: #1e293b;
        }
        
        .form-control::placeholder {
            color: #94a3b8;
        }
        
        .input-group-text {
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-right: none;
            color: #64748b;
            transition: all 0.3s ease;
        }
        
        .input-group .form-control {
            border-left: none;
        }
        
        .input-group:focus-within .input-group-text,
        .input-group:focus-within .form-control {
            border-color: #003366;
        }
        
        .input-group:focus-within .input-group-text {
            box-shadow: 0 0 0 4px rgba(0, 51, 102, 0.1);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #003366 0%, #004080 100%);
            border: none;
            border-radius: 10px;
            padding: 14px 28px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, #004080 0%, #0052a3 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 51, 102, 0.3);
        }
        
        .btn-primary:active {
            transform: translateY(0);
        }
        
        .form-check-input {
            border: 2px solid #d1d5db;
            border-radius: 6px;
        }
        
        .form-check-input:checked {
            background-color: #003366;
            border-color: #003366;
        }
        
        .form-check-label {
            color: #64748b;
            font-size: 14px;
        }
        
        .form-check-label a {
            color: #003366;
            text-decoration: none;
            font-weight: 500;
        }
        
        .form-check-label a:hover {
            color: #0052a3;
        }
        
        .auth-links {
            margin-top: 25px;
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }
        
        .auth-links p {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        .auth-links a {
            color: #003366;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        
        .auth-links a:hover {
            color: #0052a3;
        }
        
        .password-strength {
            margin-top: 8px;
        }
        
        .strength-meter {
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
            margin-top: 5px;
        }
        
        .strength-fill {
            height: 100%;
            width: 0%;
            transition: all 0.3s ease;
            border-radius: 3px;
        }
        
        .strength-text {
            font-size: 12px;
            margin-top: 5px;
            color: #64748b;
        }
        
        @media (max-width: 991px) {
            .auth-card {
                max-width: 500px;
            }
            
            .auth-illustration {
                display: none;
            }
            
            .auth-form {
                padding: 40px 30px;
            }
        }
        
        @media (max-width: 576px) {
            .auth-form {
                padding: 30px 20px;
            }
            
            .auth-logo {
                font-size: 22px;
            }
            
            .police-badge {
                width: 100px;
                height: 100px;
            }
            
            .police-badge i {
                font-size: 45px;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="row g-0">
                <div class="col-lg-6">
                    <div class="auth-illustration">
                        <div class="police-badge">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <h2 class="mb-3">Join SurakshaNet</h2>
                        <p class="mb-4">Register with Nepal Police Emergency Response System</p>
                        <div class="police-features">
                            <div class="police-feature">
                                <i class="fas fa-bell"></i>
                                <span>Emergency SOS Alerts</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-file-alt"></i>
                                <span>Incident Reporting</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-user-shield"></i>
                                <span>Missing Person Tracking</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-map-marked-alt"></i>
                                <span>Real-time Location Tracking</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-building"></i>
                                <span>Police Station Locator</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-hand-holding-heart"></i>
                                <span>Crime Reporting</span>
                            </div>
                            <div class="police-feature">
                                <i class="fas fa-users"></i>
                                <span>Community Watch</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="auth-form">
                        <div class="auth-header">
                            <div class="auth-logo">
                                <i class="fas fa-shield-halved"></i> SurakshaNet
                            </div>
                            <p class="auth-subtitle">Create your account</p>
                        </div>
                        
                        <?php if (isset($_SESSION['flash']) && isset($_SESSION['flash']['message'])): ?>
                            <?php 
                                $flashType = $_SESSION['flash']['type'];
                                $flashMessage = $_SESSION['flash']['message'];
                                unset($_SESSION['flash']);
                            ?>
                        <?php endif; ?>
                        
                        <form method="post" id="signupForm">
                            <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
                            
                            <div class="mb-3">
                                <label class="form-label">Full Name <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control" name="name" placeholder="Enter your full name" required minlength="2" pattern="[a-zA-Z\s]+" title="Name should only contain letters and spaces">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email Address <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-envelope"></i>
                                    </span>
                                    <input type="email" class="form-control" name="email" placeholder="Enter your email" required pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" title="Please enter a valid email address">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Phone Number <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background: #f8fafc; border: 2px solid #e2e8f0; border-right: none; padding: 0 15px;">
                                        <img src="https://flagcdn.com/w20/np.png" alt="Nepal" style="width: 20px; height: 14px; margin-right: 8px;">
                                        <span style="font-weight: 600; color: #374151;">+977</span>
                                    </span>
                                    <input type="tel" class="form-control" name="phone" placeholder="Enter your phone number" required pattern="[0-9]{10}" maxlength="10" title="Please enter a valid 10-digit phone number" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Password <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control" name="password" placeholder="Create a password" required id="passwordInput" minlength="8" title="Password must contain at least 8 characters, including uppercase, lowercase, number, and special character">
                                    <button type="button" class="input-group-text" onclick="togglePassword()">
                                        <i class="fas fa-eye" id="passwordToggle"></i>
                                    </button>
                                </div>
                                <div class="password-strength">
                                    <div class="strength-meter">
                                        <div class="strength-fill" id="strengthFill"></div>
                                    </div>
                                    <div class="strength-text" id="strengthText">Password strength</div>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Confirm Password <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm your password" required id="confirmPasswordInput">
                                </div>
                            </div>
                            
                            <div class="form-check mb-4">
                                <input type="checkbox" class="form-check-input" id="terms" required>
                                <label class="form-check-label" for="terms">
                                    I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
                                </label>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 mb-3">
                                <i class="fas fa-user-plus me-2"></i>Create Account
                            </button>
                        </form>
                        
                        <div class="auth-links">
                            <p>Already have an account?</p>
                            <a href="login.php">Sign in</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Flash Message Modal -->
    <div class="modal fade" id="flashModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title" id="flashModalTitle">Notification</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="flashModalBody">
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const input = document.getElementById('passwordInput');
            const toggle = document.getElementById('passwordToggle');
            if (input.type === 'password') {
                input.type = 'text';
                toggle.classList.remove('fa-eye');
                toggle.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                toggle.classList.remove('fa-eye-slash');
                toggle.classList.add('fa-eye');
            }
        }
        
        // Password strength meter
        const passwordInput = document.getElementById('passwordInput');
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            if (password.length >= 8) strength += 1;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 1;
            if (password.match(/\d/)) strength += 1;
            if (password.match(/[^a-zA-Z\d]/)) strength += 1;
            
            const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e'];
            const texts = ['Weak', 'Fair', 'Good', 'Strong'];
            
            strengthFill.style.width = (strength * 25) + '%';
            strengthFill.style.backgroundColor = colors[strength - 1] || '#ef4444';
            strengthText.textContent = texts[strength - 1] || 'Password strength';
            strengthText.style.color = colors[strength - 1] || '#64748b';
        });
        
        // Form validation
        document.getElementById('signupForm').addEventListener('submit', function(e) {
            const password = document.getElementById('passwordInput').value;
            const confirmPassword = document.getElementById('confirmPasswordInput').value;
            const phone = document.querySelector('input[name="phone"]').value;
            const email = document.querySelector('input[name="email"]').value;
            const name = document.querySelector('input[name="name"]').value;
            
            // Validate name
            if (name.trim().length < 2) {
                e.preventDefault();
                alert('Name must be at least 2 characters long!');
                return false;
            }
            
            // Validate email format
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                alert('Please enter a valid email address!');
                return false;
            }
            
            // Validate phone number (10 digits)
 const phoneRegex = /^[0-9]{10}$/;
            if (!phoneRegex.test(phone)) {
                e.preventDefault();
                alert('Please enter a valid 10-digit phone number!');
                return false;
            }
            
            // Validate password match
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                return false;
            }
            
            // Validate password length
            if (password.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters!');
                return false;
            }
            
            // Validate password complexity
            const hasUpperCase = /[A-Z]/.test(password);
            const hasLowerCase = /[a-z]/.test(password);
            const hasNumber = /\d/.test(password);
            const hasSpecial = /[!@#$%^&*]/.test(password);
            
            if (!hasUpperCase || !hasLowerCase || !hasNumber || !hasSpecial) {
                e.preventDefault();
                alert('Password must contain at least 8 characters, including uppercase, lowercase, number, and special character (!@#$%^&*)!');
                return false;
            }
        });
        
        // Show flash message in modal
        <?php if (isset($flashType) && isset($flashMessage)): ?>
            document.addEventListener('DOMContentLoaded', function() {
                const modal = new bootstrap.Modal(document.getElementById('flashModal'));
                const modalTitle = document.getElementById('flashModalTitle');
                const modalBody = document.getElementById('flashModalBody');
                
                modalTitle.textContent = '<?= $flashType === 'danger' ? 'Error' : 'Notification' ?>';
                modalBody.textContent = '<?= e($flashMessage) ?>';
                
                modal.show();
                
                // Auto-hide after 3 seconds
                setTimeout(function() {
                    modal.hide();
                }, 3000);
            });
        <?php endif; ?>
        
        // Prevent browser back button
        history.pushState(null, null, location.href);
        window.onpopstate = function() {
            history.go(1);
            window.location.href = 'login.php';
        };
    </script>
</body>
</html>
