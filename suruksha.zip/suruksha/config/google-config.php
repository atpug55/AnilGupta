<?php
/**
 * Google OAuth Configuration
 * 
 * This file centralizes Google Identity Services configuration.
 * Ensure GOOGLE_CLIENT_ID is set in your .env file.
 * 
 * Note: GOOGLE_CLIENT_ID is already defined in config.php from environment variables.
 */

// Google OAuth redirect URI (auto-handled by Google One Tap)
define('GOOGLE_REDIRECT_URI', APP_URL . '/api/google_login.php');

// Google OAuth scopes
define('GOOGLE_SCOPES', 'openid email profile');

// Check if Google is configured
function is_google_configured(): bool {
    return !empty(GOOGLE_CLIENT_ID) && GOOGLE_CLIENT_ID !== 'your_google_oauth_client_id';
}
