<?php
require_once __DIR__ . '/mailer.php';

function emergency_location_link(?string $lat, ?string $lng): string
{
    if (!$lat || !$lng) {
        return 'Location unavailable';
    }
    return 'https://www.openstreetmap.org/?mlat=' . urlencode($lat) . '&mlon=' . urlencode($lng) . '#map=17/' . urlencode($lat) . '/' . urlencode($lng);
}

function emergency_email_template(array $case, string $type): string
{
    $location = emergency_location_link($case['latitude'] ?? null, $case['longitude'] ?? null);
    $evidence = !empty($case['evidence_path']) ? APP_URL . '/' . ltrim($case['evidence_path'], '/') : 'No evidence uploaded';
    return '<div style="font-family:Arial,sans-serif;background:#f4f6fb;padding:20px">'
        . '<div style="max-width:720px;margin:auto;background:white;border-radius:12px;overflow:hidden;border:1px solid #ddd">'
        . '<div style="background:#b91c1c;color:white;padding:18px"><h2 style="margin:0">NEPAL POLICE EMERGENCY RED ALERT</h2><p style="margin:4px 0 0">SurakshaNet AI Priority Notification</p></div>'
        . '<div style="padding:20px"><h3>Case #' . e((string)$case['id']) . ' - ' . e($type) . '</h3>'
        . '<table style="width:100%;border-collapse:collapse">'
        . '<tr><td><strong>Citizen</strong></td><td>' . e($case['citizen_name'] ?? '') . '</td></tr>'
        . '<tr><td><strong>Phone</strong></td><td>' . e($case['phone'] ?? '') . '</td></tr>'
        . '<tr><td><strong>Emergency Type</strong></td><td>' . e($case['emergency_category'] ?? $case['category'] ?? $type) . '</td></tr>'
        . '<tr><td><strong>Severity</strong></td><td>' . e((string)($case['severity'] ?? '5')) . '/5</td></tr>'
        . '<tr><td><strong>Timestamp</strong></td><td>' . e($case['created_at'] ?? date('Y-m-d H:i:s')) . '</td></tr>'
        . '<tr><td><strong>Location</strong></td><td><a href="' . e($location) . '">' . e($location) . '</a></td></tr>'
        . '<tr><td><strong>Evidence</strong></td><td>' . e($evidence) . '</td></tr>'
        . '</table><p style="margin-top:18px;background:#fff3cd;padding:12px;border-left:4px solid #f59e0b">Respond immediately and update case status from SurakshaNet AI dashboard.</p>'
        . '</div></div></div>';
}

function emergency_recipients(?string $section = null): array
{
    $emails = [];
    $emails[] = MAIL_FROM;

    $stmt = db()->query("SELECT email FROM users WHERE role IN ('admin','super_admin','police_admin','dispatcher','emergency_operator') AND email IS NOT NULL");
    foreach ($stmt as $row) {
        $emails[] = $row['email'];
    }

    if ($section) {
        $stmt = db()->prepare('SELECT email FROM police_stations WHERE (section = ? OR section = ?) AND email IS NOT NULL');
        $stmt->execute([$section, 'Emergency Response']);
    } else {
        $stmt = db()->query('SELECT email FROM police_stations WHERE email IS NOT NULL');
    }
    foreach ($stmt as $row) {
        $emails[] = $row['email'];
    }

    return array_values(array_unique(array_filter($emails)));
}

function send_emergency_alert_emails(array $case, string $type, ?string $section = null, string $relatedType = 'sos'): void
{
    $subject = 'RED ALERT: ' . $type . ' Case #' . $case['id'] . ' Severity ' . ($case['severity'] ?? 5) . '/5';
    $body = emergency_email_template($case, $type);
    foreach (emergency_recipients($section) as $recipient) {
        $sent = send_mail($recipient, $subject, $body);
        db()->prepare('INSERT INTO email_logs (recipient, subject, context, related_type, related_id, sent, error_message) VALUES (?, ?, ?, ?, ?, ?, ?)')
            ->execute([$recipient, $subject, 'emergency_alert', $relatedType, $case['id'], $sent ? 1 : 0, $sent ? null : 'Mail transport returned false']);
    }
}
