<?php
require_once __DIR__ . '/../config/database.php';

function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void
{
    header('Location: ' . APP_URL . '/' . ltrim($path, '/'));
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
            http_response_code(419);
            exit('Invalid security token.');
        }
    }
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) {
        return null;
    }
    $stmt = db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function require_login(): array
{
    $user = current_user();
    if (!$user) {
        redirect('login.php');
    }
    return $user;
}

function require_role(array $roles): array
{
    $user = require_login();
    $roleAliases = [
        'admin' => ['admin', 'super_admin', 'police_admin'],
        'dispatcher' => ['dispatcher', 'emergency_operator'],
    ];
    $allowed = $roles;
    foreach ($roles as $role) {
        if (isset($roleAliases[$role])) {
            $allowed = array_merge($allowed, $roleAliases[$role]);
        }
    }
    if (!in_array($user['role'], array_unique($allowed), true)) {
        http_response_code(403);
        exit('Access denied.');
    }
    return $user;
}

function client_ip(): string
{
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

function check_sos_rate_limit(int $userId): bool
{
    $stmt = db()->prepare("SELECT COUNT(*) c FROM sos_alerts WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 2 MINUTE)");
    $stmt->execute([$userId]);
    return (int)$stmt->fetch()['c'] < 3;
}

function geo_distance_km(float $lat1, float $lon1, float $lat2, float $lon2): float
{
    $earthRadius = 6371;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon / 2) ** 2;
    return $earthRadius * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

function compass_direction(float $lat1, float $lon1, float $lat2, float $lon2): string
{
    $bearing = rad2deg(atan2(
        sin(deg2rad($lon2 - $lon1)) * cos(deg2rad($lat2)),
        cos(deg2rad($lat1)) * sin(deg2rad($lat2)) - sin(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($lon2 - $lon1))
    ));
    $bearing = fmod(($bearing + 360), 360);
    $directions = ['north', 'north-east', 'east', 'south-east', 'south', 'south-west', 'west', 'north-west'];
    return $directions[(int)round($bearing / 45) % 8];
}

function generate_username(string $name): string
{
    $base = strtolower(preg_replace('/[^a-z0-9]+/i', '', $name)) ?: 'citizen';
    do {
        $username = $base . random_int(1000, 9999);
        $stmt = db()->prepare('SELECT id FROM users WHERE username = ?');
        $stmt->execute([$username]);
    } while ($stmt->fetch());
    return $username;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function flashes(): array
{
    $items = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    // Handle both array of flashes and single flash
    if (isset($items['type']) && isset($items['message'])) {
        return [$items];
    }
    return is_array($items) ? $items : [];
}


function ensure_sos_pin_column(): void
{
    try {
        db()->query('SELECT sos_pin_hash FROM users LIMIT 1');
    } catch (Throwable $e) {
        db()->exec('ALTER TABLE users ADD COLUMN sos_pin_hash VARCHAR(255) NULL AFTER password_hash');
    }
}

function parse_device_info(?string $userAgent): array
{
    if (empty($userAgent)) {
        return [
            'os' => 'Unknown',
            'browser' => 'Unknown',
            'device_type' => 'Unknown',
            'platform' => 'Unknown',
            'raw' => 'Unknown'
        ];
    }

    $ua = $userAgent;
    $os = 'Unknown';
    $browser = 'Unknown';
    $deviceType = 'Unknown';
    $platform = 'Unknown';

    // Detect OS
    if (preg_match('/Windows NT 10\.0/i', $ua)) {
        $os = 'Windows 10/11';
    } elseif (preg_match('/Windows NT 6\.3/i', $ua)) {
        $os = 'Windows 8.1';
    } elseif (preg_match('/Windows NT 6\.2/i', $ua)) {
        $os = 'Windows 8';
    } elseif (preg_match('/Windows NT 6\.1/i', $ua)) {
        $os = 'Windows 7';
    } elseif (preg_match('/Windows NT 6\.0/i', $ua)) {
        $os = 'Windows Vista';
    } elseif (preg_match('/Windows NT 5\.1/i', $ua)) {
        $os = 'Windows XP';
    } elseif (preg_match('/Windows NT/i', $ua)) {
        $os = 'Windows';
    } elseif (preg_match('/Mac OS X ([\d_]+)/i', $ua, $matches)) {
        $os = 'macOS ' . str_replace('_', '.', $matches[1]);
    } elseif (preg_match('/Macintosh/i', $ua)) {
        $os = 'macOS';
    } elseif (preg_match('/Linux/i', $ua)) {
        $os = 'Linux';
    } elseif (preg_match('/Android ([\d.]+)/i', $ua, $matches)) {
        $os = 'Android ' . $matches[1];
    } elseif (preg_match('/Android/i', $ua)) {
        $os = 'Android';
    } elseif (preg_match('/iPhone OS ([\d_]+)/i', $ua, $matches)) {
        $os = 'iOS ' . str_replace('_', '.', $matches[1]);
    } elseif (preg_match('/iPad/i', $ua)) {
        $os = 'iPadOS';
    } elseif (preg_match('/iOS/i', $ua)) {
        $os = 'iOS';
    }

    // Detect Browser
    if (preg_match('/Edg\/([\d.]+)/i', $ua, $matches)) {
        $browser = 'Microsoft Edge ' . $matches[1];
    } elseif (preg_match('/Chrome\/([\d.]+)/i', $ua, $matches) && !preg_match('/Edg/i', $ua)) {
        $browser = 'Chrome ' . $matches[1];
    } elseif (preg_match('/Firefox\/([\d.]+)/i', $ua, $matches)) {
        $browser = 'Firefox ' . $matches[1];
    } elseif (preg_match('/Safari\/([\d.]+)/i', $ua, $matches) && !preg_match('/Chrome/i', $ua)) {
        $browser = 'Safari ' . $matches[1];
    } elseif (preg_match('/Opera|OPR\/([\d.]+)/i', $ua, $matches)) {
        $browser = 'Opera ' . ($matches[1] ?? '');
    } elseif (preg_match('/MSIE ([\d.]+)/i', $ua, $matches)) {
        $browser = 'Internet Explorer ' . $matches[1];
    }

    // Detect Device Type
    if (preg_match('/Mobile|Android|iPhone|iPad|iPod/i', $ua)) {
        if (preg_match('/iPad/i', $ua)) {
            $deviceType = 'Tablet';
        } elseif (preg_match('/Android/i', $ua) && preg_match('/Mobile/i', $ua)) {
            $deviceType = 'Mobile';
        } elseif (preg_match('/iPhone|iPod/i', $ua)) {
            $deviceType = 'Mobile';
        } else {
            $deviceType = 'Tablet';
        }
    } else {
        $deviceType = 'Desktop';
    }

    // Detect Platform/Architecture
    if (preg_match('/WOW64|x64|Win64/i', $ua)) {
        $platform = '64-bit';
    } elseif (preg_match('/WOW32|Win32|i386|i686/i', $ua)) {
        $platform = '32-bit';
    } elseif (preg_match('/arm64|aarch64/i', $ua)) {
        $platform = 'ARM64';
    } elseif (preg_match('/arm/i', $ua)) {
        $platform = 'ARM';
    } elseif (preg_match('/Macintosh/i', $ua)) {
        $platform = 'Intel';
    }

    return [
        'os' => $os,
        'browser' => $browser,
        'device_type' => $deviceType,
        'platform' => $platform,
        'raw' => $ua
    ];
}
