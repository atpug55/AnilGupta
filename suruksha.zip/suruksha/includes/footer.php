</main>
<?php $authUser = current_user(); ?>
<footer class="footer-section py-5 mt-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <div class="mb-4">
                    <div class="d-flex align-items-center mb-3">
                        <div class="logo-circle me-2">
                            <img src="<?= APP_URL ?>/assets/images/logo.png" alt="SurakshaNet AI Logo" style="width: 35px; height: 35px; object-fit: contain;">
                        </div>
                        <span class="text-white fw-bold fs-4">SurakshaNet AI</span>
                    </div>
                    <p class="text-white-50">
                        AI-Powered Intelligent Public Safety & Emergency Response Platform for Nepal. 
                        Partnered with Nepal Police for safer communities.
                    </p>
                </div>
                <div class="d-flex">
                    <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-4">
                <h5 class="text-white fw-bold mb-4">Quick Links</h5>
                <?php if ($authUser): ?>
                    <div class="dropdown">
                        <a class="dropdown-toggle d-flex align-items-center text-white-50 text-decoration-none" href="#" role="button" data-bs-toggle="dropdown">
                            <?php if (!empty($authUser['profile_photo'])): ?>
                                <img src="<?= APP_URL ?>/<?= e($authUser['profile_photo']) ?>" alt="Profile" class="rounded-circle me-2" style="width: 32px; height: 32px; object-fit: cover; border: 2px solid #3b82f6;">
                            <?php else: ?>
                                <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                    <i class="fas fa-user text-white small"></i>
                                </div>
                            <?php endif; ?>
                            <?= e($authUser['name']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= APP_URL ?>/<?= $authUser['role'] === 'citizen' ? 'citizen/settings.php' : 'admin/dashboard.php' ?>">
                                <i class="fas fa-cog me-2"></i>Settings
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?= APP_URL ?>/logout.php?csrf_token=<?= csrf_token() ?>">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    
                    <a href="<?= APP_URL ?>/index.php#features" class="footer-link">Features</a>
                    <a href="<?= APP_URL ?>/index.php#awareness" class="footer-link">Safety Tips</a>
                    <a href="<?= APP_URL ?>/register.php" class="footer-link">Register</a>
                    <a href="<?= APP_URL ?>/login.php" class="footer-link">Login</a>
                <?php endif; ?>
            </div>
            <div class="col-lg-2 col-md-4">
                <h5 class="text-white fw-bold mb-4">Services</h5>
                <a href="<?= APP_URL ?>/register.php" class="footer-link">Report Incident</a>
                <a href="<?= APP_URL ?>/register.php" class="footer-link">Missing Person</a>
                <a href="<?= APP_URL ?>/register.php" class="footer-link">SOS Emergency</a>
                <a href="<?= APP_URL ?>/register.php" class="footer-link">Citizen Dashboard</a>
            </div>
            <div class="col-lg-4 col-md-4">
                <h5 class="text-white fw-bold mb-4">Emergency Contacts</h5>
                <div class="mb-3">
                    <div class="d-flex align-items-center text-white-50 mb-2">
                        <i class="fas fa-phone-alt text-warning me-3"></i>
                        <span>Police Emergency: 100</span>
                    </div>
                    <div class="d-flex align-items-center text-white-50 mb-2">
                        <i class="fas fa-fire text-danger me-3"></i>
                        <span>Fire Service: 101</span>
                    </div>
                    <div class="d-flex align-items-center text-white-50 mb-2">
                        <i class="fas fa-ambulance text-success me-3"></i>
                        <span>Ambulance: 102</span>
                    </div>
                    <div class="d-flex align-items-center text-white-50">
                        <i class="fas fa-envelope text-primary me-3"></i>
                        <span>support@surakshanet.gov.np</span>
                    </div>
                </div>
            </div>
        </div>
        <hr class="my-4" style="border-color: rgba(255, 255, 255, 0.1);">
        <div class="row align-items-center">
            <div class="col-md-6">
                <p class="text-white-50 mb-0">
                    &copy; <?= date('Y') ?> SurakshaNet AI. All rights reserved. Official Nepal Police Partner.
                </p>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="#" class="footer-link d-inline-block me-3">Privacy Policy</a>
                <a href="#" class="footer-link d-inline-block me-3">Terms of Service</a>
                <a href="#" class="footer-link d-inline-block">Contact Us</a>
            </div>
        </div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="<?= APP_URL ?>/assets/js/app.js"></script>
</body>
</html>
