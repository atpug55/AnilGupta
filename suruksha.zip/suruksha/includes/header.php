<?php require_once __DIR__ . '/helpers.php'; $authUser = current_user(); ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= csrf_token() ?>">
    <title><?= e(APP_NAME) ?></title>
    <link rel="icon" type="image/png" href="<?= APP_URL ?>/assets/images/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
    <?php if (GOOGLE_CLIENT_ID): ?>
        <script src="https://accounts.google.com/gsi/client" async defer></script>
    <?php endif; ?>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark suraksha-navbar sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold d-flex align-items-center" href="<?= $authUser ? APP_URL . '/' . ($authUser['role'] === 'citizen' ? 'citizen/dashboard.php' : 'admin/dashboard.php') : APP_URL . '/index.php' ?>">
            <div class="logo-circle me-2">
                <img src="<?= APP_URL ?>/assets/images/logo.png" alt="SurakshaNet AI Logo" style="width: 35px; height: 35px; object-fit: contain;">
            </div>
            <span>SurakshaNet AI</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto">
                <?php if ($authUser): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                            <?php if (!empty($authUser['profile_photo'])): ?>
                                <img src="<?= APP_URL ?>/<?= e($authUser['profile_photo']) ?>" alt="Profile" class="rounded-circle me-2" style="width: 32px; height: 32px; object-fit: cover; border: 2px solid #3b82f6;">
                            <?php else: ?>
                                <div class="rounded-circle bg-primary d-flex align-items-center justify-content-center me-2" style="width: 32px; height: 32px;">
                                    <i class="fas fa-user text-white small"></i>
                                </div>
                            <?php endif; ?>
                            <?= e($authUser['name']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="<?= APP_URL ?>/<?= $authUser['role'] === 'citizen' ? 'citizen/settings.php' : 'admin/dashboard.php' ?>">
                                <i class="fas fa-cog me-2"></i>Settings
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?= APP_URL ?>/logout.php?csrf_token=<?= csrf_token() ?>">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/index.php#home">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/index.php#features">Features</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/index.php#awareness">Safety Tips</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= APP_URL ?>/login.php">Login</a></li>
                    <li class="nav-item d-flex align-items-center"><a class="btn btn-police ms-2" href="<?= APP_URL ?>/register.php">Sign Up</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<main>
<?php foreach (flashes() as $flash): ?>
    <div class="container mt-3"><div class="alert alert-<?= e($flash['type']) ?>"><?= e($flash['message']) ?></div></div>
<?php endforeach; ?>
