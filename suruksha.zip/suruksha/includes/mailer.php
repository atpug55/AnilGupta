<?php
require_once __DIR__ . '/helpers.php';

function send_mail(string $to, string $subject, string $body): bool
{
    if (MAIL_USERNAME === '' || MAIL_PASSWORD === '') {
        error_log('Mail error: SMTP username/password are not configured.');
        return false;
    }

    $autoload = __DIR__ . '/../vendor/autoload.php';
    if (file_exists($autoload)) {
        require_once $autoload;
        if (class_exists('PHPMailer\\PHPMailer\\PHPMailer')) {
            $mail = new PHPMailer\PHPMailer\PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = MAIL_HOST;
                $mail->SMTPAuth = true;
                $mail->Username = MAIL_USERNAME;
                $mail->Password = MAIL_PASSWORD;
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = (int)MAIL_PORT;
                $mail->setFrom(MAIL_FROM, APP_NAME);
                $mail->addAddress($to);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $body;
                $mail->AltBody = strip_tags($body);
                return $mail->send();
            } catch (Throwable $e) {
                error_log('Mail error: ' . $e->getMessage());
                return false;
            }
        }
    }

    return send_mail_via_smtp($to, $subject, $body);
}

function send_mail_via_smtp(string $to, string $subject, string $body): bool
{
    $host = MAIL_HOST;
    $port = (int)MAIL_PORT;
    $from = MAIL_FROM ?: MAIL_USERNAME;
    $socket = @stream_socket_client('tcp://' . $host . ':' . $port, $errno, $errstr, 20);
    if (!$socket) {
        error_log('Mail error: SMTP connection failed: ' . $errstr);
        return false;
    }

    stream_set_timeout($socket, 20);
    $read = static function () use ($socket): string {
        $data = '';
        while (($line = fgets($socket, 515)) !== false) {
            $data .= $line;
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        return $data;
    };
    $write = static function (string $command) use ($socket): void {
        fwrite($socket, $command . "\r\n");
    };
    $expect = static function (array $codes) use ($read): bool {
        $response = $read();
        $code = substr($response, 0, 3);
        if (!in_array($code, $codes, true)) {
            error_log('Mail error: SMTP response: ' . trim($response));
            return false;
        }
        return true;
    };

    if (!$expect(['220'])) {
        fclose($socket);
        return false;
    }
    $write('EHLO localhost');
    if (!$expect(['250'])) {
        fclose($socket);
        return false;
    }
    $write('STARTTLS');
    if (!$expect(['220']) || !stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
        error_log('Mail error: STARTTLS failed.');
        fclose($socket);
        return false;
    }
    $write('EHLO localhost');
    if (!$expect(['250'])) {
        fclose($socket);
        return false;
    }
    $write('AUTH LOGIN');
    if (!$expect(['334'])) {
        fclose($socket);
        return false;
    }
    $write(base64_encode(MAIL_USERNAME));
    if (!$expect(['334'])) {
        fclose($socket);
        return false;
    }
    $write(base64_encode(MAIL_PASSWORD));
    if (!$expect(['235'])) {
        fclose($socket);
        return false;
    }
    $write('MAIL FROM:<' . $from . '>');
    if (!$expect(['250'])) {
        fclose($socket);
        return false;
    }
    $write('RCPT TO:<' . $to . '>');
    if (!$expect(['250', '251'])) {
        fclose($socket);
        return false;
    }
    $write('DATA');
    if (!$expect(['354'])) {
        fclose($socket);
        return false;
    }

    $headers = [
        'From: ' . APP_NAME . ' <' . $from . '>',
        'To: <' . $to . '>',
        'Subject: ' . $subject,
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
    ];
    $message = implode("\r\n", $headers) . "\r\n\r\n" . str_replace("\n.", "\n..", $body) . "\r\n.";
    $write($message);
    $sent = $expect(['250']);
    $write('QUIT');
    fclose($socket);

    return $sent;
}
