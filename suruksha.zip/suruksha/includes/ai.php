<?php
require_once __DIR__ . '/helpers.php';

function analyze_incident_with_ai(string $title, string $description, string $language = 'auto'): array
{
    $fallback = ['category' => 'General Emergency', 'severity' => 3, 'is_spam' => false, 'summary' => mb_substr($description, 0, 180)];
    if (GEMINI_API_KEY === '') {
        return $fallback;
    }

    $prompt = 'Analyze this Nepal police emergency report. Return only JSON with category, severity 1-5, is_spam boolean, summary, language. Title: ' . $title . ' Description: ' . $description . ' Language: ' . $language;
    $payload = json_encode(['contents' => [['parts' => [['text' => $prompt]]]]]);
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' . urlencode(GEMINI_API_KEY);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_TIMEOUT => 12,
    ]);
    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response ?: '', true);
    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
    $text = trim(str_replace(['```json', '```'], '', $text));
    $json = json_decode($text, true);

    if (!is_array($json)) {
        return $fallback;
    }

    return [
        'category' => $json['category'] ?? $fallback['category'],
        'severity' => max(1, min(5, (int)($json['severity'] ?? 3))),
        'is_spam' => (bool)($json['is_spam'] ?? false),
        'summary' => $json['summary'] ?? $fallback['summary'],
    ];
}
